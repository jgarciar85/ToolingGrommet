<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> Partial Class Form1
#Region "Windows Form Designer generated code "
	<System.Diagnostics.DebuggerNonUserCode()> Public Sub New()
		MyBase.New()
		'This call is required by the Windows Form Designer.
		InitializeComponent()
	End Sub
	'Form overrides dispose to clean up the component list.
	<System.Diagnostics.DebuggerNonUserCode()> Protected Overloads Overrides Sub Dispose(ByVal Disposing As Boolean)
		If Disposing Then
			If Not components Is Nothing Then
				components.Dispose()
			End If
		End If
		MyBase.Dispose(Disposing)
	End Sub
	'Required by the Windows Form Designer
	Private components As System.ComponentModel.IContainer
    'Public WithEvents MesOraMFC1 As AxMesMFC.AxMesOraMFC
    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.
    'Do not modify it using the code editor.
	<System.Diagnostics.DebuggerStepThrough()> Private Sub InitializeComponent()
        Me.components = New System.ComponentModel.Container()
        Dim DataGridViewCellStyle4 As System.Windows.Forms.DataGridViewCellStyle = New System.Windows.Forms.DataGridViewCellStyle()
        Dim DataGridViewCellStyle5 As System.Windows.Forms.DataGridViewCellStyle = New System.Windows.Forms.DataGridViewCellStyle()
        Dim DataGridViewCellStyle6 As System.Windows.Forms.DataGridViewCellStyle = New System.Windows.Forms.DataGridViewCellStyle()
        Dim resources As System.ComponentModel.ComponentResourceManager = New System.ComponentModel.ComponentResourceManager(GetType(Form1))
        Me.Label19 = New System.Windows.Forms.Label()
        Me.Label20 = New System.Windows.Forms.Label()
        Me.OEE_CURRENT = New System.Windows.Forms.Label()
        Me.Panel1 = New System.Windows.Forms.Panel()
        Me.QUALITY = New System.Windows.Forms.Label()
        Me.Label23 = New System.Windows.Forms.Label()
        Me.PERFORMANCE = New System.Windows.Forms.Label()
        Me.Label22 = New System.Windows.Forms.Label()
        Me.AVAILABILITY = New System.Windows.Forms.Label()
        Me.Label21 = New System.Windows.Forms.Label()
        Me.FECHA = New System.Windows.Forms.Label()
        Me.HORA = New System.Windows.Forms.Label()
        Me.Panel2 = New System.Windows.Forms.Panel()
        Me.TimerMain = New System.Windows.Forms.Timer(Me.components)
        Me.Timer4 = New System.Windows.Forms.Timer(Me.components)
        Me.MenuStrip1 = New System.Windows.Forms.MenuStrip()
        Me.MantenimientoToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.AjustesToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.AcercaDeToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.TmrDbToFile = New System.Windows.Forms.Timer(Me.components)
        Me.tpEstacion1 = New System.Windows.Forms.TabPage()
        Me.PE6TS = New System.Windows.Forms.Label()
        Me.PV6TS = New System.Windows.Forms.Label()
        Me.PA6TS = New System.Windows.Forms.Label()
        Me.Label66 = New System.Windows.Forms.Label()
        Me.LPE6S = New System.Windows.Forms.Button()
        Me.LPV6S = New System.Windows.Forms.Button()
        Me.LPA6S = New System.Windows.Forms.Button()
        Me.Label6 = New System.Windows.Forms.Label()
        Me.GridChangeTool = New System.Windows.Forms.DataGridView()
        Me.btnRevisarE1 = New System.Windows.Forms.Button()
        Me.BtnRepTool = New System.Windows.Forms.Button()
        Me.Label73 = New System.Windows.Forms.Label()
        Me.txtVidaE1 = New System.Windows.Forms.TextBox()
        Me.txtUsoE1 = New System.Windows.Forms.TextBox()
        Me.Label75 = New System.Windows.Forms.Label()
        Me.txtEmplE1 = New System.Windows.Forms.TextBox()
        Me.Label76 = New System.Windows.Forms.Label()
        Me.Label77 = New System.Windows.Forms.Label()
        Me.Label78 = New System.Windows.Forms.Label()
        Me.txtTurnoE1 = New System.Windows.Forms.TextBox()
        Me.txtLadoE1 = New System.Windows.Forms.TextBox()
        Me.txtPrenE1 = New System.Windows.Forms.TextBox()
        Me.txtLineaE1 = New System.Windows.Forms.TextBox()
        Me.txtHoraE1 = New System.Windows.Forms.TextBox()
        Me.txtFechE1 = New System.Windows.Forms.TextBox()
        Me.txtTecE1 = New System.Windows.Forms.TextBox()
        Me.txtLainaE1 = New System.Windows.Forms.TextBox()
        Me.txtGreenE1 = New System.Windows.Forms.TextBox()
        Me.txtAntE1 = New System.Windows.Forms.TextBox()
        Me.Label79 = New System.Windows.Forms.Label()
        Me.Label80 = New System.Windows.Forms.Label()
        Me.Label81 = New System.Windows.Forms.Label()
        Me.Label82 = New System.Windows.Forms.Label()
        Me.Label83 = New System.Windows.Forms.Label()
        Me.Label84 = New System.Windows.Forms.Label()
        Me.Label85 = New System.Windows.Forms.Label()
        Me.Label86 = New System.Windows.Forms.Label()
        Me.Label87 = New System.Windows.Forms.Label()
        Me.txtToolE1 = New System.Windows.Forms.TextBox()
        Me.PE5TS = New System.Windows.Forms.Label()
        Me.PV5TS = New System.Windows.Forms.Label()
        Me.PA5TS = New System.Windows.Forms.Label()
        Me.PE4TS = New System.Windows.Forms.Label()
        Me.PV4TS = New System.Windows.Forms.Label()
        Me.PA4TS = New System.Windows.Forms.Label()
        Me.PE3TS = New System.Windows.Forms.Label()
        Me.PV3TS = New System.Windows.Forms.Label()
        Me.PA3TS = New System.Windows.Forms.Label()
        Me.PE2TS = New System.Windows.Forms.Label()
        Me.PV2TS = New System.Windows.Forms.Label()
        Me.PA2TS = New System.Windows.Forms.Label()
        Me.PE1TS = New System.Windows.Forms.Label()
        Me.PV1TS = New System.Windows.Forms.Label()
        Me.PA1TS = New System.Windows.Forms.Label()
        Me.Label45 = New System.Windows.Forms.Label()
        Me.Label46 = New System.Windows.Forms.Label()
        Me.LPA1S = New System.Windows.Forms.Button()
        Me.Label47 = New System.Windows.Forms.Label()
        Me.Label48 = New System.Windows.Forms.Label()
        Me.LPE4S = New System.Windows.Forms.Button()
        Me.LPE1S = New System.Windows.Forms.Button()
        Me.LPV5S = New System.Windows.Forms.Button()
        Me.LPE5S = New System.Windows.Forms.Button()
        Me.Label49 = New System.Windows.Forms.Label()
        Me.LPV1S = New System.Windows.Forms.Button()
        Me.LPA5S = New System.Windows.Forms.Button()
        Me.LPA4S = New System.Windows.Forms.Button()
        Me.LPE2S = New System.Windows.Forms.Button()
        Me.LPV2S = New System.Windows.Forms.Button()
        Me.LPA2S = New System.Windows.Forms.Button()
        Me.LPV3S = New System.Windows.Forms.Button()
        Me.LPA3S = New System.Windows.Forms.Button()
        Me.LPE3S = New System.Windows.Forms.Button()
        Me.LPV4S = New System.Windows.Forms.Button()
        Me.InformacionHH = New System.Windows.Forms.TabPage()
        Me.BtnEnvioHH = New System.Windows.Forms.Button()
        Me.Tooling = New System.Windows.Forms.TabPage()
        Me.TxtUpdTooling = New System.Windows.Forms.TextBox()
        Me.BtnSave = New System.Windows.Forms.Button()
        Me.GridTooling = New System.Windows.Forms.DataGridView()
        Me.Lineas = New System.Windows.Forms.TabPage()
        Me.Panel3 = New System.Windows.Forms.Panel()
        Me.PE13T = New System.Windows.Forms.Label()
        Me.EdNumEmpleado = New System.Windows.Forms.TextBox()
        Me.PE11T = New System.Windows.Forms.Label()
        Me.Label1 = New System.Windows.Forms.Label()
        Me.PE10T = New System.Windows.Forms.Label()
        Me.EdtTecnico = New System.Windows.Forms.TextBox()
        Me.PV13T = New System.Windows.Forms.Label()
        Me.Label44 = New System.Windows.Forms.Label()
        Me.PV11T = New System.Windows.Forms.Label()
        Me.Label3 = New System.Windows.Forms.Label()
        Me.PV10T = New System.Windows.Forms.Label()
        Me.EdtLine = New System.Windows.Forms.TextBox()
        Me.PA13T = New System.Windows.Forms.Label()
        Me.Label41 = New System.Windows.Forms.Label()
        Me.PA11T = New System.Windows.Forms.Label()
        Me.EdtPrensa = New System.Windows.Forms.TextBox()
        Me.PA10T = New System.Windows.Forms.Label()
        Me.Label32 = New System.Windows.Forms.Label()
        Me.PE9T = New System.Windows.Forms.Label()
        Me.EdtLado = New System.Windows.Forms.TextBox()
        Me.PV9T = New System.Windows.Forms.Label()
        Me.Label33 = New System.Windows.Forms.Label()
        Me.PA9T = New System.Windows.Forms.Label()
        Me.EdtHora = New System.Windows.Forms.TextBox()
        Me.PE8T = New System.Windows.Forms.Label()
        Me.Label34 = New System.Windows.Forms.Label()
        Me.PV8T = New System.Windows.Forms.Label()
        Me.EdtFecha = New System.Windows.Forms.TextBox()
        Me.PA8T = New System.Windows.Forms.Label()
        Me.Label35 = New System.Windows.Forms.Label()
        Me.PE7T = New System.Windows.Forms.Label()
        Me.EdtTurno = New System.Windows.Forms.TextBox()
        Me.PV7T = New System.Windows.Forms.Label()
        Me.Label39 = New System.Windows.Forms.Label()
        Me.PA7T = New System.Windows.Forms.Label()
        Me.EdtTooling = New System.Windows.Forms.TextBox()
        Me.PE6T = New System.Windows.Forms.Label()
        Me.Label38 = New System.Windows.Forms.Label()
        Me.PV6T = New System.Windows.Forms.Label()
        Me.EdtVida = New System.Windows.Forms.TextBox()
        Me.PA6T = New System.Windows.Forms.Label()
        Me.Label4 = New System.Windows.Forms.Label()
        Me.PE5T = New System.Windows.Forms.Label()
        Me.EdtTiempoTotal = New System.Windows.Forms.TextBox()
        Me.PV5T = New System.Windows.Forms.Label()
        Me.Label2 = New System.Windows.Forms.Label()
        Me.PA5T = New System.Windows.Forms.Label()
        Me.EdtPPackAnt = New System.Windows.Forms.TextBox()
        Me.PE4T = New System.Windows.Forms.Label()
        Me.Label37 = New System.Windows.Forms.Label()
        Me.PV4T = New System.Windows.Forms.Label()
        Me.EdtGreenPlate = New System.Windows.Forms.TextBox()
        Me.PA4T = New System.Windows.Forms.Label()
        Me.Label43 = New System.Windows.Forms.Label()
        Me.PE3T = New System.Windows.Forms.Label()
        Me.EdtLaina = New System.Windows.Forms.TextBox()
        Me.Label40 = New System.Windows.Forms.Label()
        Me.PV3T = New System.Windows.Forms.Label()
        Me.Label5 = New System.Windows.Forms.Label()
        Me.PA3T = New System.Windows.Forms.Label()
        Me.PE2T = New System.Windows.Forms.Label()
        Me.PV2T = New System.Windows.Forms.Label()
        Me.PA2T = New System.Windows.Forms.Label()
        Me.PE1T = New System.Windows.Forms.Label()
        Me.PV1T = New System.Windows.Forms.Label()
        Me.PA1T = New System.Windows.Forms.Label()
        Me.Label15 = New System.Windows.Forms.Label()
        Me.Label16 = New System.Windows.Forms.Label()
        Me.Label10 = New System.Windows.Forms.Label()
        Me.Label8 = New System.Windows.Forms.Label()
        Me.Label31 = New System.Windows.Forms.Label()
        Me.Label30 = New System.Windows.Forms.Label()
        Me.Label29 = New System.Windows.Forms.Label()
        Me.LPA9 = New System.Windows.Forms.Button()
        Me.LPE13 = New System.Windows.Forms.Button()
        Me.Label25 = New System.Windows.Forms.Label()
        Me.LPE11 = New System.Windows.Forms.Button()
        Me.LPE10 = New System.Windows.Forms.Button()
        Me.LPV13 = New System.Windows.Forms.Button()
        Me.Label24 = New System.Windows.Forms.Label()
        Me.LPV11 = New System.Windows.Forms.Button()
        Me.LPV10 = New System.Windows.Forms.Button()
        Me.LPA13 = New System.Windows.Forms.Button()
        Me.LPA1 = New System.Windows.Forms.Button()
        Me.LPA11 = New System.Windows.Forms.Button()
        Me.LPA10 = New System.Windows.Forms.Button()
        Me.Label27 = New System.Windows.Forms.Label()
        Me.Label26 = New System.Windows.Forms.Label()
        Me.LPE4 = New System.Windows.Forms.Button()
        Me.LPE9 = New System.Windows.Forms.Button()
        Me.LPE1 = New System.Windows.Forms.Button()
        Me.LPV8 = New System.Windows.Forms.Button()
        Me.LPV5 = New System.Windows.Forms.Button()
        Me.LPA8 = New System.Windows.Forms.Button()
        Me.LPE5 = New System.Windows.Forms.Button()
        Me.LPE7 = New System.Windows.Forms.Button()
        Me.LPE6 = New System.Windows.Forms.Button()
        Me.Label17 = New System.Windows.Forms.Label()
        Me.LPV7 = New System.Windows.Forms.Button()
        Me.LPV6 = New System.Windows.Forms.Button()
        Me.LPV1 = New System.Windows.Forms.Button()
        Me.LPA5 = New System.Windows.Forms.Button()
        Me.LPA4 = New System.Windows.Forms.Button()
        Me.LPE2 = New System.Windows.Forms.Button()
        Me.LPV2 = New System.Windows.Forms.Button()
        Me.LPA2 = New System.Windows.Forms.Button()
        Me.LPA7 = New System.Windows.Forms.Button()
        Me.LPV3 = New System.Windows.Forms.Button()
        Me.LPA3 = New System.Windows.Forms.Button()
        Me.LPE3 = New System.Windows.Forms.Button()
        Me.LPA6 = New System.Windows.Forms.Button()
        Me.LPV4 = New System.Windows.Forms.Button()
        Me.LPV9 = New System.Windows.Forms.Button()
        Me.LPE8 = New System.Windows.Forms.Button()
        Me.TabHistorial = New System.Windows.Forms.TabControl()
        Me.tpEstacion2 = New System.Windows.Forms.TabPage()
        Me.Label7 = New System.Windows.Forms.Label()
        Me.GridChangeTool2 = New System.Windows.Forms.DataGridView()
        Me.btnRevisarE2 = New System.Windows.Forms.Button()
        Me.btnRepararE2 = New System.Windows.Forms.Button()
        Me.Label88 = New System.Windows.Forms.Label()
        Me.txtVidaE2 = New System.Windows.Forms.TextBox()
        Me.txtUsoE2 = New System.Windows.Forms.TextBox()
        Me.Label90 = New System.Windows.Forms.Label()
        Me.txtEmpE2 = New System.Windows.Forms.TextBox()
        Me.Label91 = New System.Windows.Forms.Label()
        Me.Label92 = New System.Windows.Forms.Label()
        Me.Label93 = New System.Windows.Forms.Label()
        Me.txtTurnoE2 = New System.Windows.Forms.TextBox()
        Me.txtLadoE2 = New System.Windows.Forms.TextBox()
        Me.txtPrensaE2 = New System.Windows.Forms.TextBox()
        Me.txtLineaE2 = New System.Windows.Forms.TextBox()
        Me.txtHoraE2 = New System.Windows.Forms.TextBox()
        Me.txtFechE2 = New System.Windows.Forms.TextBox()
        Me.txtTecE2 = New System.Windows.Forms.TextBox()
        Me.txtLainaE2 = New System.Windows.Forms.TextBox()
        Me.txtGreenE2 = New System.Windows.Forms.TextBox()
        Me.txtAntE2 = New System.Windows.Forms.TextBox()
        Me.Label94 = New System.Windows.Forms.Label()
        Me.Label95 = New System.Windows.Forms.Label()
        Me.Label96 = New System.Windows.Forms.Label()
        Me.Label97 = New System.Windows.Forms.Label()
        Me.Label98 = New System.Windows.Forms.Label()
        Me.Label99 = New System.Windows.Forms.Label()
        Me.Label100 = New System.Windows.Forms.Label()
        Me.Label101 = New System.Windows.Forms.Label()
        Me.Label102 = New System.Windows.Forms.Label()
        Me.txtToolE2 = New System.Windows.Forms.TextBox()
        Me.PE13TS = New System.Windows.Forms.Label()
        Me.PE11TS = New System.Windows.Forms.Label()
        Me.PE10TS = New System.Windows.Forms.Label()
        Me.PV13TS = New System.Windows.Forms.Label()
        Me.PV11TS = New System.Windows.Forms.Label()
        Me.PV10TS = New System.Windows.Forms.Label()
        Me.PA13TS = New System.Windows.Forms.Label()
        Me.PA11TS = New System.Windows.Forms.Label()
        Me.PA10TS = New System.Windows.Forms.Label()
        Me.PE9TS = New System.Windows.Forms.Label()
        Me.PV9TS = New System.Windows.Forms.Label()
        Me.PA9TS = New System.Windows.Forms.Label()
        Me.PE8TS = New System.Windows.Forms.Label()
        Me.PV8TS = New System.Windows.Forms.Label()
        Me.PA8TS = New System.Windows.Forms.Label()
        Me.PE7TS = New System.Windows.Forms.Label()
        Me.PV7TS = New System.Windows.Forms.Label()
        Me.PA7TS = New System.Windows.Forms.Label()
        Me.Label11 = New System.Windows.Forms.Label()
        Me.Label9 = New System.Windows.Forms.Label()
        Me.Label62 = New System.Windows.Forms.Label()
        Me.Label63 = New System.Windows.Forms.Label()
        Me.Label64 = New System.Windows.Forms.Label()
        Me.LPA9S = New System.Windows.Forms.Button()
        Me.Label65 = New System.Windows.Forms.Label()
        Me.LPE13S = New System.Windows.Forms.Button()
        Me.LPE11S = New System.Windows.Forms.Button()
        Me.LPV13S = New System.Windows.Forms.Button()
        Me.LPE10S = New System.Windows.Forms.Button()
        Me.LPA13S = New System.Windows.Forms.Button()
        Me.LPV11S = New System.Windows.Forms.Button()
        Me.LPA11S = New System.Windows.Forms.Button()
        Me.LPV10S = New System.Windows.Forms.Button()
        Me.LPA10S = New System.Windows.Forms.Button()
        Me.LPE9S = New System.Windows.Forms.Button()
        Me.LPV8S = New System.Windows.Forms.Button()
        Me.LPA8S = New System.Windows.Forms.Button()
        Me.LPE7S = New System.Windows.Forms.Button()
        Me.LPV7S = New System.Windows.Forms.Button()
        Me.LPA7S = New System.Windows.Forms.Button()
        Me.LPV9S = New System.Windows.Forms.Button()
        Me.LPE8S = New System.Windows.Forms.Button()
        Me.tpEstacion3 = New System.Windows.Forms.TabPage()
        Me.GrdGrommet = New System.Windows.Forms.DataGridView()
        Me.Button1 = New System.Windows.Forms.Button()
        Me.lblEstacion = New System.Windows.Forms.Label()
        Me.tmrChange = New System.Windows.Forms.Timer(Me.components)
        Me.PictureBox1 = New System.Windows.Forms.PictureBox()
        Me.Panel1.SuspendLayout()
        Me.MenuStrip1.SuspendLayout()
        Me.tpEstacion1.SuspendLayout()
        CType(Me.GridChangeTool, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.InformacionHH.SuspendLayout()
        Me.Tooling.SuspendLayout()
        CType(Me.GridTooling, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.Lineas.SuspendLayout()
        Me.Panel3.SuspendLayout()
        Me.TabHistorial.SuspendLayout()
        Me.tpEstacion2.SuspendLayout()
        CType(Me.GridChangeTool2, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.tpEstacion3.SuspendLayout()
        CType(Me.GrdGrommet, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.PictureBox1, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.SuspendLayout()
        '
        'Label19
        '
        Me.Label19.BackColor = System.Drawing.Color.White
        Me.Label19.Font = New System.Drawing.Font("Times New Roman", 48.0!, System.Drawing.FontStyle.Bold)
        Me.Label19.ForeColor = System.Drawing.Color.Black
        Me.Label19.Location = New System.Drawing.Point(252, 1)
        Me.Label19.Name = "Label19"
        Me.Label19.Size = New System.Drawing.Size(805, 119)
        Me.Label19.TabIndex = 11
        Me.Label19.Text = "CONTROL DE TOOLING"
        Me.Label19.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'Label20
        '
        Me.Label20.BackColor = System.Drawing.Color.Lime
        Me.Label20.Font = New System.Drawing.Font("Times New Roman", 36.0!, System.Drawing.FontStyle.Bold)
        Me.Label20.ForeColor = System.Drawing.Color.DarkBlue
        Me.Label20.ImageAlign = System.Drawing.ContentAlignment.BottomCenter
        Me.Label20.Location = New System.Drawing.Point(7, 6)
        Me.Label20.Name = "Label20"
        Me.Label20.Size = New System.Drawing.Size(138, 64)
        Me.Label20.TabIndex = 12
        Me.Label20.Text = "OEE"
        Me.Label20.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'OEE_CURRENT
        '
        Me.OEE_CURRENT.BackColor = System.Drawing.Color.DarkBlue
        Me.OEE_CURRENT.Font = New System.Drawing.Font("Arial", 36.0!, System.Drawing.FontStyle.Bold)
        Me.OEE_CURRENT.ForeColor = System.Drawing.Color.Lime
        Me.OEE_CURRENT.Location = New System.Drawing.Point(1, 70)
        Me.OEE_CURRENT.Name = "OEE_CURRENT"
        Me.OEE_CURRENT.Size = New System.Drawing.Size(149, 56)
        Me.OEE_CURRENT.TabIndex = 13
        Me.OEE_CURRENT.Text = "100.0"
        Me.OEE_CURRENT.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'Panel1
        '
        Me.Panel1.BackColor = System.Drawing.Color.DarkBlue
        Me.Panel1.Controls.Add(Me.QUALITY)
        Me.Panel1.Controls.Add(Me.Label23)
        Me.Panel1.Controls.Add(Me.PERFORMANCE)
        Me.Panel1.Controls.Add(Me.Label22)
        Me.Panel1.Controls.Add(Me.AVAILABILITY)
        Me.Panel1.Controls.Add(Me.Label21)
        Me.Panel1.Controls.Add(Me.OEE_CURRENT)
        Me.Panel1.Controls.Add(Me.Label20)
        Me.Panel1.Location = New System.Drawing.Point(857, 165)
        Me.Panel1.Name = "Panel1"
        Me.Panel1.Size = New System.Drawing.Size(150, 368)
        Me.Panel1.TabIndex = 14
        '
        'QUALITY
        '
        Me.QUALITY.BackColor = System.Drawing.Color.Lime
        Me.QUALITY.Font = New System.Drawing.Font("Arial", 26.25!, System.Drawing.FontStyle.Bold)
        Me.QUALITY.ForeColor = System.Drawing.Color.Navy
        Me.QUALITY.ImageAlign = System.Drawing.ContentAlignment.TopCenter
        Me.QUALITY.Location = New System.Drawing.Point(4, 311)
        Me.QUALITY.Name = "QUALITY"
        Me.QUALITY.Size = New System.Drawing.Size(142, 43)
        Me.QUALITY.TabIndex = 20
        Me.QUALITY.Text = "0.0"
        Me.QUALITY.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'Label23
        '
        Me.Label23.BackColor = System.Drawing.Color.Lime
        Me.Label23.Font = New System.Drawing.Font("Trebuchet MS", 14.25!, System.Drawing.FontStyle.Bold)
        Me.Label23.ForeColor = System.Drawing.Color.DarkBlue
        Me.Label23.ImageAlign = System.Drawing.ContentAlignment.BottomCenter
        Me.Label23.Location = New System.Drawing.Point(4, 287)
        Me.Label23.Name = "Label23"
        Me.Label23.Size = New System.Drawing.Size(142, 24)
        Me.Label23.TabIndex = 19
        Me.Label23.Text = "QUALITY"
        Me.Label23.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'PERFORMANCE
        '
        Me.PERFORMANCE.BackColor = System.Drawing.Color.Lime
        Me.PERFORMANCE.Font = New System.Drawing.Font("Arial", 26.25!, System.Drawing.FontStyle.Bold)
        Me.PERFORMANCE.ForeColor = System.Drawing.Color.Navy
        Me.PERFORMANCE.ImageAlign = System.Drawing.ContentAlignment.TopCenter
        Me.PERFORMANCE.Location = New System.Drawing.Point(4, 232)
        Me.PERFORMANCE.Name = "PERFORMANCE"
        Me.PERFORMANCE.Size = New System.Drawing.Size(142, 43)
        Me.PERFORMANCE.TabIndex = 18
        Me.PERFORMANCE.Text = "0.0"
        Me.PERFORMANCE.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'Label22
        '
        Me.Label22.BackColor = System.Drawing.Color.Lime
        Me.Label22.Font = New System.Drawing.Font("Trebuchet MS", 14.25!, System.Drawing.FontStyle.Bold)
        Me.Label22.ForeColor = System.Drawing.Color.DarkBlue
        Me.Label22.ImageAlign = System.Drawing.ContentAlignment.BottomCenter
        Me.Label22.Location = New System.Drawing.Point(4, 208)
        Me.Label22.Name = "Label22"
        Me.Label22.Size = New System.Drawing.Size(142, 24)
        Me.Label22.TabIndex = 17
        Me.Label22.Text = "PERFORMANCE"
        Me.Label22.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'AVAILABILITY
        '
        Me.AVAILABILITY.BackColor = System.Drawing.Color.Lime
        Me.AVAILABILITY.Font = New System.Drawing.Font("Arial", 26.25!, System.Drawing.FontStyle.Bold)
        Me.AVAILABILITY.ForeColor = System.Drawing.Color.Navy
        Me.AVAILABILITY.ImageAlign = System.Drawing.ContentAlignment.TopCenter
        Me.AVAILABILITY.Location = New System.Drawing.Point(5, 153)
        Me.AVAILABILITY.Name = "AVAILABILITY"
        Me.AVAILABILITY.Size = New System.Drawing.Size(140, 43)
        Me.AVAILABILITY.TabIndex = 16
        Me.AVAILABILITY.Text = "0.0"
        Me.AVAILABILITY.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'Label21
        '
        Me.Label21.BackColor = System.Drawing.Color.Lime
        Me.Label21.Font = New System.Drawing.Font("Trebuchet MS", 14.25!, System.Drawing.FontStyle.Bold)
        Me.Label21.ForeColor = System.Drawing.Color.DarkBlue
        Me.Label21.ImageAlign = System.Drawing.ContentAlignment.BottomCenter
        Me.Label21.Location = New System.Drawing.Point(5, 129)
        Me.Label21.Name = "Label21"
        Me.Label21.Size = New System.Drawing.Size(140, 24)
        Me.Label21.TabIndex = 15
        Me.Label21.Text = "AVAILABILITY"
        Me.Label21.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'FECHA
        '
        Me.FECHA.BackColor = System.Drawing.SystemColors.ButtonHighlight
        Me.FECHA.Font = New System.Drawing.Font("Microsoft Sans Serif", 18.0!, System.Drawing.FontStyle.Bold)
        Me.FECHA.ForeColor = System.Drawing.Color.Black
        Me.FECHA.Location = New System.Drawing.Point(1029, 58)
        Me.FECHA.Name = "FECHA"
        Me.FECHA.Size = New System.Drawing.Size(250, 39)
        Me.FECHA.TabIndex = 15
        Me.FECHA.Text = "24/11/2010"
        Me.FECHA.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'HORA
        '
        Me.HORA.BackColor = System.Drawing.SystemColors.ButtonHighlight
        Me.HORA.Font = New System.Drawing.Font("Microsoft Sans Serif", 18.0!, System.Drawing.FontStyle.Bold)
        Me.HORA.ForeColor = System.Drawing.Color.Black
        Me.HORA.Location = New System.Drawing.Point(1080, 97)
        Me.HORA.Name = "HORA"
        Me.HORA.Size = New System.Drawing.Size(149, 25)
        Me.HORA.TabIndex = 16
        Me.HORA.Text = "12:00:00"
        Me.HORA.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'Panel2
        '
        Me.Panel2.BackColor = System.Drawing.SystemColors.ButtonHighlight
        Me.Panel2.Location = New System.Drawing.Point(731, 1)
        Me.Panel2.Name = "Panel2"
        Me.Panel2.Size = New System.Drawing.Size(290, 22)
        Me.Panel2.TabIndex = 17
        '
        'TimerMain
        '
        Me.TimerMain.Interval = 10000
        '
        'Timer4
        '
        Me.Timer4.Enabled = True
        Me.Timer4.Interval = 1000
        '
        'MenuStrip1
        '
        Me.MenuStrip1.Items.AddRange(New System.Windows.Forms.ToolStripItem() {Me.MantenimientoToolStripMenuItem, Me.AcercaDeToolStripMenuItem})
        Me.MenuStrip1.Location = New System.Drawing.Point(0, 0)
        Me.MenuStrip1.Name = "MenuStrip1"
        Me.MenuStrip1.Size = New System.Drawing.Size(1237, 24)
        Me.MenuStrip1.TabIndex = 18
        Me.MenuStrip1.Text = "MenuStrip1"
        '
        'MantenimientoToolStripMenuItem
        '
        Me.MantenimientoToolStripMenuItem.DropDownItems.AddRange(New System.Windows.Forms.ToolStripItem() {Me.AjustesToolStripMenuItem})
        Me.MantenimientoToolStripMenuItem.Name = "MantenimientoToolStripMenuItem"
        Me.MantenimientoToolStripMenuItem.Size = New System.Drawing.Size(101, 20)
        Me.MantenimientoToolStripMenuItem.Text = "Mantenimiento"
        '
        'AjustesToolStripMenuItem
        '
        Me.AjustesToolStripMenuItem.Name = "AjustesToolStripMenuItem"
        Me.AjustesToolStripMenuItem.Size = New System.Drawing.Size(112, 22)
        Me.AjustesToolStripMenuItem.Text = "Ajustes"
        '
        'AcercaDeToolStripMenuItem
        '
        Me.AcercaDeToolStripMenuItem.Name = "AcercaDeToolStripMenuItem"
        Me.AcercaDeToolStripMenuItem.Size = New System.Drawing.Size(80, 20)
        Me.AcercaDeToolStripMenuItem.Text = "Acerca de..."
        '
        'TmrDbToFile
        '
        Me.TmrDbToFile.Enabled = True
        Me.TmrDbToFile.Interval = 60000
        '
        'tpEstacion1
        '
        Me.tpEstacion1.Controls.Add(Me.PE6TS)
        Me.tpEstacion1.Controls.Add(Me.PV6TS)
        Me.tpEstacion1.Controls.Add(Me.PA6TS)
        Me.tpEstacion1.Controls.Add(Me.Label66)
        Me.tpEstacion1.Controls.Add(Me.LPE6S)
        Me.tpEstacion1.Controls.Add(Me.LPV6S)
        Me.tpEstacion1.Controls.Add(Me.LPA6S)
        Me.tpEstacion1.Controls.Add(Me.Label6)
        Me.tpEstacion1.Controls.Add(Me.GridChangeTool)
        Me.tpEstacion1.Controls.Add(Me.btnRevisarE1)
        Me.tpEstacion1.Controls.Add(Me.BtnRepTool)
        Me.tpEstacion1.Controls.Add(Me.Label73)
        Me.tpEstacion1.Controls.Add(Me.txtVidaE1)
        Me.tpEstacion1.Controls.Add(Me.txtUsoE1)
        Me.tpEstacion1.Controls.Add(Me.Label75)
        Me.tpEstacion1.Controls.Add(Me.txtEmplE1)
        Me.tpEstacion1.Controls.Add(Me.Label76)
        Me.tpEstacion1.Controls.Add(Me.Label77)
        Me.tpEstacion1.Controls.Add(Me.Label78)
        Me.tpEstacion1.Controls.Add(Me.txtTurnoE1)
        Me.tpEstacion1.Controls.Add(Me.txtLadoE1)
        Me.tpEstacion1.Controls.Add(Me.txtPrenE1)
        Me.tpEstacion1.Controls.Add(Me.txtLineaE1)
        Me.tpEstacion1.Controls.Add(Me.txtHoraE1)
        Me.tpEstacion1.Controls.Add(Me.txtFechE1)
        Me.tpEstacion1.Controls.Add(Me.txtTecE1)
        Me.tpEstacion1.Controls.Add(Me.txtLainaE1)
        Me.tpEstacion1.Controls.Add(Me.txtGreenE1)
        Me.tpEstacion1.Controls.Add(Me.txtAntE1)
        Me.tpEstacion1.Controls.Add(Me.Label79)
        Me.tpEstacion1.Controls.Add(Me.Label80)
        Me.tpEstacion1.Controls.Add(Me.Label81)
        Me.tpEstacion1.Controls.Add(Me.Label82)
        Me.tpEstacion1.Controls.Add(Me.Label83)
        Me.tpEstacion1.Controls.Add(Me.Label84)
        Me.tpEstacion1.Controls.Add(Me.Label85)
        Me.tpEstacion1.Controls.Add(Me.Label86)
        Me.tpEstacion1.Controls.Add(Me.Label87)
        Me.tpEstacion1.Controls.Add(Me.txtToolE1)
        Me.tpEstacion1.Controls.Add(Me.PE5TS)
        Me.tpEstacion1.Controls.Add(Me.PV5TS)
        Me.tpEstacion1.Controls.Add(Me.PA5TS)
        Me.tpEstacion1.Controls.Add(Me.PE4TS)
        Me.tpEstacion1.Controls.Add(Me.PV4TS)
        Me.tpEstacion1.Controls.Add(Me.PA4TS)
        Me.tpEstacion1.Controls.Add(Me.PE3TS)
        Me.tpEstacion1.Controls.Add(Me.PV3TS)
        Me.tpEstacion1.Controls.Add(Me.PA3TS)
        Me.tpEstacion1.Controls.Add(Me.PE2TS)
        Me.tpEstacion1.Controls.Add(Me.PV2TS)
        Me.tpEstacion1.Controls.Add(Me.PA2TS)
        Me.tpEstacion1.Controls.Add(Me.PE1TS)
        Me.tpEstacion1.Controls.Add(Me.PV1TS)
        Me.tpEstacion1.Controls.Add(Me.PA1TS)
        Me.tpEstacion1.Controls.Add(Me.Label45)
        Me.tpEstacion1.Controls.Add(Me.Label46)
        Me.tpEstacion1.Controls.Add(Me.LPA1S)
        Me.tpEstacion1.Controls.Add(Me.Label47)
        Me.tpEstacion1.Controls.Add(Me.Label48)
        Me.tpEstacion1.Controls.Add(Me.LPE4S)
        Me.tpEstacion1.Controls.Add(Me.LPE1S)
        Me.tpEstacion1.Controls.Add(Me.LPV5S)
        Me.tpEstacion1.Controls.Add(Me.LPE5S)
        Me.tpEstacion1.Controls.Add(Me.Label49)
        Me.tpEstacion1.Controls.Add(Me.LPV1S)
        Me.tpEstacion1.Controls.Add(Me.LPA5S)
        Me.tpEstacion1.Controls.Add(Me.LPA4S)
        Me.tpEstacion1.Controls.Add(Me.LPE2S)
        Me.tpEstacion1.Controls.Add(Me.LPV2S)
        Me.tpEstacion1.Controls.Add(Me.LPA2S)
        Me.tpEstacion1.Controls.Add(Me.LPV3S)
        Me.tpEstacion1.Controls.Add(Me.LPA3S)
        Me.tpEstacion1.Controls.Add(Me.LPE3S)
        Me.tpEstacion1.Controls.Add(Me.LPV4S)
        Me.tpEstacion1.Location = New System.Drawing.Point(4, 23)
        Me.tpEstacion1.Name = "tpEstacion1"
        Me.tpEstacion1.Padding = New System.Windows.Forms.Padding(3)
        Me.tpEstacion1.Size = New System.Drawing.Size(1237, 683)
        Me.tpEstacion1.TabIndex = 5
        Me.tpEstacion1.Text = "Estacion1"
        Me.tpEstacion1.UseVisualStyleBackColor = True
        '
        'PE6TS
        '
        Me.PE6TS.AutoSize = True
        Me.PE6TS.Font = New System.Drawing.Font("Arial", 6.75!)
        Me.PE6TS.ImeMode = System.Windows.Forms.ImeMode.NoControl
        Me.PE6TS.Location = New System.Drawing.Point(303, 513)
        Me.PE6TS.Name = "PE6TS"
        Me.PE6TS.Size = New System.Drawing.Size(15, 12)
        Me.PE6TS.TabIndex = 175
        Me.PE6TS.Text = "TT"
        Me.PE6TS.Visible = False
        '
        'PV6TS
        '
        Me.PV6TS.AutoSize = True
        Me.PV6TS.Font = New System.Drawing.Font("Arial", 6.75!)
        Me.PV6TS.ImeMode = System.Windows.Forms.ImeMode.NoControl
        Me.PV6TS.Location = New System.Drawing.Point(179, 516)
        Me.PV6TS.Name = "PV6TS"
        Me.PV6TS.Size = New System.Drawing.Size(15, 12)
        Me.PV6TS.TabIndex = 174
        Me.PV6TS.Text = "TT"
        '
        'PA6TS
        '
        Me.PA6TS.AutoSize = True
        Me.PA6TS.Font = New System.Drawing.Font("Arial", 6.75!)
        Me.PA6TS.ImeMode = System.Windows.Forms.ImeMode.NoControl
        Me.PA6TS.Location = New System.Drawing.Point(60, 516)
        Me.PA6TS.Name = "PA6TS"
        Me.PA6TS.Size = New System.Drawing.Size(15, 12)
        Me.PA6TS.TabIndex = 173
        Me.PA6TS.Text = "TT"
        '
        'Label66
        '
        Me.Label66.AutoSize = True
        Me.Label66.Font = New System.Drawing.Font("Arial", 20.25!, System.Drawing.FontStyle.Bold)
        Me.Label66.ImeMode = System.Windows.Forms.ImeMode.NoControl
        Me.Label66.Location = New System.Drawing.Point(8, 483)
        Me.Label66.Name = "Label66"
        Me.Label66.Size = New System.Drawing.Size(47, 32)
        Me.Label66.TabIndex = 172
        Me.Label66.Text = "L6"
        '
        'LPE6S
        '
        Me.LPE6S.BackColor = System.Drawing.Color.Red
        Me.LPE6S.Font = New System.Drawing.Font("Arial", 14.25!)
        Me.LPE6S.ImeMode = System.Windows.Forms.ImeMode.NoControl
        Me.LPE6S.Location = New System.Drawing.Point(290, 464)
        Me.LPE6S.Name = "LPE6S"
        Me.LPE6S.Size = New System.Drawing.Size(90, 75)
        Me.LPE6S.TabIndex = 171
        Me.LPE6S.Text = "PE6"
        Me.LPE6S.UseVisualStyleBackColor = False
        Me.LPE6S.Visible = False
        '
        'LPV6S
        '
        Me.LPV6S.BackColor = System.Drawing.Color.DodgerBlue
        Me.LPV6S.Font = New System.Drawing.Font("Arial", 14.25!)
        Me.LPV6S.ImeMode = System.Windows.Forms.ImeMode.NoControl
        Me.LPV6S.Location = New System.Drawing.Point(170, 464)
        Me.LPV6S.Name = "LPV6S"
        Me.LPV6S.Size = New System.Drawing.Size(90, 75)
        Me.LPV6S.TabIndex = 169
        Me.LPV6S.Text = "PV6"
        Me.LPV6S.UseVisualStyleBackColor = False
        '
        'LPA6S
        '
        Me.LPA6S.BackColor = System.Drawing.Color.Green
        Me.LPA6S.Font = New System.Drawing.Font("Arial", 14.25!)
        Me.LPA6S.ImeMode = System.Windows.Forms.ImeMode.NoControl
        Me.LPA6S.Location = New System.Drawing.Point(54, 464)
        Me.LPA6S.Name = "LPA6S"
        Me.LPA6S.Size = New System.Drawing.Size(90, 75)
        Me.LPA6S.TabIndex = 170
        Me.LPA6S.Text = "PA6"
        Me.LPA6S.UseVisualStyleBackColor = False
        '
        'Label6
        '
        Me.Label6.BackColor = System.Drawing.SystemColors.ButtonHighlight
        Me.Label6.Font = New System.Drawing.Font("Microsoft Sans Serif", 18.0!, System.Drawing.FontStyle.Bold)
        Me.Label6.ForeColor = System.Drawing.Color.Black
        Me.Label6.Location = New System.Drawing.Point(788, 293)
        Me.Label6.Name = "Label6"
        Me.Label6.Size = New System.Drawing.Size(382, 25)
        Me.Label6.TabIndex = 168
        Me.Label6.Text = "CAMBIOS SOLICITADO"
        Me.Label6.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'GridChangeTool
        '
        Me.GridChangeTool.AllowUserToAddRows = False
        Me.GridChangeTool.AllowUserToDeleteRows = False
        Me.GridChangeTool.AllowUserToResizeColumns = False
        Me.GridChangeTool.AllowUserToResizeRows = False
        Me.GridChangeTool.BorderStyle = System.Windows.Forms.BorderStyle.None
        Me.GridChangeTool.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize
        Me.GridChangeTool.Location = New System.Drawing.Point(385, 330)
        Me.GridChangeTool.MultiSelect = False
        Me.GridChangeTool.Name = "GridChangeTool"
        Me.GridChangeTool.ReadOnly = True
        Me.GridChangeTool.RowHeadersVisible = False
        Me.GridChangeTool.RowHeadersWidth = 10
        DataGridViewCellStyle4.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.GridChangeTool.RowsDefaultCellStyle = DataGridViewCellStyle4
        Me.GridChangeTool.RowTemplate.Height = 25
        Me.GridChangeTool.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.FullRowSelect
        Me.GridChangeTool.Size = New System.Drawing.Size(737, 290)
        Me.GridChangeTool.TabIndex = 167
        '
        'btnRevisarE1
        '
        Me.btnRevisarE1.Font = New System.Drawing.Font("Arial", 20.25!, System.Drawing.FontStyle.Bold)
        Me.btnRevisarE1.Location = New System.Drawing.Point(14, 558)
        Me.btnRevisarE1.Name = "btnRevisarE1"
        Me.btnRevisarE1.Size = New System.Drawing.Size(161, 62)
        Me.btnRevisarE1.TabIndex = 165
        Me.btnRevisarE1.Text = "REVISAR"
        '
        'BtnRepTool
        '
        Me.BtnRepTool.Font = New System.Drawing.Font("Arial", 20.25!, System.Drawing.FontStyle.Bold)
        Me.BtnRepTool.Location = New System.Drawing.Point(213, 556)
        Me.BtnRepTool.Name = "BtnRepTool"
        Me.BtnRepTool.Size = New System.Drawing.Size(167, 64)
        Me.BtnRepTool.TabIndex = 164
        Me.BtnRepTool.Text = "REPARAR"
        '
        'Label73
        '
        Me.Label73.AutoSize = True
        Me.Label73.Font = New System.Drawing.Font("Arial", 9.75!, System.Drawing.FontStyle.Bold)
        Me.Label73.ImeMode = System.Windows.Forms.ImeMode.NoControl
        Me.Label73.Location = New System.Drawing.Point(544, 183)
        Me.Label73.Name = "Label73"
        Me.Label73.Size = New System.Drawing.Size(72, 16)
        Me.Label73.TabIndex = 163
        Me.Label73.Text = "VIDA UTIL"
        Me.Label73.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'txtVidaE1
        '
        Me.txtVidaE1.Font = New System.Drawing.Font("Microsoft Sans Serif", 15.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.txtVidaE1.ForeColor = System.Drawing.Color.Black
        Me.txtVidaE1.Location = New System.Drawing.Point(547, 208)
        Me.txtVidaE1.Name = "txtVidaE1"
        Me.txtVidaE1.Size = New System.Drawing.Size(100, 31)
        Me.txtVidaE1.TabIndex = 162
        '
        'txtUsoE1
        '
        Me.txtUsoE1.Font = New System.Drawing.Font("Microsoft Sans Serif", 15.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.txtUsoE1.ForeColor = System.Drawing.Color.Black
        Me.txtUsoE1.Location = New System.Drawing.Point(653, 207)
        Me.txtUsoE1.Name = "txtUsoE1"
        Me.txtUsoE1.Size = New System.Drawing.Size(173, 31)
        Me.txtUsoE1.TabIndex = 160
        '
        'Label75
        '
        Me.Label75.AutoSize = True
        Me.Label75.Font = New System.Drawing.Font("Arial", 9.75!, System.Drawing.FontStyle.Bold)
        Me.Label75.ImeMode = System.Windows.Forms.ImeMode.NoControl
        Me.Label75.Location = New System.Drawing.Point(655, 187)
        Me.Label75.Name = "Label75"
        Me.Label75.Size = New System.Drawing.Size(111, 16)
        Me.Label75.TabIndex = 159
        Me.Label75.Text = "TIEMPO DE USO"
        '
        'txtEmplE1
        '
        Me.txtEmplE1.Font = New System.Drawing.Font("Microsoft Sans Serif", 15.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.txtEmplE1.ForeColor = System.Drawing.Color.Black
        Me.txtEmplE1.Location = New System.Drawing.Point(386, 27)
        Me.txtEmplE1.Name = "txtEmplE1"
        Me.txtEmplE1.Size = New System.Drawing.Size(155, 31)
        Me.txtEmplE1.TabIndex = 158
        '
        'Label76
        '
        Me.Label76.AutoSize = True
        Me.Label76.Font = New System.Drawing.Font("Arial", 9.75!, System.Drawing.FontStyle.Bold)
        Me.Label76.ImeMode = System.Windows.Forms.ImeMode.NoControl
        Me.Label76.Location = New System.Drawing.Point(386, 8)
        Me.Label76.Name = "Label76"
        Me.Label76.Size = New System.Drawing.Size(113, 16)
        Me.Label76.TabIndex = 157
        Me.Label76.Text = "NUM EMPLEADO"
        '
        'Label77
        '
        Me.Label77.AutoSize = True
        Me.Label77.Font = New System.Drawing.Font("Arial", 9.75!, System.Drawing.FontStyle.Bold)
        Me.Label77.ImeMode = System.Windows.Forms.ImeMode.NoControl
        Me.Label77.Location = New System.Drawing.Point(544, 8)
        Me.Label77.Name = "Label77"
        Me.Label77.Size = New System.Drawing.Size(113, 16)
        Me.Label77.TabIndex = 156
        Me.Label77.Text = "TEC/AUX -MTTO."
        '
        'Label78
        '
        Me.Label78.AutoSize = True
        Me.Label78.Font = New System.Drawing.Font("Arial", 9.75!, System.Drawing.FontStyle.Bold)
        Me.Label78.ImeMode = System.Windows.Forms.ImeMode.NoControl
        Me.Label78.Location = New System.Drawing.Point(664, 258)
        Me.Label78.Name = "Label78"
        Me.Label78.Size = New System.Drawing.Size(132, 16)
        Me.Label78.TabIndex = 155
        Me.Label78.Text = "LAINA (DIMENSION)"
        '
        'txtTurnoE1
        '
        Me.txtTurnoE1.Font = New System.Drawing.Font("Microsoft Sans Serif", 15.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.txtTurnoE1.ForeColor = System.Drawing.Color.Black
        Me.txtTurnoE1.Location = New System.Drawing.Point(759, 149)
        Me.txtTurnoE1.Name = "txtTurnoE1"
        Me.txtTurnoE1.Size = New System.Drawing.Size(67, 31)
        Me.txtTurnoE1.TabIndex = 154
        '
        'txtLadoE1
        '
        Me.txtLadoE1.Font = New System.Drawing.Font("Microsoft Sans Serif", 15.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.txtLadoE1.ForeColor = System.Drawing.Color.Black
        Me.txtLadoE1.Location = New System.Drawing.Point(685, 86)
        Me.txtLadoE1.Name = "txtLadoE1"
        Me.txtLadoE1.Size = New System.Drawing.Size(100, 31)
        Me.txtLadoE1.TabIndex = 153
        '
        'txtPrenE1
        '
        Me.txtPrenE1.Font = New System.Drawing.Font("Microsoft Sans Serif", 15.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.txtPrenE1.ForeColor = System.Drawing.Color.Black
        Me.txtPrenE1.Location = New System.Drawing.Point(547, 86)
        Me.txtPrenE1.Name = "txtPrenE1"
        Me.txtPrenE1.Size = New System.Drawing.Size(120, 31)
        Me.txtPrenE1.TabIndex = 152
        '
        'txtLineaE1
        '
        Me.txtLineaE1.CausesValidation = False
        Me.txtLineaE1.Font = New System.Drawing.Font("Microsoft Sans Serif", 15.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.txtLineaE1.ForeColor = System.Drawing.Color.Black
        Me.txtLineaE1.Location = New System.Drawing.Point(389, 86)
        Me.txtLineaE1.Name = "txtLineaE1"
        Me.txtLineaE1.Size = New System.Drawing.Size(100, 31)
        Me.txtLineaE1.TabIndex = 151
        '
        'txtHoraE1
        '
        Me.txtHoraE1.Font = New System.Drawing.Font("Microsoft Sans Serif", 15.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.txtHoraE1.ForeColor = System.Drawing.Color.Black
        Me.txtHoraE1.Location = New System.Drawing.Point(385, 149)
        Me.txtHoraE1.Name = "txtHoraE1"
        Me.txtHoraE1.Size = New System.Drawing.Size(169, 31)
        Me.txtHoraE1.TabIndex = 150
        '
        'txtFechE1
        '
        Me.txtFechE1.Font = New System.Drawing.Font("Microsoft Sans Serif", 15.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.txtFechE1.ForeColor = System.Drawing.Color.Black
        Me.txtFechE1.Location = New System.Drawing.Point(560, 149)
        Me.txtFechE1.Name = "txtFechE1"
        Me.txtFechE1.Size = New System.Drawing.Size(193, 31)
        Me.txtFechE1.TabIndex = 149
        '
        'txtTecE1
        '
        Me.txtTecE1.Font = New System.Drawing.Font("Microsoft Sans Serif", 15.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.txtTecE1.ForeColor = System.Drawing.Color.Black
        Me.txtTecE1.Location = New System.Drawing.Point(547, 27)
        Me.txtTecE1.Name = "txtTecE1"
        Me.txtTecE1.Size = New System.Drawing.Size(167, 31)
        Me.txtTecE1.TabIndex = 148
        '
        'txtLainaE1
        '
        Me.txtLainaE1.Font = New System.Drawing.Font("Microsoft Sans Serif", 15.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.txtLainaE1.ForeColor = System.Drawing.Color.Black
        Me.txtLainaE1.Location = New System.Drawing.Point(653, 286)
        Me.txtLainaE1.Name = "txtLainaE1"
        Me.txtLainaE1.Size = New System.Drawing.Size(129, 31)
        Me.txtLainaE1.TabIndex = 147
        '
        'txtGreenE1
        '
        Me.txtGreenE1.Font = New System.Drawing.Font("Microsoft Sans Serif", 15.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.txtGreenE1.ForeColor = System.Drawing.Color.Black
        Me.txtGreenE1.Location = New System.Drawing.Point(516, 286)
        Me.txtGreenE1.Name = "txtGreenE1"
        Me.txtGreenE1.Size = New System.Drawing.Size(131, 31)
        Me.txtGreenE1.TabIndex = 146
        '
        'txtAntE1
        '
        Me.txtAntE1.Font = New System.Drawing.Font("Microsoft Sans Serif", 15.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.txtAntE1.ForeColor = System.Drawing.Color.Black
        Me.txtAntE1.Location = New System.Drawing.Point(383, 286)
        Me.txtAntE1.Name = "txtAntE1"
        Me.txtAntE1.Size = New System.Drawing.Size(127, 31)
        Me.txtAntE1.TabIndex = 145
        '
        'Label79
        '
        Me.Label79.AutoSize = True
        Me.Label79.Font = New System.Drawing.Font("Arial", 9.75!, System.Drawing.FontStyle.Bold)
        Me.Label79.ImeMode = System.Windows.Forms.ImeMode.NoControl
        Me.Label79.Location = New System.Drawing.Point(388, 67)
        Me.Label79.Name = "Label79"
        Me.Label79.Size = New System.Drawing.Size(46, 16)
        Me.Label79.TabIndex = 144
        Me.Label79.Text = "LINEA"
        '
        'Label80
        '
        Me.Label80.AutoSize = True
        Me.Label80.Font = New System.Drawing.Font("Arial", 9.75!, System.Drawing.FontStyle.Bold)
        Me.Label80.ImeMode = System.Windows.Forms.ImeMode.NoControl
        Me.Label80.Location = New System.Drawing.Point(525, 258)
        Me.Label80.Name = "Label80"
        Me.Label80.Size = New System.Drawing.Size(97, 16)
        Me.Label80.TabIndex = 143
        Me.Label80.Text = "GREEN PLATE"
        '
        'Label81
        '
        Me.Label81.AutoSize = True
        Me.Label81.Font = New System.Drawing.Font("Arial", 9.75!, System.Drawing.FontStyle.Bold)
        Me.Label81.ImeMode = System.Windows.Forms.ImeMode.NoControl
        Me.Label81.Location = New System.Drawing.Point(390, 258)
        Me.Label81.Name = "Label81"
        Me.Label81.Size = New System.Drawing.Size(104, 16)
        Me.Label81.TabIndex = 142
        Me.Label81.Text = "TOOLING. ANT."
        '
        'Label82
        '
        Me.Label82.AutoSize = True
        Me.Label82.Font = New System.Drawing.Font("Arial", 9.75!, System.Drawing.FontStyle.Bold)
        Me.Label82.ImeMode = System.Windows.Forms.ImeMode.NoControl
        Me.Label82.Location = New System.Drawing.Point(385, 187)
        Me.Label82.Name = "Label82"
        Me.Label82.Size = New System.Drawing.Size(67, 16)
        Me.Label82.TabIndex = 141
        Me.Label82.Text = "TOOLING"
        '
        'Label83
        '
        Me.Label83.AutoSize = True
        Me.Label83.Font = New System.Drawing.Font("Arial", 9.75!, System.Drawing.FontStyle.Bold)
        Me.Label83.ImeMode = System.Windows.Forms.ImeMode.NoControl
        Me.Label83.Location = New System.Drawing.Point(756, 129)
        Me.Label83.Name = "Label83"
        Me.Label83.Size = New System.Drawing.Size(53, 16)
        Me.Label83.TabIndex = 140
        Me.Label83.Text = "TURNO"
        '
        'Label84
        '
        Me.Label84.AutoSize = True
        Me.Label84.Font = New System.Drawing.Font("Arial", 9.75!, System.Drawing.FontStyle.Bold)
        Me.Label84.ImeMode = System.Windows.Forms.ImeMode.NoControl
        Me.Label84.Location = New System.Drawing.Point(388, 129)
        Me.Label84.Name = "Label84"
        Me.Label84.Size = New System.Drawing.Size(45, 16)
        Me.Label84.TabIndex = 139
        Me.Label84.Text = "HORA"
        '
        'Label85
        '
        Me.Label85.AutoSize = True
        Me.Label85.Font = New System.Drawing.Font("Arial", 9.75!, System.Drawing.FontStyle.Bold)
        Me.Label85.ImeMode = System.Windows.Forms.ImeMode.NoControl
        Me.Label85.Location = New System.Drawing.Point(575, 129)
        Me.Label85.Name = "Label85"
        Me.Label85.Size = New System.Drawing.Size(51, 16)
        Me.Label85.TabIndex = 138
        Me.Label85.Text = "FECHA"
        '
        'Label86
        '
        Me.Label86.AutoSize = True
        Me.Label86.Font = New System.Drawing.Font("Arial", 9.75!, System.Drawing.FontStyle.Bold)
        Me.Label86.ImeMode = System.Windows.Forms.ImeMode.NoControl
        Me.Label86.Location = New System.Drawing.Point(685, 67)
        Me.Label86.Name = "Label86"
        Me.Label86.Size = New System.Drawing.Size(44, 16)
        Me.Label86.TabIndex = 137
        Me.Label86.Text = "LADO"
        '
        'Label87
        '
        Me.Label87.AutoSize = True
        Me.Label87.Font = New System.Drawing.Font("Arial", 9.75!, System.Drawing.FontStyle.Bold)
        Me.Label87.ImeMode = System.Windows.Forms.ImeMode.NoControl
        Me.Label87.Location = New System.Drawing.Point(552, 67)
        Me.Label87.Name = "Label87"
        Me.Label87.Size = New System.Drawing.Size(61, 16)
        Me.Label87.TabIndex = 136
        Me.Label87.Text = "PRENSA"
        '
        'txtToolE1
        '
        Me.txtToolE1.Font = New System.Drawing.Font("Microsoft Sans Serif", 15.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.txtToolE1.ForeColor = System.Drawing.Color.Black
        Me.txtToolE1.Location = New System.Drawing.Point(386, 207)
        Me.txtToolE1.Name = "txtToolE1"
        Me.txtToolE1.Size = New System.Drawing.Size(155, 31)
        Me.txtToolE1.TabIndex = 135
        '
        'PE5TS
        '
        Me.PE5TS.AutoSize = True
        Me.PE5TS.Font = New System.Drawing.Font("Arial", 6.75!)
        Me.PE5TS.ImeMode = System.Windows.Forms.ImeMode.NoControl
        Me.PE5TS.Location = New System.Drawing.Point(308, 424)
        Me.PE5TS.Name = "PE5TS"
        Me.PE5TS.Size = New System.Drawing.Size(15, 12)
        Me.PE5TS.TabIndex = 134
        Me.PE5TS.Text = "TT"
        Me.PE5TS.Visible = False
        '
        'PV5TS
        '
        Me.PV5TS.AutoSize = True
        Me.PV5TS.Font = New System.Drawing.Font("Arial", 6.75!)
        Me.PV5TS.ImeMode = System.Windows.Forms.ImeMode.NoControl
        Me.PV5TS.Location = New System.Drawing.Point(182, 424)
        Me.PV5TS.Name = "PV5TS"
        Me.PV5TS.Size = New System.Drawing.Size(15, 12)
        Me.PV5TS.TabIndex = 133
        Me.PV5TS.Text = "TT"
        '
        'PA5TS
        '
        Me.PA5TS.AutoSize = True
        Me.PA5TS.Font = New System.Drawing.Font("Arial", 6.75!)
        Me.PA5TS.ImeMode = System.Windows.Forms.ImeMode.NoControl
        Me.PA5TS.Location = New System.Drawing.Point(69, 424)
        Me.PA5TS.Name = "PA5TS"
        Me.PA5TS.Size = New System.Drawing.Size(15, 12)
        Me.PA5TS.TabIndex = 132
        Me.PA5TS.Text = "TT"
        '
        'PE4TS
        '
        Me.PE4TS.AutoSize = True
        Me.PE4TS.Font = New System.Drawing.Font("Arial", 6.75!)
        Me.PE4TS.ImeMode = System.Windows.Forms.ImeMode.NoControl
        Me.PE4TS.Location = New System.Drawing.Point(311, 330)
        Me.PE4TS.Name = "PE4TS"
        Me.PE4TS.Size = New System.Drawing.Size(15, 12)
        Me.PE4TS.TabIndex = 131
        Me.PE4TS.Text = "TT"
        Me.PE4TS.Visible = False
        '
        'PV4TS
        '
        Me.PV4TS.AutoSize = True
        Me.PV4TS.Font = New System.Drawing.Font("Arial", 6.75!)
        Me.PV4TS.ImeMode = System.Windows.Forms.ImeMode.NoControl
        Me.PV4TS.Location = New System.Drawing.Point(196, 330)
        Me.PV4TS.Name = "PV4TS"
        Me.PV4TS.Size = New System.Drawing.Size(15, 12)
        Me.PV4TS.TabIndex = 130
        Me.PV4TS.Text = "TT"
        '
        'PA4TS
        '
        Me.PA4TS.AutoSize = True
        Me.PA4TS.Font = New System.Drawing.Font("Arial", 6.75!)
        Me.PA4TS.ImeMode = System.Windows.Forms.ImeMode.NoControl
        Me.PA4TS.Location = New System.Drawing.Point(79, 330)
        Me.PA4TS.Name = "PA4TS"
        Me.PA4TS.Size = New System.Drawing.Size(15, 12)
        Me.PA4TS.TabIndex = 129
        Me.PA4TS.Text = "TT"
        '
        'PE3TS
        '
        Me.PE3TS.AutoSize = True
        Me.PE3TS.Font = New System.Drawing.Font("Arial", 6.75!)
        Me.PE3TS.ImeMode = System.Windows.Forms.ImeMode.NoControl
        Me.PE3TS.Location = New System.Drawing.Point(299, 241)
        Me.PE3TS.Name = "PE3TS"
        Me.PE3TS.Size = New System.Drawing.Size(15, 12)
        Me.PE3TS.TabIndex = 128
        Me.PE3TS.Text = "TT"
        Me.PE3TS.Visible = False
        '
        'PV3TS
        '
        Me.PV3TS.AutoSize = True
        Me.PV3TS.Font = New System.Drawing.Font("Arial", 6.75!)
        Me.PV3TS.ImeMode = System.Windows.Forms.ImeMode.NoControl
        Me.PV3TS.Location = New System.Drawing.Point(184, 241)
        Me.PV3TS.Name = "PV3TS"
        Me.PV3TS.Size = New System.Drawing.Size(15, 12)
        Me.PV3TS.TabIndex = 127
        Me.PV3TS.Text = "TT"
        '
        'PA3TS
        '
        Me.PA3TS.AutoSize = True
        Me.PA3TS.Font = New System.Drawing.Font("Arial", 6.75!)
        Me.PA3TS.ImeMode = System.Windows.Forms.ImeMode.NoControl
        Me.PA3TS.Location = New System.Drawing.Point(69, 241)
        Me.PA3TS.Name = "PA3TS"
        Me.PA3TS.Size = New System.Drawing.Size(15, 12)
        Me.PA3TS.TabIndex = 126
        Me.PA3TS.Text = "TT"
        '
        'PE2TS
        '
        Me.PE2TS.AutoSize = True
        Me.PE2TS.Font = New System.Drawing.Font("Arial", 6.75!)
        Me.PE2TS.ImeMode = System.Windows.Forms.ImeMode.NoControl
        Me.PE2TS.Location = New System.Drawing.Point(299, 149)
        Me.PE2TS.Name = "PE2TS"
        Me.PE2TS.Size = New System.Drawing.Size(15, 12)
        Me.PE2TS.TabIndex = 125
        Me.PE2TS.Text = "TT"
        Me.PE2TS.Visible = False
        '
        'PV2TS
        '
        Me.PV2TS.AutoSize = True
        Me.PV2TS.Font = New System.Drawing.Font("Arial", 6.75!)
        Me.PV2TS.ImeMode = System.Windows.Forms.ImeMode.NoControl
        Me.PV2TS.Location = New System.Drawing.Point(184, 149)
        Me.PV2TS.Name = "PV2TS"
        Me.PV2TS.Size = New System.Drawing.Size(15, 12)
        Me.PV2TS.TabIndex = 124
        Me.PV2TS.Text = "TT"
        '
        'PA2TS
        '
        Me.PA2TS.AutoSize = True
        Me.PA2TS.Font = New System.Drawing.Font("Arial", 6.75!)
        Me.PA2TS.ImeMode = System.Windows.Forms.ImeMode.NoControl
        Me.PA2TS.Location = New System.Drawing.Point(68, 149)
        Me.PA2TS.Name = "PA2TS"
        Me.PA2TS.Size = New System.Drawing.Size(15, 12)
        Me.PA2TS.TabIndex = 123
        Me.PA2TS.Text = "TT"
        '
        'PE1TS
        '
        Me.PE1TS.AutoSize = True
        Me.PE1TS.Font = New System.Drawing.Font("Arial", 6.75!)
        Me.PE1TS.ImeMode = System.Windows.Forms.ImeMode.NoControl
        Me.PE1TS.Location = New System.Drawing.Point(300, 60)
        Me.PE1TS.Name = "PE1TS"
        Me.PE1TS.Size = New System.Drawing.Size(15, 12)
        Me.PE1TS.TabIndex = 122
        Me.PE1TS.Text = "TT"
        Me.PE1TS.Visible = False
        '
        'PV1TS
        '
        Me.PV1TS.AutoSize = True
        Me.PV1TS.Font = New System.Drawing.Font("Arial", 6.75!)
        Me.PV1TS.ImeMode = System.Windows.Forms.ImeMode.NoControl
        Me.PV1TS.Location = New System.Drawing.Point(185, 60)
        Me.PV1TS.Name = "PV1TS"
        Me.PV1TS.Size = New System.Drawing.Size(15, 12)
        Me.PV1TS.TabIndex = 121
        Me.PV1TS.Text = "TT"
        '
        'PA1TS
        '
        Me.PA1TS.AutoSize = True
        Me.PA1TS.Font = New System.Drawing.Font("Arial", 6.75!)
        Me.PA1TS.ImeMode = System.Windows.Forms.ImeMode.NoControl
        Me.PA1TS.Location = New System.Drawing.Point(69, 60)
        Me.PA1TS.Name = "PA1TS"
        Me.PA1TS.Size = New System.Drawing.Size(15, 12)
        Me.PA1TS.TabIndex = 120
        Me.PA1TS.Text = "TT"
        '
        'Label45
        '
        Me.Label45.AutoSize = True
        Me.Label45.Font = New System.Drawing.Font("Arial", 20.25!, System.Drawing.FontStyle.Bold)
        Me.Label45.ImeMode = System.Windows.Forms.ImeMode.NoControl
        Me.Label45.Location = New System.Drawing.Point(8, 36)
        Me.Label45.Name = "Label45"
        Me.Label45.Size = New System.Drawing.Size(47, 32)
        Me.Label45.TabIndex = 115
        Me.Label45.Text = "L1"
        '
        'Label46
        '
        Me.Label46.AutoSize = True
        Me.Label46.Font = New System.Drawing.Font("Arial", 20.25!, System.Drawing.FontStyle.Bold)
        Me.Label46.ImeMode = System.Windows.Forms.ImeMode.NoControl
        Me.Label46.Location = New System.Drawing.Point(8, 113)
        Me.Label46.Name = "Label46"
        Me.Label46.Size = New System.Drawing.Size(47, 32)
        Me.Label46.TabIndex = 116
        Me.Label46.Text = "L2"
        '
        'LPA1S
        '
        Me.LPA1S.BackColor = System.Drawing.Color.Green
        Me.LPA1S.Font = New System.Drawing.Font("Arial", 14.25!)
        Me.LPA1S.ImeMode = System.Windows.Forms.ImeMode.NoControl
        Me.LPA1S.Location = New System.Drawing.Point(58, 8)
        Me.LPA1S.Name = "LPA1S"
        Me.LPA1S.Size = New System.Drawing.Size(90, 75)
        Me.LPA1S.TabIndex = 100
        Me.LPA1S.Text = "PA1"
        Me.LPA1S.UseVisualStyleBackColor = False
        '
        'Label47
        '
        Me.Label47.AutoSize = True
        Me.Label47.Font = New System.Drawing.Font("Arial", 20.25!, System.Drawing.FontStyle.Bold)
        Me.Label47.ImeMode = System.Windows.Forms.ImeMode.NoControl
        Me.Label47.Location = New System.Drawing.Point(8, 389)
        Me.Label47.Name = "Label47"
        Me.Label47.Size = New System.Drawing.Size(47, 32)
        Me.Label47.TabIndex = 119
        Me.Label47.Text = "L5"
        '
        'Label48
        '
        Me.Label48.AutoSize = True
        Me.Label48.Font = New System.Drawing.Font("Arial", 20.25!, System.Drawing.FontStyle.Bold)
        Me.Label48.ImeMode = System.Windows.Forms.ImeMode.NoControl
        Me.Label48.Location = New System.Drawing.Point(8, 298)
        Me.Label48.Name = "Label48"
        Me.Label48.Size = New System.Drawing.Size(47, 32)
        Me.Label48.TabIndex = 118
        Me.Label48.Text = "L4"
        '
        'LPE4S
        '
        Me.LPE4S.BackColor = System.Drawing.Color.Green
        Me.LPE4S.Font = New System.Drawing.Font("Arial", 14.25!)
        Me.LPE4S.ImeMode = System.Windows.Forms.ImeMode.NoControl
        Me.LPE4S.Location = New System.Drawing.Point(290, 278)
        Me.LPE4S.Name = "LPE4S"
        Me.LPE4S.Size = New System.Drawing.Size(90, 75)
        Me.LPE4S.TabIndex = 111
        Me.LPE4S.Text = "PE4"
        Me.LPE4S.UseVisualStyleBackColor = False
        Me.LPE4S.Visible = False
        '
        'LPE1S
        '
        Me.LPE1S.BackColor = System.Drawing.Color.DodgerBlue
        Me.LPE1S.Font = New System.Drawing.Font("Arial", 14.25!)
        Me.LPE1S.ImeMode = System.Windows.Forms.ImeMode.NoControl
        Me.LPE1S.Location = New System.Drawing.Point(290, 8)
        Me.LPE1S.Name = "LPE1S"
        Me.LPE1S.Size = New System.Drawing.Size(90, 75)
        Me.LPE1S.TabIndex = 102
        Me.LPE1S.Text = "PE1"
        Me.LPE1S.UseVisualStyleBackColor = False
        Me.LPE1S.Visible = False
        '
        'LPV5S
        '
        Me.LPV5S.BackColor = System.Drawing.Color.DodgerBlue
        Me.LPV5S.Font = New System.Drawing.Font("Arial", 14.25!)
        Me.LPV5S.ImeMode = System.Windows.Forms.ImeMode.NoControl
        Me.LPV5S.Location = New System.Drawing.Point(174, 370)
        Me.LPV5S.Name = "LPV5S"
        Me.LPV5S.Size = New System.Drawing.Size(90, 75)
        Me.LPV5S.TabIndex = 114
        Me.LPV5S.Text = "PV5"
        Me.LPV5S.UseVisualStyleBackColor = False
        '
        'LPE5S
        '
        Me.LPE5S.BackColor = System.Drawing.Color.Red
        Me.LPE5S.Font = New System.Drawing.Font("Arial", 14.25!)
        Me.LPE5S.ImeMode = System.Windows.Forms.ImeMode.NoControl
        Me.LPE5S.Location = New System.Drawing.Point(290, 370)
        Me.LPE5S.Name = "LPE5S"
        Me.LPE5S.Size = New System.Drawing.Size(90, 75)
        Me.LPE5S.TabIndex = 113
        Me.LPE5S.Text = "PE5"
        Me.LPE5S.UseVisualStyleBackColor = False
        Me.LPE5S.Visible = False
        '
        'Label49
        '
        Me.Label49.AutoSize = True
        Me.Label49.Font = New System.Drawing.Font("Arial", 20.25!, System.Drawing.FontStyle.Bold)
        Me.Label49.ImeMode = System.Windows.Forms.ImeMode.NoControl
        Me.Label49.Location = New System.Drawing.Point(8, 206)
        Me.Label49.Name = "Label49"
        Me.Label49.Size = New System.Drawing.Size(47, 32)
        Me.Label49.TabIndex = 117
        Me.Label49.Text = "L3"
        '
        'LPV1S
        '
        Me.LPV1S.BackColor = System.Drawing.Color.Red
        Me.LPV1S.Font = New System.Drawing.Font("Arial", 14.25!)
        Me.LPV1S.ImeMode = System.Windows.Forms.ImeMode.NoControl
        Me.LPV1S.Location = New System.Drawing.Point(174, 8)
        Me.LPV1S.Name = "LPV1S"
        Me.LPV1S.Size = New System.Drawing.Size(90, 75)
        Me.LPV1S.TabIndex = 101
        Me.LPV1S.Text = "PV1"
        Me.LPV1S.UseVisualStyleBackColor = False
        '
        'LPA5S
        '
        Me.LPA5S.BackColor = System.Drawing.Color.Green
        Me.LPA5S.Font = New System.Drawing.Font("Arial", 14.25!)
        Me.LPA5S.ImeMode = System.Windows.Forms.ImeMode.NoControl
        Me.LPA5S.Location = New System.Drawing.Point(58, 370)
        Me.LPA5S.Name = "LPA5S"
        Me.LPA5S.Size = New System.Drawing.Size(90, 75)
        Me.LPA5S.TabIndex = 112
        Me.LPA5S.Text = "PA5"
        Me.LPA5S.UseVisualStyleBackColor = False
        '
        'LPA4S
        '
        Me.LPA4S.BackColor = System.Drawing.Color.Green
        Me.LPA4S.Font = New System.Drawing.Font("Arial", 14.25!)
        Me.LPA4S.ImeMode = System.Windows.Forms.ImeMode.NoControl
        Me.LPA4S.Location = New System.Drawing.Point(61, 279)
        Me.LPA4S.Name = "LPA4S"
        Me.LPA4S.Size = New System.Drawing.Size(90, 75)
        Me.LPA4S.TabIndex = 103
        Me.LPA4S.Text = "PA4"
        Me.LPA4S.UseVisualStyleBackColor = False
        '
        'LPE2S
        '
        Me.LPE2S.BackColor = System.Drawing.Color.Red
        Me.LPE2S.Font = New System.Drawing.Font("Arial", 14.25!)
        Me.LPE2S.ImeMode = System.Windows.Forms.ImeMode.NoControl
        Me.LPE2S.Location = New System.Drawing.Point(290, 94)
        Me.LPE2S.Name = "LPE2S"
        Me.LPE2S.Size = New System.Drawing.Size(90, 75)
        Me.LPE2S.TabIndex = 105
        Me.LPE2S.Text = "PE2"
        Me.LPE2S.UseVisualStyleBackColor = False
        Me.LPE2S.Visible = False
        '
        'LPV2S
        '
        Me.LPV2S.BackColor = System.Drawing.Color.DodgerBlue
        Me.LPV2S.Font = New System.Drawing.Font("Arial", 14.25!)
        Me.LPV2S.ImeMode = System.Windows.Forms.ImeMode.NoControl
        Me.LPV2S.Location = New System.Drawing.Point(174, 94)
        Me.LPV2S.Name = "LPV2S"
        Me.LPV2S.Size = New System.Drawing.Size(90, 75)
        Me.LPV2S.TabIndex = 104
        Me.LPV2S.Text = "PV2"
        Me.LPV2S.UseVisualStyleBackColor = False
        '
        'LPA2S
        '
        Me.LPA2S.BackColor = System.Drawing.Color.Green
        Me.LPA2S.Font = New System.Drawing.Font("Arial", 14.25!)
        Me.LPA2S.ImeMode = System.Windows.Forms.ImeMode.NoControl
        Me.LPA2S.Location = New System.Drawing.Point(58, 94)
        Me.LPA2S.Name = "LPA2S"
        Me.LPA2S.Size = New System.Drawing.Size(90, 75)
        Me.LPA2S.TabIndex = 106
        Me.LPA2S.Text = "PA2"
        Me.LPA2S.UseVisualStyleBackColor = False
        '
        'LPV3S
        '
        Me.LPV3S.BackColor = System.Drawing.Color.DodgerBlue
        Me.LPV3S.Font = New System.Drawing.Font("Arial", 14.25!)
        Me.LPV3S.ImeMode = System.Windows.Forms.ImeMode.NoControl
        Me.LPV3S.Location = New System.Drawing.Point(174, 187)
        Me.LPV3S.Name = "LPV3S"
        Me.LPV3S.Size = New System.Drawing.Size(90, 75)
        Me.LPV3S.TabIndex = 107
        Me.LPV3S.Text = "PV3"
        Me.LPV3S.UseVisualStyleBackColor = False
        '
        'LPA3S
        '
        Me.LPA3S.BackColor = System.Drawing.Color.Green
        Me.LPA3S.Font = New System.Drawing.Font("Arial", 14.25!)
        Me.LPA3S.ImeMode = System.Windows.Forms.ImeMode.NoControl
        Me.LPA3S.Location = New System.Drawing.Point(58, 187)
        Me.LPA3S.Name = "LPA3S"
        Me.LPA3S.Size = New System.Drawing.Size(90, 75)
        Me.LPA3S.TabIndex = 110
        Me.LPA3S.Text = "PA3"
        Me.LPA3S.UseVisualStyleBackColor = False
        '
        'LPE3S
        '
        Me.LPE3S.BackColor = System.Drawing.Color.Red
        Me.LPE3S.Font = New System.Drawing.Font("Arial", 14.25!)
        Me.LPE3S.ImeMode = System.Windows.Forms.ImeMode.NoControl
        Me.LPE3S.Location = New System.Drawing.Point(290, 187)
        Me.LPE3S.Name = "LPE3S"
        Me.LPE3S.Size = New System.Drawing.Size(90, 75)
        Me.LPE3S.TabIndex = 108
        Me.LPE3S.Text = "PE3"
        Me.LPE3S.UseVisualStyleBackColor = False
        Me.LPE3S.Visible = False
        '
        'LPV4S
        '
        Me.LPV4S.BackColor = System.Drawing.Color.DodgerBlue
        Me.LPV4S.Font = New System.Drawing.Font("Arial", 14.25!)
        Me.LPV4S.ImeMode = System.Windows.Forms.ImeMode.NoControl
        Me.LPV4S.Location = New System.Drawing.Point(177, 278)
        Me.LPV4S.Name = "LPV4S"
        Me.LPV4S.Size = New System.Drawing.Size(90, 75)
        Me.LPV4S.TabIndex = 109
        Me.LPV4S.Text = "PV4"
        Me.LPV4S.UseVisualStyleBackColor = False
        '
        'InformacionHH
        '
        Me.InformacionHH.Controls.Add(Me.BtnEnvioHH)
        Me.InformacionHH.Location = New System.Drawing.Point(4, 23)
        Me.InformacionHH.Name = "InformacionHH"
        Me.InformacionHH.Size = New System.Drawing.Size(1237, 683)
        Me.InformacionHH.TabIndex = 4
        Me.InformacionHH.Text = "INFORMACION  HH"
        Me.InformacionHH.UseVisualStyleBackColor = True
        '
        'BtnEnvioHH
        '
        Me.BtnEnvioHH.Enabled = False
        Me.BtnEnvioHH.ImeMode = System.Windows.Forms.ImeMode.NoControl
        Me.BtnEnvioHH.Location = New System.Drawing.Point(356, 129)
        Me.BtnEnvioHH.Name = "BtnEnvioHH"
        Me.BtnEnvioHH.Size = New System.Drawing.Size(168, 53)
        Me.BtnEnvioHH.TabIndex = 3
        Me.BtnEnvioHH.Text = "CARGAR HH"
        Me.BtnEnvioHH.UseVisualStyleBackColor = True
        '
        'Tooling
        '
        Me.Tooling.Controls.Add(Me.TxtUpdTooling)
        Me.Tooling.Controls.Add(Me.BtnSave)
        Me.Tooling.Controls.Add(Me.GridTooling)
        Me.Tooling.Location = New System.Drawing.Point(4, 23)
        Me.Tooling.Name = "Tooling"
        Me.Tooling.Padding = New System.Windows.Forms.Padding(3)
        Me.Tooling.Size = New System.Drawing.Size(1237, 683)
        Me.Tooling.TabIndex = 0
        Me.Tooling.Text = "TOOLING"
        Me.Tooling.UseVisualStyleBackColor = True
        '
        'TxtUpdTooling
        '
        Me.TxtUpdTooling.Enabled = False
        Me.TxtUpdTooling.Font = New System.Drawing.Font("Arial", 12.0!, System.Drawing.FontStyle.Bold)
        Me.TxtUpdTooling.ForeColor = System.Drawing.SystemColors.MenuHighlight
        Me.TxtUpdTooling.Location = New System.Drawing.Point(851, 261)
        Me.TxtUpdTooling.Name = "TxtUpdTooling"
        Me.TxtUpdTooling.Size = New System.Drawing.Size(88, 26)
        Me.TxtUpdTooling.TabIndex = 2
        '
        'BtnSave
        '
        Me.BtnSave.Enabled = False
        Me.BtnSave.ImeMode = System.Windows.Forms.ImeMode.NoControl
        Me.BtnSave.Location = New System.Drawing.Point(846, 293)
        Me.BtnSave.Name = "BtnSave"
        Me.BtnSave.Size = New System.Drawing.Size(105, 40)
        Me.BtnSave.TabIndex = 1
        Me.BtnSave.Text = "GRABAR"
        Me.BtnSave.UseVisualStyleBackColor = True
        Me.BtnSave.Visible = False
        '
        'GridTooling
        '
        Me.GridTooling.BackgroundColor = System.Drawing.SystemColors.Highlight
        Me.GridTooling.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize
        Me.GridTooling.GridColor = System.Drawing.SystemColors.InactiveCaption
        Me.GridTooling.Location = New System.Drawing.Point(127, 18)
        Me.GridTooling.Name = "GridTooling"
        Me.GridTooling.Size = New System.Drawing.Size(700, 481)
        Me.GridTooling.TabIndex = 0
        '
        'Lineas
        '
        Me.Lineas.Controls.Add(Me.Panel3)
        Me.Lineas.Location = New System.Drawing.Point(4, 23)
        Me.Lineas.Name = "Lineas"
        Me.Lineas.Size = New System.Drawing.Size(1237, 683)
        Me.Lineas.TabIndex = 3
        Me.Lineas.Text = "LINEAS"
        Me.Lineas.UseVisualStyleBackColor = True
        '
        'Panel3
        '
        Me.Panel3.Controls.Add(Me.PE13T)
        Me.Panel3.Controls.Add(Me.EdNumEmpleado)
        Me.Panel3.Controls.Add(Me.PE11T)
        Me.Panel3.Controls.Add(Me.Label1)
        Me.Panel3.Controls.Add(Me.PE10T)
        Me.Panel3.Controls.Add(Me.EdtTecnico)
        Me.Panel3.Controls.Add(Me.PV13T)
        Me.Panel3.Controls.Add(Me.Label44)
        Me.Panel3.Controls.Add(Me.PV11T)
        Me.Panel3.Controls.Add(Me.Label3)
        Me.Panel3.Controls.Add(Me.PV10T)
        Me.Panel3.Controls.Add(Me.EdtLine)
        Me.Panel3.Controls.Add(Me.PA13T)
        Me.Panel3.Controls.Add(Me.Label41)
        Me.Panel3.Controls.Add(Me.PA11T)
        Me.Panel3.Controls.Add(Me.EdtPrensa)
        Me.Panel3.Controls.Add(Me.PA10T)
        Me.Panel3.Controls.Add(Me.Label32)
        Me.Panel3.Controls.Add(Me.PE9T)
        Me.Panel3.Controls.Add(Me.EdtLado)
        Me.Panel3.Controls.Add(Me.PV9T)
        Me.Panel3.Controls.Add(Me.Label33)
        Me.Panel3.Controls.Add(Me.PA9T)
        Me.Panel3.Controls.Add(Me.EdtHora)
        Me.Panel3.Controls.Add(Me.PE8T)
        Me.Panel3.Controls.Add(Me.Label34)
        Me.Panel3.Controls.Add(Me.PV8T)
        Me.Panel3.Controls.Add(Me.EdtFecha)
        Me.Panel3.Controls.Add(Me.PA8T)
        Me.Panel3.Controls.Add(Me.Label35)
        Me.Panel3.Controls.Add(Me.PE7T)
        Me.Panel3.Controls.Add(Me.EdtTurno)
        Me.Panel3.Controls.Add(Me.PV7T)
        Me.Panel3.Controls.Add(Me.Label39)
        Me.Panel3.Controls.Add(Me.PA7T)
        Me.Panel3.Controls.Add(Me.EdtTooling)
        Me.Panel3.Controls.Add(Me.PE6T)
        Me.Panel3.Controls.Add(Me.Label38)
        Me.Panel3.Controls.Add(Me.PV6T)
        Me.Panel3.Controls.Add(Me.EdtVida)
        Me.Panel3.Controls.Add(Me.PA6T)
        Me.Panel3.Controls.Add(Me.Label4)
        Me.Panel3.Controls.Add(Me.PE5T)
        Me.Panel3.Controls.Add(Me.EdtTiempoTotal)
        Me.Panel3.Controls.Add(Me.PV5T)
        Me.Panel3.Controls.Add(Me.Label2)
        Me.Panel3.Controls.Add(Me.PA5T)
        Me.Panel3.Controls.Add(Me.EdtPPackAnt)
        Me.Panel3.Controls.Add(Me.PE4T)
        Me.Panel3.Controls.Add(Me.Label37)
        Me.Panel3.Controls.Add(Me.PV4T)
        Me.Panel3.Controls.Add(Me.EdtGreenPlate)
        Me.Panel3.Controls.Add(Me.PA4T)
        Me.Panel3.Controls.Add(Me.Label43)
        Me.Panel3.Controls.Add(Me.PE3T)
        Me.Panel3.Controls.Add(Me.EdtLaina)
        Me.Panel3.Controls.Add(Me.Label40)
        Me.Panel3.Controls.Add(Me.PV3T)
        Me.Panel3.Controls.Add(Me.Label5)
        Me.Panel3.Controls.Add(Me.PA3T)
        Me.Panel3.Controls.Add(Me.PE2T)
        Me.Panel3.Controls.Add(Me.PV2T)
        Me.Panel3.Controls.Add(Me.PA2T)
        Me.Panel3.Controls.Add(Me.PE1T)
        Me.Panel3.Controls.Add(Me.PV1T)
        Me.Panel3.Controls.Add(Me.PA1T)
        Me.Panel3.Controls.Add(Me.Label15)
        Me.Panel3.Controls.Add(Me.Label16)
        Me.Panel3.Controls.Add(Me.Label10)
        Me.Panel3.Controls.Add(Me.Label8)
        Me.Panel3.Controls.Add(Me.Label31)
        Me.Panel3.Controls.Add(Me.Label30)
        Me.Panel3.Controls.Add(Me.Label29)
        Me.Panel3.Controls.Add(Me.LPA9)
        Me.Panel3.Controls.Add(Me.LPE13)
        Me.Panel3.Controls.Add(Me.Label25)
        Me.Panel3.Controls.Add(Me.LPE11)
        Me.Panel3.Controls.Add(Me.LPE10)
        Me.Panel3.Controls.Add(Me.LPV13)
        Me.Panel3.Controls.Add(Me.Label24)
        Me.Panel3.Controls.Add(Me.LPV11)
        Me.Panel3.Controls.Add(Me.LPV10)
        Me.Panel3.Controls.Add(Me.LPA13)
        Me.Panel3.Controls.Add(Me.LPA1)
        Me.Panel3.Controls.Add(Me.LPA11)
        Me.Panel3.Controls.Add(Me.LPA10)
        Me.Panel3.Controls.Add(Me.Label27)
        Me.Panel3.Controls.Add(Me.Label26)
        Me.Panel3.Controls.Add(Me.LPE4)
        Me.Panel3.Controls.Add(Me.LPE9)
        Me.Panel3.Controls.Add(Me.LPE1)
        Me.Panel3.Controls.Add(Me.LPV8)
        Me.Panel3.Controls.Add(Me.LPV5)
        Me.Panel3.Controls.Add(Me.LPA8)
        Me.Panel3.Controls.Add(Me.LPE5)
        Me.Panel3.Controls.Add(Me.LPE7)
        Me.Panel3.Controls.Add(Me.LPE6)
        Me.Panel3.Controls.Add(Me.Label17)
        Me.Panel3.Controls.Add(Me.LPV7)
        Me.Panel3.Controls.Add(Me.LPV6)
        Me.Panel3.Controls.Add(Me.LPV1)
        Me.Panel3.Controls.Add(Me.LPA5)
        Me.Panel3.Controls.Add(Me.LPA4)
        Me.Panel3.Controls.Add(Me.LPE2)
        Me.Panel3.Controls.Add(Me.LPV2)
        Me.Panel3.Controls.Add(Me.LPA2)
        Me.Panel3.Controls.Add(Me.LPA7)
        Me.Panel3.Controls.Add(Me.LPV3)
        Me.Panel3.Controls.Add(Me.LPA3)
        Me.Panel3.Controls.Add(Me.LPE3)
        Me.Panel3.Controls.Add(Me.LPA6)
        Me.Panel3.Controls.Add(Me.LPV4)
        Me.Panel3.Controls.Add(Me.LPV9)
        Me.Panel3.Controls.Add(Me.LPE8)
        Me.Panel3.Location = New System.Drawing.Point(-9, 3)
        Me.Panel3.Name = "Panel3"
        Me.Panel3.Size = New System.Drawing.Size(1242, 810)
        Me.Panel3.TabIndex = 47
        '
        'PE13T
        '
        Me.PE13T.AutoSize = True
        Me.PE13T.Font = New System.Drawing.Font("Arial", 6.75!)
        Me.PE13T.ImeMode = System.Windows.Forms.ImeMode.NoControl
        Me.PE13T.Location = New System.Drawing.Point(1161, 589)
        Me.PE13T.Name = "PE13T"
        Me.PE13T.Size = New System.Drawing.Size(15, 12)
        Me.PE13T.TabIndex = 117
        Me.PE13T.Text = "TT"
        '
        'EdNumEmpleado
        '
        Me.EdNumEmpleado.Font = New System.Drawing.Font("Microsoft Sans Serif", 14.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.EdNumEmpleado.ForeColor = System.Drawing.Color.Black
        Me.EdNumEmpleado.Location = New System.Drawing.Point(623, 44)
        Me.EdNumEmpleado.Name = "EdNumEmpleado"
        Me.EdNumEmpleado.Size = New System.Drawing.Size(120, 29)
        Me.EdNumEmpleado.TabIndex = 80
        '
        'PE11T
        '
        Me.PE11T.AutoSize = True
        Me.PE11T.Font = New System.Drawing.Font("Arial", 6.75!)
        Me.PE11T.ImeMode = System.Windows.Forms.ImeMode.NoControl
        Me.PE11T.Location = New System.Drawing.Point(1162, 495)
        Me.PE11T.Name = "PE11T"
        Me.PE11T.Size = New System.Drawing.Size(15, 12)
        Me.PE11T.TabIndex = 117
        Me.PE11T.Text = "TT"
        '
        'Label1
        '
        Me.Label1.AutoSize = True
        Me.Label1.Font = New System.Drawing.Font("Arial", 9.75!, System.Drawing.FontStyle.Bold)
        Me.Label1.ImeMode = System.Windows.Forms.ImeMode.NoControl
        Me.Label1.Location = New System.Drawing.Point(491, 49)
        Me.Label1.Name = "Label1"
        Me.Label1.Size = New System.Drawing.Size(113, 16)
        Me.Label1.TabIndex = 79
        Me.Label1.Text = "NUM EMPLEADO"
        '
        'PE10T
        '
        Me.PE10T.AutoSize = True
        Me.PE10T.Font = New System.Drawing.Font("Arial", 6.75!)
        Me.PE10T.ImeMode = System.Windows.Forms.ImeMode.NoControl
        Me.PE10T.Location = New System.Drawing.Point(1161, 395)
        Me.PE10T.Name = "PE10T"
        Me.PE10T.Size = New System.Drawing.Size(15, 12)
        Me.PE10T.TabIndex = 117
        Me.PE10T.Text = "TT"
        '
        'EdtTecnico
        '
        Me.EdtTecnico.Font = New System.Drawing.Font("Microsoft Sans Serif", 14.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.EdtTecnico.ForeColor = System.Drawing.Color.Black
        Me.EdtTecnico.Location = New System.Drawing.Point(623, 94)
        Me.EdtTecnico.Name = "EdtTecnico"
        Me.EdtTecnico.Size = New System.Drawing.Size(120, 29)
        Me.EdtTecnico.TabIndex = 70
        '
        'PV13T
        '
        Me.PV13T.AutoSize = True
        Me.PV13T.Font = New System.Drawing.Font("Arial", 6.75!)
        Me.PV13T.ImeMode = System.Windows.Forms.ImeMode.NoControl
        Me.PV13T.Location = New System.Drawing.Point(1028, 585)
        Me.PV13T.Name = "PV13T"
        Me.PV13T.Size = New System.Drawing.Size(15, 12)
        Me.PV13T.TabIndex = 116
        Me.PV13T.Text = "TT"
        '
        'Label44
        '
        Me.Label44.AutoSize = True
        Me.Label44.Font = New System.Drawing.Font("Arial", 9.75!, System.Drawing.FontStyle.Bold)
        Me.Label44.ImeMode = System.Windows.Forms.ImeMode.NoControl
        Me.Label44.Location = New System.Drawing.Point(492, 101)
        Me.Label44.Name = "Label44"
        Me.Label44.Size = New System.Drawing.Size(113, 16)
        Me.Label44.TabIndex = 78
        Me.Label44.Text = "TEC/AUX -MTTO."
        '
        'PV11T
        '
        Me.PV11T.AutoSize = True
        Me.PV11T.Font = New System.Drawing.Font("Arial", 6.75!)
        Me.PV11T.ImeMode = System.Windows.Forms.ImeMode.NoControl
        Me.PV11T.Location = New System.Drawing.Point(1029, 491)
        Me.PV11T.Name = "PV11T"
        Me.PV11T.Size = New System.Drawing.Size(15, 12)
        Me.PV11T.TabIndex = 116
        Me.PV11T.Text = "TT"
        '
        'Label3
        '
        Me.Label3.AutoSize = True
        Me.Label3.Font = New System.Drawing.Font("Arial", 9.75!, System.Drawing.FontStyle.Bold)
        Me.Label3.ImeMode = System.Windows.Forms.ImeMode.NoControl
        Me.Label3.Location = New System.Drawing.Point(492, 130)
        Me.Label3.Name = "Label3"
        Me.Label3.Size = New System.Drawing.Size(53, 16)
        Me.Label3.TabIndex = 84
        Me.Label3.Text = "TURNO"
        '
        'PV10T
        '
        Me.PV10T.AutoSize = True
        Me.PV10T.Font = New System.Drawing.Font("Arial", 6.75!)
        Me.PV10T.ImeMode = System.Windows.Forms.ImeMode.NoControl
        Me.PV10T.Location = New System.Drawing.Point(1028, 391)
        Me.PV10T.Name = "PV10T"
        Me.PV10T.Size = New System.Drawing.Size(15, 12)
        Me.PV10T.TabIndex = 116
        Me.PV10T.Text = "TT"
        '
        'EdtLine
        '
        Me.EdtLine.CausesValidation = False
        Me.EdtLine.Font = New System.Drawing.Font("Microsoft Sans Serif", 14.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.EdtLine.ForeColor = System.Drawing.Color.Black
        Me.EdtLine.Location = New System.Drawing.Point(483, 186)
        Me.EdtLine.Name = "EdtLine"
        Me.EdtLine.Size = New System.Drawing.Size(72, 29)
        Me.EdtLine.TabIndex = 73
        '
        'PA13T
        '
        Me.PA13T.AutoSize = True
        Me.PA13T.Font = New System.Drawing.Font("Arial", 6.75!)
        Me.PA13T.ImeMode = System.Windows.Forms.ImeMode.NoControl
        Me.PA13T.Location = New System.Drawing.Point(918, 585)
        Me.PA13T.Name = "PA13T"
        Me.PA13T.Size = New System.Drawing.Size(15, 12)
        Me.PA13T.TabIndex = 115
        Me.PA13T.Text = "TT"
        '
        'Label41
        '
        Me.Label41.AutoSize = True
        Me.Label41.Font = New System.Drawing.Font("Arial", 9.75!, System.Drawing.FontStyle.Bold)
        Me.Label41.ImeMode = System.Windows.Forms.ImeMode.NoControl
        Me.Label41.Location = New System.Drawing.Point(480, 161)
        Me.Label41.Name = "Label41"
        Me.Label41.Size = New System.Drawing.Size(46, 16)
        Me.Label41.TabIndex = 62
        Me.Label41.Text = "LINEA"
        '
        'PA11T
        '
        Me.PA11T.AutoSize = True
        Me.PA11T.Font = New System.Drawing.Font("Arial", 6.75!)
        Me.PA11T.ImeMode = System.Windows.Forms.ImeMode.NoControl
        Me.PA11T.Location = New System.Drawing.Point(919, 491)
        Me.PA11T.Name = "PA11T"
        Me.PA11T.Size = New System.Drawing.Size(15, 12)
        Me.PA11T.TabIndex = 115
        Me.PA11T.Text = "TT"
        '
        'EdtPrensa
        '
        Me.EdtPrensa.Font = New System.Drawing.Font("Microsoft Sans Serif", 14.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.EdtPrensa.ForeColor = System.Drawing.Color.Black
        Me.EdtPrensa.Location = New System.Drawing.Point(561, 188)
        Me.EdtPrensa.Name = "EdtPrensa"
        Me.EdtPrensa.Size = New System.Drawing.Size(120, 29)
        Me.EdtPrensa.TabIndex = 74
        '
        'PA10T
        '
        Me.PA10T.AutoSize = True
        Me.PA10T.Font = New System.Drawing.Font("Arial", 6.75!)
        Me.PA10T.ImeMode = System.Windows.Forms.ImeMode.NoControl
        Me.PA10T.Location = New System.Drawing.Point(918, 391)
        Me.PA10T.Name = "PA10T"
        Me.PA10T.Size = New System.Drawing.Size(15, 12)
        Me.PA10T.TabIndex = 115
        Me.PA10T.Text = "TT"
        '
        'Label32
        '
        Me.Label32.AutoSize = True
        Me.Label32.Font = New System.Drawing.Font("Arial", 9.75!, System.Drawing.FontStyle.Bold)
        Me.Label32.ImeMode = System.Windows.Forms.ImeMode.NoControl
        Me.Label32.Location = New System.Drawing.Point(562, 161)
        Me.Label32.Name = "Label32"
        Me.Label32.Size = New System.Drawing.Size(61, 16)
        Me.Label32.TabIndex = 52
        Me.Label32.Text = "PRENSA"
        '
        'PE9T
        '
        Me.PE9T.AutoSize = True
        Me.PE9T.Font = New System.Drawing.Font("Arial", 6.75!)
        Me.PE9T.ImeMode = System.Windows.Forms.ImeMode.NoControl
        Me.PE9T.Location = New System.Drawing.Point(1161, 299)
        Me.PE9T.Name = "PE9T"
        Me.PE9T.Size = New System.Drawing.Size(15, 12)
        Me.PE9T.TabIndex = 114
        Me.PE9T.Text = "TT"
        '
        'EdtLado
        '
        Me.EdtLado.Font = New System.Drawing.Font("Microsoft Sans Serif", 14.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.EdtLado.ForeColor = System.Drawing.Color.Black
        Me.EdtLado.Location = New System.Drawing.Point(687, 188)
        Me.EdtLado.Name = "EdtLado"
        Me.EdtLado.Size = New System.Drawing.Size(87, 29)
        Me.EdtLado.TabIndex = 75
        '
        'PV9T
        '
        Me.PV9T.AutoSize = True
        Me.PV9T.Font = New System.Drawing.Font("Arial", 6.75!)
        Me.PV9T.ImeMode = System.Windows.Forms.ImeMode.NoControl
        Me.PV9T.Location = New System.Drawing.Point(1028, 299)
        Me.PV9T.Name = "PV9T"
        Me.PV9T.Size = New System.Drawing.Size(15, 12)
        Me.PV9T.TabIndex = 113
        Me.PV9T.Text = "TT"
        '
        'Label33
        '
        Me.Label33.AutoSize = True
        Me.Label33.Font = New System.Drawing.Font("Arial", 9.75!, System.Drawing.FontStyle.Bold)
        Me.Label33.ImeMode = System.Windows.Forms.ImeMode.NoControl
        Me.Label33.Location = New System.Drawing.Point(684, 169)
        Me.Label33.Name = "Label33"
        Me.Label33.Size = New System.Drawing.Size(44, 16)
        Me.Label33.TabIndex = 53
        Me.Label33.Text = "LADO"
        '
        'PA9T
        '
        Me.PA9T.AutoSize = True
        Me.PA9T.Font = New System.Drawing.Font("Arial", 6.75!)
        Me.PA9T.ImeMode = System.Windows.Forms.ImeMode.NoControl
        Me.PA9T.Location = New System.Drawing.Point(918, 303)
        Me.PA9T.Name = "PA9T"
        Me.PA9T.Size = New System.Drawing.Size(15, 12)
        Me.PA9T.TabIndex = 112
        Me.PA9T.Text = "TT"
        '
        'EdtHora
        '
        Me.EdtHora.Font = New System.Drawing.Font("Microsoft Sans Serif", 14.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.EdtHora.ForeColor = System.Drawing.Color.Black
        Me.EdtHora.Location = New System.Drawing.Point(483, 247)
        Me.EdtHora.Name = "EdtHora"
        Me.EdtHora.Size = New System.Drawing.Size(174, 29)
        Me.EdtHora.TabIndex = 72
        '
        'PE8T
        '
        Me.PE8T.AutoSize = True
        Me.PE8T.Font = New System.Drawing.Font("Arial", 6.75!)
        Me.PE8T.ImeMode = System.Windows.Forms.ImeMode.NoControl
        Me.PE8T.Location = New System.Drawing.Point(1161, 206)
        Me.PE8T.Name = "PE8T"
        Me.PE8T.Size = New System.Drawing.Size(15, 12)
        Me.PE8T.TabIndex = 111
        Me.PE8T.Text = "TT"
        '
        'Label34
        '
        Me.Label34.AutoSize = True
        Me.Label34.Font = New System.Drawing.Font("Arial", 9.75!, System.Drawing.FontStyle.Bold)
        Me.Label34.ImeMode = System.Windows.Forms.ImeMode.NoControl
        Me.Label34.Location = New System.Drawing.Point(480, 229)
        Me.Label34.Name = "Label34"
        Me.Label34.Size = New System.Drawing.Size(45, 16)
        Me.Label34.TabIndex = 55
        Me.Label34.Text = "HORA"
        '
        'PV8T
        '
        Me.PV8T.AutoSize = True
        Me.PV8T.Font = New System.Drawing.Font("Arial", 6.75!)
        Me.PV8T.ImeMode = System.Windows.Forms.ImeMode.NoControl
        Me.PV8T.Location = New System.Drawing.Point(1026, 209)
        Me.PV8T.Name = "PV8T"
        Me.PV8T.Size = New System.Drawing.Size(15, 12)
        Me.PV8T.TabIndex = 110
        Me.PV8T.Text = "TT"
        '
        'EdtFecha
        '
        Me.EdtFecha.Font = New System.Drawing.Font("Microsoft Sans Serif", 14.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.EdtFecha.ForeColor = System.Drawing.Color.Black
        Me.EdtFecha.Location = New System.Drawing.Point(483, 308)
        Me.EdtFecha.Name = "EdtFecha"
        Me.EdtFecha.Size = New System.Drawing.Size(202, 29)
        Me.EdtFecha.TabIndex = 71
        '
        'PA8T
        '
        Me.PA8T.AutoSize = True
        Me.PA8T.Font = New System.Drawing.Font("Arial", 6.75!)
        Me.PA8T.ImeMode = System.Windows.Forms.ImeMode.NoControl
        Me.PA8T.Location = New System.Drawing.Point(918, 206)
        Me.PA8T.Name = "PA8T"
        Me.PA8T.Size = New System.Drawing.Size(15, 12)
        Me.PA8T.TabIndex = 109
        Me.PA8T.Text = "TT"
        '
        'Label35
        '
        Me.Label35.AutoSize = True
        Me.Label35.Font = New System.Drawing.Font("Arial", 9.75!, System.Drawing.FontStyle.Bold)
        Me.Label35.ImeMode = System.Windows.Forms.ImeMode.NoControl
        Me.Label35.Location = New System.Drawing.Point(480, 290)
        Me.Label35.Name = "Label35"
        Me.Label35.Size = New System.Drawing.Size(51, 16)
        Me.Label35.TabIndex = 54
        Me.Label35.Text = "FECHA"
        '
        'PE7T
        '
        Me.PE7T.AutoSize = True
        Me.PE7T.Font = New System.Drawing.Font("Arial", 6.75!)
        Me.PE7T.ImeMode = System.Windows.Forms.ImeMode.NoControl
        Me.PE7T.Location = New System.Drawing.Point(1161, 107)
        Me.PE7T.Name = "PE7T"
        Me.PE7T.Size = New System.Drawing.Size(15, 12)
        Me.PE7T.TabIndex = 108
        Me.PE7T.Text = "TT"
        '
        'EdtTurno
        '
        Me.EdtTurno.Font = New System.Drawing.Font("Microsoft Sans Serif", 14.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.EdtTurno.ForeColor = System.Drawing.Color.Black
        Me.EdtTurno.Location = New System.Drawing.Point(704, 247)
        Me.EdtTurno.Name = "EdtTurno"
        Me.EdtTurno.Size = New System.Drawing.Size(51, 29)
        Me.EdtTurno.TabIndex = 76
        '
        'PV7T
        '
        Me.PV7T.AutoSize = True
        Me.PV7T.Font = New System.Drawing.Font("Arial", 6.75!)
        Me.PV7T.ImeMode = System.Windows.Forms.ImeMode.NoControl
        Me.PV7T.Location = New System.Drawing.Point(1026, 107)
        Me.PV7T.Name = "PV7T"
        Me.PV7T.Size = New System.Drawing.Size(15, 12)
        Me.PV7T.TabIndex = 107
        Me.PV7T.Text = "TT"
        '
        'Label39
        '
        Me.Label39.AutoSize = True
        Me.Label39.Font = New System.Drawing.Font("Arial", 9.75!, System.Drawing.FontStyle.Bold)
        Me.Label39.ImeMode = System.Windows.Forms.ImeMode.NoControl
        Me.Label39.Location = New System.Drawing.Point(698, 229)
        Me.Label39.Name = "Label39"
        Me.Label39.Size = New System.Drawing.Size(53, 16)
        Me.Label39.TabIndex = 56
        Me.Label39.Text = "TURNO"
        '
        'PA7T
        '
        Me.PA7T.AutoSize = True
        Me.PA7T.Font = New System.Drawing.Font("Arial", 6.75!)
        Me.PA7T.ImeMode = System.Windows.Forms.ImeMode.NoControl
        Me.PA7T.Location = New System.Drawing.Point(918, 107)
        Me.PA7T.Name = "PA7T"
        Me.PA7T.Size = New System.Drawing.Size(15, 12)
        Me.PA7T.TabIndex = 106
        Me.PA7T.Text = "TT"
        '
        'EdtTooling
        '
        Me.EdtTooling.Font = New System.Drawing.Font("Microsoft Sans Serif", 14.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.EdtTooling.ForeColor = System.Drawing.Color.Black
        Me.EdtTooling.Location = New System.Drawing.Point(483, 370)
        Me.EdtTooling.Name = "EdtTooling"
        Me.EdtTooling.Size = New System.Drawing.Size(100, 29)
        Me.EdtTooling.TabIndex = 51
        '
        'PE6T
        '
        Me.PE6T.AutoSize = True
        Me.PE6T.Font = New System.Drawing.Font("Arial", 6.75!)
        Me.PE6T.ImeMode = System.Windows.Forms.ImeMode.NoControl
        Me.PE6T.Location = New System.Drawing.Point(365, 585)
        Me.PE6T.Name = "PE6T"
        Me.PE6T.Size = New System.Drawing.Size(15, 12)
        Me.PE6T.TabIndex = 105
        Me.PE6T.Text = "TT"
        '
        'Label38
        '
        Me.Label38.AutoSize = True
        Me.Label38.Font = New System.Drawing.Font("Arial", 9.75!, System.Drawing.FontStyle.Bold)
        Me.Label38.ImeMode = System.Windows.Forms.ImeMode.NoControl
        Me.Label38.Location = New System.Drawing.Point(490, 350)
        Me.Label38.Name = "Label38"
        Me.Label38.Size = New System.Drawing.Size(67, 16)
        Me.Label38.TabIndex = 57
        Me.Label38.Text = "TOOLING"
        '
        'PV6T
        '
        Me.PV6T.AutoSize = True
        Me.PV6T.Font = New System.Drawing.Font("Arial", 6.75!)
        Me.PV6T.ImeMode = System.Windows.Forms.ImeMode.NoControl
        Me.PV6T.Location = New System.Drawing.Point(241, 588)
        Me.PV6T.Name = "PV6T"
        Me.PV6T.Size = New System.Drawing.Size(15, 12)
        Me.PV6T.TabIndex = 104
        Me.PV6T.Text = "TT"
        '
        'EdtVida
        '
        Me.EdtVida.Font = New System.Drawing.Font("Microsoft Sans Serif", 14.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.EdtVida.ForeColor = System.Drawing.Color.Black
        Me.EdtVida.Location = New System.Drawing.Point(623, 370)
        Me.EdtVida.Name = "EdtVida"
        Me.EdtVida.Size = New System.Drawing.Size(133, 29)
        Me.EdtVida.TabIndex = 85
        '
        'PA6T
        '
        Me.PA6T.AutoSize = True
        Me.PA6T.Font = New System.Drawing.Font("Arial", 6.75!)
        Me.PA6T.ImeMode = System.Windows.Forms.ImeMode.NoControl
        Me.PA6T.Location = New System.Drawing.Point(122, 588)
        Me.PA6T.Name = "PA6T"
        Me.PA6T.Size = New System.Drawing.Size(15, 12)
        Me.PA6T.TabIndex = 103
        Me.PA6T.Text = "TT"
        '
        'Label4
        '
        Me.Label4.AutoSize = True
        Me.Label4.Font = New System.Drawing.Font("Arial", 9.75!, System.Drawing.FontStyle.Bold)
        Me.Label4.ImeMode = System.Windows.Forms.ImeMode.NoControl
        Me.Label4.Location = New System.Drawing.Point(636, 349)
        Me.Label4.Name = "Label4"
        Me.Label4.Size = New System.Drawing.Size(72, 16)
        Me.Label4.TabIndex = 86
        Me.Label4.Text = "VIDA UTIL"
        Me.Label4.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'PE5T
        '
        Me.PE5T.AutoSize = True
        Me.PE5T.Font = New System.Drawing.Font("Arial", 6.75!)
        Me.PE5T.ImeMode = System.Windows.Forms.ImeMode.NoControl
        Me.PE5T.Location = New System.Drawing.Point(356, 495)
        Me.PE5T.Name = "PE5T"
        Me.PE5T.Size = New System.Drawing.Size(15, 12)
        Me.PE5T.TabIndex = 102
        Me.PE5T.Text = "TT"
        '
        'EdtTiempoTotal
        '
        Me.EdtTiempoTotal.Font = New System.Drawing.Font("Microsoft Sans Serif", 14.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.EdtTiempoTotal.ForeColor = System.Drawing.Color.Black
        Me.EdtTiempoTotal.Location = New System.Drawing.Point(529, 450)
        Me.EdtTiempoTotal.Name = "EdtTiempoTotal"
        Me.EdtTiempoTotal.Size = New System.Drawing.Size(179, 29)
        Me.EdtTiempoTotal.TabIndex = 83
        '
        'PV5T
        '
        Me.PV5T.AutoSize = True
        Me.PV5T.Font = New System.Drawing.Font("Arial", 6.75!)
        Me.PV5T.ImeMode = System.Windows.Forms.ImeMode.NoControl
        Me.PV5T.Location = New System.Drawing.Point(230, 495)
        Me.PV5T.Name = "PV5T"
        Me.PV5T.Size = New System.Drawing.Size(15, 12)
        Me.PV5T.TabIndex = 101
        Me.PV5T.Text = "TT"
        '
        'Label2
        '
        Me.Label2.AutoSize = True
        Me.Label2.Font = New System.Drawing.Font("Arial", 9.75!, System.Drawing.FontStyle.Bold)
        Me.Label2.ImeMode = System.Windows.Forms.ImeMode.NoControl
        Me.Label2.Location = New System.Drawing.Point(520, 431)
        Me.Label2.Name = "Label2"
        Me.Label2.Size = New System.Drawing.Size(111, 16)
        Me.Label2.TabIndex = 82
        Me.Label2.Text = "TIEMPO DE USO"
        '
        'PA5T
        '
        Me.PA5T.AutoSize = True
        Me.PA5T.Font = New System.Drawing.Font("Arial", 6.75!)
        Me.PA5T.ImeMode = System.Windows.Forms.ImeMode.NoControl
        Me.PA5T.Location = New System.Drawing.Point(117, 495)
        Me.PA5T.Name = "PA5T"
        Me.PA5T.Size = New System.Drawing.Size(15, 12)
        Me.PA5T.TabIndex = 100
        Me.PA5T.Text = "TT"
        '
        'EdtPPackAnt
        '
        Me.EdtPPackAnt.Font = New System.Drawing.Font("Microsoft Sans Serif", 14.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.EdtPPackAnt.ForeColor = System.Drawing.Color.Black
        Me.EdtPPackAnt.Location = New System.Drawing.Point(490, 521)
        Me.EdtPPackAnt.Name = "EdtPPackAnt"
        Me.EdtPPackAnt.Size = New System.Drawing.Size(100, 29)
        Me.EdtPPackAnt.TabIndex = 64
        '
        'PE4T
        '
        Me.PE4T.AutoSize = True
        Me.PE4T.Font = New System.Drawing.Font("Arial", 6.75!)
        Me.PE4T.ImeMode = System.Windows.Forms.ImeMode.NoControl
        Me.PE4T.Location = New System.Drawing.Point(356, 398)
        Me.PE4T.Name = "PE4T"
        Me.PE4T.Size = New System.Drawing.Size(15, 12)
        Me.PE4T.TabIndex = 99
        Me.PE4T.Text = "TT"
        '
        'Label37
        '
        Me.Label37.AutoSize = True
        Me.Label37.Font = New System.Drawing.Font("Arial", 9.75!, System.Drawing.FontStyle.Bold)
        Me.Label37.ImeMode = System.Windows.Forms.ImeMode.NoControl
        Me.Label37.Location = New System.Drawing.Point(486, 502)
        Me.Label37.Name = "Label37"
        Me.Label37.Size = New System.Drawing.Size(104, 16)
        Me.Label37.TabIndex = 58
        Me.Label37.Text = "TOOLING. ANT."
        '
        'PV4T
        '
        Me.PV4T.AutoSize = True
        Me.PV4T.Font = New System.Drawing.Font("Arial", 6.75!)
        Me.PV4T.ImeMode = System.Windows.Forms.ImeMode.NoControl
        Me.PV4T.Location = New System.Drawing.Point(241, 398)
        Me.PV4T.Name = "PV4T"
        Me.PV4T.Size = New System.Drawing.Size(15, 12)
        Me.PV4T.TabIndex = 98
        Me.PV4T.Text = "TT"
        '
        'EdtGreenPlate
        '
        Me.EdtGreenPlate.Font = New System.Drawing.Font("Microsoft Sans Serif", 14.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.EdtGreenPlate.ForeColor = System.Drawing.Color.Black
        Me.EdtGreenPlate.Location = New System.Drawing.Point(656, 520)
        Me.EdtGreenPlate.Name = "EdtGreenPlate"
        Me.EdtGreenPlate.Size = New System.Drawing.Size(100, 29)
        Me.EdtGreenPlate.TabIndex = 66
        '
        'PA4T
        '
        Me.PA4T.AutoSize = True
        Me.PA4T.Font = New System.Drawing.Font("Arial", 6.75!)
        Me.PA4T.ImeMode = System.Windows.Forms.ImeMode.NoControl
        Me.PA4T.Location = New System.Drawing.Point(124, 398)
        Me.PA4T.Name = "PA4T"
        Me.PA4T.Size = New System.Drawing.Size(15, 12)
        Me.PA4T.TabIndex = 97
        Me.PA4T.Text = "TT"
        '
        'Label43
        '
        Me.Label43.AutoSize = True
        Me.Label43.Font = New System.Drawing.Font("Arial", 9.75!, System.Drawing.FontStyle.Bold)
        Me.Label43.ImeMode = System.Windows.Forms.ImeMode.NoControl
        Me.Label43.Location = New System.Drawing.Point(657, 501)
        Me.Label43.Name = "Label43"
        Me.Label43.Size = New System.Drawing.Size(97, 16)
        Me.Label43.TabIndex = 60
        Me.Label43.Text = "GREEN PLATE"
        '
        'PE3T
        '
        Me.PE3T.AutoSize = True
        Me.PE3T.Font = New System.Drawing.Font("Arial", 6.75!)
        Me.PE3T.ImeMode = System.Windows.Forms.ImeMode.NoControl
        Me.PE3T.Location = New System.Drawing.Point(347, 301)
        Me.PE3T.Name = "PE3T"
        Me.PE3T.Size = New System.Drawing.Size(15, 12)
        Me.PE3T.TabIndex = 96
        Me.PE3T.Text = "TT"
        '
        'EdtLaina
        '
        Me.EdtLaina.Font = New System.Drawing.Font("Microsoft Sans Serif", 14.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.EdtLaina.ForeColor = System.Drawing.Color.Black
        Me.EdtLaina.Location = New System.Drawing.Point(561, 594)
        Me.EdtLaina.Name = "EdtLaina"
        Me.EdtLaina.Size = New System.Drawing.Size(129, 29)
        Me.EdtLaina.TabIndex = 69
        '
        'Label40
        '
        Me.Label40.AutoSize = True
        Me.Label40.Font = New System.Drawing.Font("Arial", 9.75!, System.Drawing.FontStyle.Bold)
        Me.Label40.ImeMode = System.Windows.Forms.ImeMode.NoControl
        Me.Label40.Location = New System.Drawing.Point(563, 575)
        Me.Label40.Name = "Label40"
        Me.Label40.Size = New System.Drawing.Size(132, 16)
        Me.Label40.TabIndex = 77
        Me.Label40.Text = "LAINA (DIMENSION)"
        '
        'PV3T
        '
        Me.PV3T.AutoSize = True
        Me.PV3T.Font = New System.Drawing.Font("Arial", 6.75!)
        Me.PV3T.ImeMode = System.Windows.Forms.ImeMode.NoControl
        Me.PV3T.Location = New System.Drawing.Point(232, 301)
        Me.PV3T.Name = "PV3T"
        Me.PV3T.Size = New System.Drawing.Size(15, 12)
        Me.PV3T.TabIndex = 95
        Me.PV3T.Text = "TT"
        '
        'Label5
        '
        Me.Label5.AutoSize = True
        Me.Label5.Font = New System.Drawing.Font("Arial", 9.75!, System.Drawing.FontStyle.Bold)
        Me.Label5.ImeMode = System.Windows.Forms.ImeMode.NoControl
        Me.Label5.Location = New System.Drawing.Point(592, 644)
        Me.Label5.Name = "Label5"
        Me.Label5.Size = New System.Drawing.Size(53, 16)
        Me.Label5.TabIndex = 87
        Me.Label5.Text = "TURNO"
        Me.Label5.Visible = False
        '
        'PA3T
        '
        Me.PA3T.AutoSize = True
        Me.PA3T.Font = New System.Drawing.Font("Arial", 6.75!)
        Me.PA3T.ImeMode = System.Windows.Forms.ImeMode.NoControl
        Me.PA3T.Location = New System.Drawing.Point(117, 301)
        Me.PA3T.Name = "PA3T"
        Me.PA3T.Size = New System.Drawing.Size(15, 12)
        Me.PA3T.TabIndex = 94
        Me.PA3T.Text = "TT"
        '
        'PE2T
        '
        Me.PE2T.AutoSize = True
        Me.PE2T.Font = New System.Drawing.Font("Arial", 6.75!)
        Me.PE2T.ImeMode = System.Windows.Forms.ImeMode.NoControl
        Me.PE2T.Location = New System.Drawing.Point(347, 199)
        Me.PE2T.Name = "PE2T"
        Me.PE2T.Size = New System.Drawing.Size(15, 12)
        Me.PE2T.TabIndex = 93
        Me.PE2T.Text = "TT"
        '
        'PV2T
        '
        Me.PV2T.AutoSize = True
        Me.PV2T.Font = New System.Drawing.Font("Arial", 6.75!)
        Me.PV2T.ImeMode = System.Windows.Forms.ImeMode.NoControl
        Me.PV2T.Location = New System.Drawing.Point(232, 199)
        Me.PV2T.Name = "PV2T"
        Me.PV2T.Size = New System.Drawing.Size(15, 12)
        Me.PV2T.TabIndex = 92
        Me.PV2T.Text = "TT"
        '
        'PA2T
        '
        Me.PA2T.AutoSize = True
        Me.PA2T.Font = New System.Drawing.Font("Arial", 6.75!)
        Me.PA2T.ImeMode = System.Windows.Forms.ImeMode.NoControl
        Me.PA2T.Location = New System.Drawing.Point(116, 199)
        Me.PA2T.Name = "PA2T"
        Me.PA2T.Size = New System.Drawing.Size(15, 12)
        Me.PA2T.TabIndex = 91
        Me.PA2T.Text = "TT"
        '
        'PE1T
        '
        Me.PE1T.AutoSize = True
        Me.PE1T.Font = New System.Drawing.Font("Arial", 6.75!)
        Me.PE1T.ImeMode = System.Windows.Forms.ImeMode.NoControl
        Me.PE1T.Location = New System.Drawing.Point(348, 100)
        Me.PE1T.Name = "PE1T"
        Me.PE1T.Size = New System.Drawing.Size(15, 12)
        Me.PE1T.TabIndex = 90
        Me.PE1T.Text = "TT"
        '
        'PV1T
        '
        Me.PV1T.AutoSize = True
        Me.PV1T.Font = New System.Drawing.Font("Arial", 6.75!)
        Me.PV1T.ImeMode = System.Windows.Forms.ImeMode.NoControl
        Me.PV1T.Location = New System.Drawing.Point(233, 100)
        Me.PV1T.Name = "PV1T"
        Me.PV1T.Size = New System.Drawing.Size(15, 12)
        Me.PV1T.TabIndex = 89
        Me.PV1T.Text = "TT"
        '
        'PA1T
        '
        Me.PA1T.AutoSize = True
        Me.PA1T.Font = New System.Drawing.Font("Arial", 6.75!)
        Me.PA1T.ImeMode = System.Windows.Forms.ImeMode.NoControl
        Me.PA1T.Location = New System.Drawing.Point(117, 100)
        Me.PA1T.Name = "PA1T"
        Me.PA1T.Size = New System.Drawing.Size(15, 12)
        Me.PA1T.TabIndex = 88
        Me.PA1T.Text = "TT"
        '
        'Label15
        '
        Me.Label15.AutoSize = True
        Me.Label15.Font = New System.Drawing.Font("Arial", 20.25!, System.Drawing.FontStyle.Bold)
        Me.Label15.ImeMode = System.Windows.Forms.ImeMode.NoControl
        Me.Label15.Location = New System.Drawing.Point(18, 93)
        Me.Label15.Name = "Label15"
        Me.Label15.Size = New System.Drawing.Size(47, 32)
        Me.Label15.TabIndex = 39
        Me.Label15.Text = "L1"
        '
        'Label16
        '
        Me.Label16.AutoSize = True
        Me.Label16.Font = New System.Drawing.Font("Arial", 20.25!, System.Drawing.FontStyle.Bold)
        Me.Label16.ImeMode = System.Windows.Forms.ImeMode.NoControl
        Me.Label16.Location = New System.Drawing.Point(18, 179)
        Me.Label16.Name = "Label16"
        Me.Label16.Size = New System.Drawing.Size(47, 32)
        Me.Label16.TabIndex = 40
        Me.Label16.Text = "L2"
        '
        'Label10
        '
        Me.Label10.AutoSize = True
        Me.Label10.Font = New System.Drawing.Font("Arial", 20.25!, System.Drawing.FontStyle.Bold)
        Me.Label10.ImeMode = System.Windows.Forms.ImeMode.NoControl
        Me.Label10.Location = New System.Drawing.Point(817, 556)
        Me.Label10.Name = "Label10"
        Me.Label10.Size = New System.Drawing.Size(62, 32)
        Me.Label10.TabIndex = 50
        Me.Label10.Text = "L13"
        '
        'Label8
        '
        Me.Label8.AutoSize = True
        Me.Label8.Font = New System.Drawing.Font("Arial", 20.25!, System.Drawing.FontStyle.Bold)
        Me.Label8.ImeMode = System.Windows.Forms.ImeMode.NoControl
        Me.Label8.Location = New System.Drawing.Point(818, 462)
        Me.Label8.Name = "Label8"
        Me.Label8.Size = New System.Drawing.Size(61, 32)
        Me.Label8.TabIndex = 50
        Me.Label8.Text = "L11"
        '
        'Label31
        '
        Me.Label31.AutoSize = True
        Me.Label31.Font = New System.Drawing.Font("Arial", 20.25!, System.Drawing.FontStyle.Bold)
        Me.Label31.ImeMode = System.Windows.Forms.ImeMode.NoControl
        Me.Label31.Location = New System.Drawing.Point(817, 362)
        Me.Label31.Name = "Label31"
        Me.Label31.Size = New System.Drawing.Size(62, 32)
        Me.Label31.TabIndex = 50
        Me.Label31.Text = "L10"
        '
        'Label30
        '
        Me.Label30.AutoSize = True
        Me.Label30.Font = New System.Drawing.Font("Arial", 20.25!, System.Drawing.FontStyle.Bold)
        Me.Label30.ImeMode = System.Windows.Forms.ImeMode.NoControl
        Me.Label30.Location = New System.Drawing.Point(832, 266)
        Me.Label30.Name = "Label30"
        Me.Label30.Size = New System.Drawing.Size(47, 32)
        Me.Label30.TabIndex = 49
        Me.Label30.Text = "L9"
        '
        'Label29
        '
        Me.Label29.AutoSize = True
        Me.Label29.Font = New System.Drawing.Font("Arial", 20.25!, System.Drawing.FontStyle.Bold)
        Me.Label29.ImeMode = System.Windows.Forms.ImeMode.NoControl
        Me.Label29.Location = New System.Drawing.Point(832, 176)
        Me.Label29.Name = "Label29"
        Me.Label29.Size = New System.Drawing.Size(47, 32)
        Me.Label29.TabIndex = 48
        Me.Label29.Text = "L8"
        '
        'LPA9
        '
        Me.LPA9.BackColor = System.Drawing.Color.Yellow
        Me.LPA9.Font = New System.Drawing.Font("Arial", 14.25!)
        Me.LPA9.ImeMode = System.Windows.Forms.ImeMode.NoControl
        Me.LPA9.Location = New System.Drawing.Point(897, 240)
        Me.LPA9.Name = "LPA9"
        Me.LPA9.Size = New System.Drawing.Size(100, 85)
        Me.LPA9.TabIndex = 38
        Me.LPA9.Text = "PA9"
        Me.LPA9.UseVisualStyleBackColor = False
        '
        'LPE13
        '
        Me.LPE13.BackColor = System.Drawing.Color.Red
        Me.LPE13.Font = New System.Drawing.Font("Arial", 14.25!)
        Me.LPE13.ImeMode = System.Windows.Forms.ImeMode.NoControl
        Me.LPE13.Location = New System.Drawing.Point(1133, 528)
        Me.LPE13.Name = "LPE13"
        Me.LPE13.Size = New System.Drawing.Size(100, 85)
        Me.LPE13.TabIndex = 35
        Me.LPE13.Text = "PE13"
        Me.LPE13.UseVisualStyleBackColor = False
        '
        'Label25
        '
        Me.Label25.AutoSize = True
        Me.Label25.Font = New System.Drawing.Font("Arial", 20.25!, System.Drawing.FontStyle.Bold)
        Me.Label25.ImeMode = System.Windows.Forms.ImeMode.NoControl
        Me.Label25.Location = New System.Drawing.Point(832, 82)
        Me.Label25.Name = "Label25"
        Me.Label25.Size = New System.Drawing.Size(47, 32)
        Me.Label25.TabIndex = 47
        Me.Label25.Text = "L7"
        '
        'LPE11
        '
        Me.LPE11.BackColor = System.Drawing.Color.Red
        Me.LPE11.Font = New System.Drawing.Font("Arial", 14.25!)
        Me.LPE11.ImeMode = System.Windows.Forms.ImeMode.NoControl
        Me.LPE11.Location = New System.Drawing.Point(1134, 434)
        Me.LPE11.Name = "LPE11"
        Me.LPE11.Size = New System.Drawing.Size(100, 85)
        Me.LPE11.TabIndex = 35
        Me.LPE11.Text = "PE11"
        Me.LPE11.UseVisualStyleBackColor = False
        '
        'LPE10
        '
        Me.LPE10.BackColor = System.Drawing.Color.Red
        Me.LPE10.Font = New System.Drawing.Font("Arial", 14.25!)
        Me.LPE10.ImeMode = System.Windows.Forms.ImeMode.NoControl
        Me.LPE10.Location = New System.Drawing.Point(1133, 334)
        Me.LPE10.Name = "LPE10"
        Me.LPE10.Size = New System.Drawing.Size(100, 85)
        Me.LPE10.TabIndex = 35
        Me.LPE10.Text = "PE10"
        Me.LPE10.UseVisualStyleBackColor = False
        '
        'LPV13
        '
        Me.LPV13.BackColor = System.Drawing.Color.DodgerBlue
        Me.LPV13.Font = New System.Drawing.Font("Arial", 14.25!)
        Me.LPV13.ImeMode = System.Windows.Forms.ImeMode.NoControl
        Me.LPV13.Location = New System.Drawing.Point(1013, 527)
        Me.LPV13.Name = "LPV13"
        Me.LPV13.Size = New System.Drawing.Size(100, 85)
        Me.LPV13.TabIndex = 34
        Me.LPV13.Text = "PV13"
        Me.LPV13.UseVisualStyleBackColor = False
        '
        'Label24
        '
        Me.Label24.AutoSize = True
        Me.Label24.Font = New System.Drawing.Font("Arial", 20.25!, System.Drawing.FontStyle.Bold)
        Me.Label24.ImeMode = System.Windows.Forms.ImeMode.NoControl
        Me.Label24.Location = New System.Drawing.Point(16, 572)
        Me.Label24.Name = "Label24"
        Me.Label24.Size = New System.Drawing.Size(47, 32)
        Me.Label24.TabIndex = 46
        Me.Label24.Text = "L6"
        '
        'LPV11
        '
        Me.LPV11.BackColor = System.Drawing.Color.DodgerBlue
        Me.LPV11.Font = New System.Drawing.Font("Arial", 14.25!)
        Me.LPV11.ImeMode = System.Windows.Forms.ImeMode.NoControl
        Me.LPV11.Location = New System.Drawing.Point(1014, 433)
        Me.LPV11.Name = "LPV11"
        Me.LPV11.Size = New System.Drawing.Size(100, 85)
        Me.LPV11.TabIndex = 34
        Me.LPV11.Text = "PV11"
        Me.LPV11.UseVisualStyleBackColor = False
        '
        'LPV10
        '
        Me.LPV10.BackColor = System.Drawing.Color.DodgerBlue
        Me.LPV10.Font = New System.Drawing.Font("Arial", 14.25!)
        Me.LPV10.ImeMode = System.Windows.Forms.ImeMode.NoControl
        Me.LPV10.Location = New System.Drawing.Point(1013, 333)
        Me.LPV10.Name = "LPV10"
        Me.LPV10.Size = New System.Drawing.Size(100, 85)
        Me.LPV10.TabIndex = 34
        Me.LPV10.Text = "PV10"
        Me.LPV10.UseVisualStyleBackColor = False
        '
        'LPA13
        '
        Me.LPA13.BackColor = System.Drawing.Color.Green
        Me.LPA13.Font = New System.Drawing.Font("Arial", 14.25!)
        Me.LPA13.ImeMode = System.Windows.Forms.ImeMode.NoControl
        Me.LPA13.Location = New System.Drawing.Point(897, 528)
        Me.LPA13.Name = "LPA13"
        Me.LPA13.Size = New System.Drawing.Size(100, 85)
        Me.LPA13.TabIndex = 33
        Me.LPA13.Text = "PA13"
        Me.LPA13.UseVisualStyleBackColor = False
        '
        'LPA1
        '
        Me.LPA1.BackColor = System.Drawing.Color.Green
        Me.LPA1.Font = New System.Drawing.Font("Arial", 14.25!)
        Me.LPA1.ImeMode = System.Windows.Forms.ImeMode.NoControl
        Me.LPA1.Location = New System.Drawing.Point(101, 40)
        Me.LPA1.Name = "LPA1"
        Me.LPA1.Size = New System.Drawing.Size(100, 85)
        Me.LPA1.TabIndex = 0
        Me.LPA1.Text = "PA1"
        Me.LPA1.UseVisualStyleBackColor = False
        '
        'LPA11
        '
        Me.LPA11.BackColor = System.Drawing.Color.Green
        Me.LPA11.Font = New System.Drawing.Font("Arial", 14.25!)
        Me.LPA11.ImeMode = System.Windows.Forms.ImeMode.NoControl
        Me.LPA11.Location = New System.Drawing.Point(898, 434)
        Me.LPA11.Name = "LPA11"
        Me.LPA11.Size = New System.Drawing.Size(100, 85)
        Me.LPA11.TabIndex = 33
        Me.LPA11.Text = "PA11"
        Me.LPA11.UseVisualStyleBackColor = False
        '
        'LPA10
        '
        Me.LPA10.BackColor = System.Drawing.Color.Green
        Me.LPA10.Font = New System.Drawing.Font("Arial", 14.25!)
        Me.LPA10.ImeMode = System.Windows.Forms.ImeMode.NoControl
        Me.LPA10.Location = New System.Drawing.Point(897, 334)
        Me.LPA10.Name = "LPA10"
        Me.LPA10.Size = New System.Drawing.Size(100, 85)
        Me.LPA10.TabIndex = 33
        Me.LPA10.Text = "PA10"
        Me.LPA10.UseVisualStyleBackColor = False
        '
        'Label27
        '
        Me.Label27.AutoSize = True
        Me.Label27.Font = New System.Drawing.Font("Arial", 20.25!, System.Drawing.FontStyle.Bold)
        Me.Label27.ImeMode = System.Windows.Forms.ImeMode.NoControl
        Me.Label27.Location = New System.Drawing.Point(18, 479)
        Me.Label27.Name = "Label27"
        Me.Label27.Size = New System.Drawing.Size(47, 32)
        Me.Label27.TabIndex = 45
        Me.Label27.Text = "L5"
        '
        'Label26
        '
        Me.Label26.AutoSize = True
        Me.Label26.Font = New System.Drawing.Font("Arial", 20.25!, System.Drawing.FontStyle.Bold)
        Me.Label26.ImeMode = System.Windows.Forms.ImeMode.NoControl
        Me.Label26.Location = New System.Drawing.Point(16, 382)
        Me.Label26.Name = "Label26"
        Me.Label26.Size = New System.Drawing.Size(47, 32)
        Me.Label26.TabIndex = 44
        Me.Label26.Text = "L4"
        '
        'LPE4
        '
        Me.LPE4.BackColor = System.Drawing.Color.Green
        Me.LPE4.Font = New System.Drawing.Font("Arial", 14.25!)
        Me.LPE4.ImeMode = System.Windows.Forms.ImeMode.NoControl
        Me.LPE4.Location = New System.Drawing.Point(330, 338)
        Me.LPE4.Name = "LPE4"
        Me.LPE4.Size = New System.Drawing.Size(100, 85)
        Me.LPE4.TabIndex = 28
        Me.LPE4.Text = "PE4"
        Me.LPE4.UseVisualStyleBackColor = False
        '
        'LPE9
        '
        Me.LPE9.BackColor = System.Drawing.Color.Red
        Me.LPE9.Font = New System.Drawing.Font("Arial", 14.25!)
        Me.LPE9.ImeMode = System.Windows.Forms.ImeMode.NoControl
        Me.LPE9.Location = New System.Drawing.Point(1133, 238)
        Me.LPE9.Name = "LPE9"
        Me.LPE9.Size = New System.Drawing.Size(100, 85)
        Me.LPE9.TabIndex = 37
        Me.LPE9.Text = "PE9"
        Me.LPE9.UseVisualStyleBackColor = False
        '
        'LPE1
        '
        Me.LPE1.BackColor = System.Drawing.Color.DodgerBlue
        Me.LPE1.Font = New System.Drawing.Font("Arial", 14.25!)
        Me.LPE1.ImeMode = System.Windows.Forms.ImeMode.NoControl
        Me.LPE1.Location = New System.Drawing.Point(333, 40)
        Me.LPE1.Name = "LPE1"
        Me.LPE1.Size = New System.Drawing.Size(100, 85)
        Me.LPE1.TabIndex = 3
        Me.LPE1.Text = "PE1"
        Me.LPE1.UseVisualStyleBackColor = False
        '
        'LPV8
        '
        Me.LPV8.BackColor = System.Drawing.Color.DodgerBlue
        Me.LPV8.Font = New System.Drawing.Font("Arial", 14.25!)
        Me.LPV8.ImeMode = System.Windows.Forms.ImeMode.NoControl
        Me.LPV8.Location = New System.Drawing.Point(1013, 146)
        Me.LPV8.Name = "LPV8"
        Me.LPV8.Size = New System.Drawing.Size(100, 85)
        Me.LPV8.TabIndex = 27
        Me.LPV8.Text = "PV8"
        Me.LPV8.UseVisualStyleBackColor = False
        '
        'LPV5
        '
        Me.LPV5.BackColor = System.Drawing.Color.DodgerBlue
        Me.LPV5.Font = New System.Drawing.Font("Arial", 14.25!)
        Me.LPV5.ImeMode = System.Windows.Forms.ImeMode.NoControl
        Me.LPV5.Location = New System.Drawing.Point(217, 437)
        Me.LPV5.Name = "LPV5"
        Me.LPV5.Size = New System.Drawing.Size(100, 85)
        Me.LPV5.TabIndex = 36
        Me.LPV5.Text = "PV5"
        Me.LPV5.UseVisualStyleBackColor = False
        '
        'LPA8
        '
        Me.LPA8.BackColor = System.Drawing.Color.Green
        Me.LPA8.Font = New System.Drawing.Font("Arial", 14.25!)
        Me.LPA8.ImeMode = System.Windows.Forms.ImeMode.NoControl
        Me.LPA8.Location = New System.Drawing.Point(897, 145)
        Me.LPA8.Name = "LPA8"
        Me.LPA8.Size = New System.Drawing.Size(100, 85)
        Me.LPA8.TabIndex = 23
        Me.LPA8.Text = "PA8"
        Me.LPA8.UseVisualStyleBackColor = False
        '
        'LPE5
        '
        Me.LPE5.BackColor = System.Drawing.Color.Red
        Me.LPE5.Font = New System.Drawing.Font("Arial", 14.25!)
        Me.LPE5.ImeMode = System.Windows.Forms.ImeMode.NoControl
        Me.LPE5.Location = New System.Drawing.Point(333, 437)
        Me.LPE5.Name = "LPE5"
        Me.LPE5.Size = New System.Drawing.Size(100, 85)
        Me.LPE5.TabIndex = 31
        Me.LPE5.Text = "PE5"
        Me.LPE5.UseVisualStyleBackColor = False
        '
        'LPE7
        '
        Me.LPE7.BackColor = System.Drawing.Color.Red
        Me.LPE7.Font = New System.Drawing.Font("Arial", 14.25!)
        Me.LPE7.ImeMode = System.Windows.Forms.ImeMode.NoControl
        Me.LPE7.Location = New System.Drawing.Point(1133, 44)
        Me.LPE7.Name = "LPE7"
        Me.LPE7.Size = New System.Drawing.Size(100, 85)
        Me.LPE7.TabIndex = 32
        Me.LPE7.Text = "PE7"
        Me.LPE7.UseVisualStyleBackColor = False
        '
        'LPE6
        '
        Me.LPE6.BackColor = System.Drawing.Color.Red
        Me.LPE6.Font = New System.Drawing.Font("Arial", 14.25!)
        Me.LPE6.ImeMode = System.Windows.Forms.ImeMode.NoControl
        Me.LPE6.Location = New System.Drawing.Point(330, 528)
        Me.LPE6.Name = "LPE6"
        Me.LPE6.Size = New System.Drawing.Size(100, 85)
        Me.LPE6.TabIndex = 22
        Me.LPE6.Text = "PE6"
        Me.LPE6.UseVisualStyleBackColor = False
        '
        'Label17
        '
        Me.Label17.AutoSize = True
        Me.Label17.Font = New System.Drawing.Font("Arial", 20.25!, System.Drawing.FontStyle.Bold)
        Me.Label17.ImeMode = System.Windows.Forms.ImeMode.NoControl
        Me.Label17.Location = New System.Drawing.Point(18, 278)
        Me.Label17.Name = "Label17"
        Me.Label17.Size = New System.Drawing.Size(47, 32)
        Me.Label17.TabIndex = 41
        Me.Label17.Text = "L3"
        '
        'LPV7
        '
        Me.LPV7.BackColor = System.Drawing.Color.DodgerBlue
        Me.LPV7.Font = New System.Drawing.Font("Arial", 14.25!)
        Me.LPV7.ImeMode = System.Windows.Forms.ImeMode.NoControl
        Me.LPV7.Location = New System.Drawing.Point(1013, 44)
        Me.LPV7.Name = "LPV7"
        Me.LPV7.Size = New System.Drawing.Size(100, 85)
        Me.LPV7.TabIndex = 21
        Me.LPV7.Text = "PV7"
        Me.LPV7.UseVisualStyleBackColor = False
        '
        'LPV6
        '
        Me.LPV6.BackColor = System.Drawing.Color.DodgerBlue
        Me.LPV6.Font = New System.Drawing.Font("Arial", 14.25!)
        Me.LPV6.ImeMode = System.Windows.Forms.ImeMode.NoControl
        Me.LPV6.Location = New System.Drawing.Point(217, 528)
        Me.LPV6.Name = "LPV6"
        Me.LPV6.Size = New System.Drawing.Size(100, 85)
        Me.LPV6.TabIndex = 17
        Me.LPV6.Text = "PV6"
        Me.LPV6.UseVisualStyleBackColor = False
        '
        'LPV1
        '
        Me.LPV1.BackColor = System.Drawing.Color.Red
        Me.LPV1.Font = New System.Drawing.Font("Arial", 14.25!)
        Me.LPV1.ImeMode = System.Windows.Forms.ImeMode.NoControl
        Me.LPV1.Location = New System.Drawing.Point(217, 40)
        Me.LPV1.Name = "LPV1"
        Me.LPV1.Size = New System.Drawing.Size(100, 85)
        Me.LPV1.TabIndex = 1
        Me.LPV1.Text = "PV1"
        Me.LPV1.UseVisualStyleBackColor = False
        '
        'LPA5
        '
        Me.LPA5.BackColor = System.Drawing.Color.Green
        Me.LPA5.Font = New System.Drawing.Font("Arial", 14.25!)
        Me.LPA5.ImeMode = System.Windows.Forms.ImeMode.NoControl
        Me.LPA5.Location = New System.Drawing.Point(101, 437)
        Me.LPA5.Name = "LPA5"
        Me.LPA5.Size = New System.Drawing.Size(100, 85)
        Me.LPA5.TabIndex = 30
        Me.LPA5.Text = "PA5"
        Me.LPA5.UseVisualStyleBackColor = False
        '
        'LPA4
        '
        Me.LPA4.BackColor = System.Drawing.Color.Green
        Me.LPA4.Font = New System.Drawing.Font("Arial", 14.25!)
        Me.LPA4.ImeMode = System.Windows.Forms.ImeMode.NoControl
        Me.LPA4.Location = New System.Drawing.Point(101, 339)
        Me.LPA4.Name = "LPA4"
        Me.LPA4.Size = New System.Drawing.Size(100, 85)
        Me.LPA4.TabIndex = 6
        Me.LPA4.Text = "PA4"
        Me.LPA4.UseVisualStyleBackColor = False
        '
        'LPE2
        '
        Me.LPE2.BackColor = System.Drawing.Color.Red
        Me.LPE2.Font = New System.Drawing.Font("Arial", 14.25!)
        Me.LPE2.ImeMode = System.Windows.Forms.ImeMode.NoControl
        Me.LPE2.Location = New System.Drawing.Point(333, 136)
        Me.LPE2.Name = "LPE2"
        Me.LPE2.Size = New System.Drawing.Size(100, 85)
        Me.LPE2.TabIndex = 9
        Me.LPE2.Text = "PE2"
        Me.LPE2.UseVisualStyleBackColor = False
        '
        'LPV2
        '
        Me.LPV2.BackColor = System.Drawing.Color.DodgerBlue
        Me.LPV2.Font = New System.Drawing.Font("Arial", 14.25!)
        Me.LPV2.ImeMode = System.Windows.Forms.ImeMode.NoControl
        Me.LPV2.Location = New System.Drawing.Point(217, 136)
        Me.LPV2.Name = "LPV2"
        Me.LPV2.Size = New System.Drawing.Size(100, 85)
        Me.LPV2.TabIndex = 7
        Me.LPV2.Text = "PV2"
        Me.LPV2.UseVisualStyleBackColor = False
        '
        'LPA2
        '
        Me.LPA2.BackColor = System.Drawing.Color.Green
        Me.LPA2.Font = New System.Drawing.Font("Arial", 14.25!)
        Me.LPA2.ImeMode = System.Windows.Forms.ImeMode.NoControl
        Me.LPA2.Location = New System.Drawing.Point(101, 136)
        Me.LPA2.Name = "LPA2"
        Me.LPA2.Size = New System.Drawing.Size(100, 85)
        Me.LPA2.TabIndex = 12
        Me.LPA2.Text = "PA2"
        Me.LPA2.UseVisualStyleBackColor = False
        '
        'LPA7
        '
        Me.LPA7.BackColor = System.Drawing.Color.Green
        Me.LPA7.Font = New System.Drawing.Font("Arial", 14.25!)
        Me.LPA7.ImeMode = System.Windows.Forms.ImeMode.NoControl
        Me.LPA7.Location = New System.Drawing.Point(897, 44)
        Me.LPA7.Name = "LPA7"
        Me.LPA7.Size = New System.Drawing.Size(100, 85)
        Me.LPA7.TabIndex = 14
        Me.LPA7.Text = "PA7"
        Me.LPA7.UseVisualStyleBackColor = False
        '
        'LPV3
        '
        Me.LPV3.BackColor = System.Drawing.Color.DodgerBlue
        Me.LPV3.Font = New System.Drawing.Font("Arial", 14.25!)
        Me.LPV3.ImeMode = System.Windows.Forms.ImeMode.NoControl
        Me.LPV3.Location = New System.Drawing.Point(217, 239)
        Me.LPV3.Name = "LPV3"
        Me.LPV3.Size = New System.Drawing.Size(100, 85)
        Me.LPV3.TabIndex = 13
        Me.LPV3.Text = "PV3"
        Me.LPV3.UseVisualStyleBackColor = False
        '
        'LPA3
        '
        Me.LPA3.BackColor = System.Drawing.Color.Green
        Me.LPA3.Font = New System.Drawing.Font("Arial", 14.25!)
        Me.LPA3.ImeMode = System.Windows.Forms.ImeMode.NoControl
        Me.LPA3.Location = New System.Drawing.Point(101, 239)
        Me.LPA3.Name = "LPA3"
        Me.LPA3.Size = New System.Drawing.Size(100, 85)
        Me.LPA3.TabIndex = 26
        Me.LPA3.Text = "PA3"
        Me.LPA3.UseVisualStyleBackColor = False
        '
        'LPE3
        '
        Me.LPE3.BackColor = System.Drawing.Color.Red
        Me.LPE3.Font = New System.Drawing.Font("Arial", 14.25!)
        Me.LPE3.ImeMode = System.Windows.Forms.ImeMode.NoControl
        Me.LPE3.Location = New System.Drawing.Point(333, 239)
        Me.LPE3.Name = "LPE3"
        Me.LPE3.Size = New System.Drawing.Size(100, 85)
        Me.LPE3.TabIndex = 16
        Me.LPE3.Text = "PE3"
        Me.LPE3.UseVisualStyleBackColor = False
        '
        'LPA6
        '
        Me.LPA6.BackColor = System.Drawing.Color.Green
        Me.LPA6.Font = New System.Drawing.Font("Arial", 14.25!)
        Me.LPA6.ImeMode = System.Windows.Forms.ImeMode.NoControl
        Me.LPA6.Location = New System.Drawing.Point(101, 528)
        Me.LPA6.Name = "LPA6"
        Me.LPA6.Size = New System.Drawing.Size(100, 85)
        Me.LPA6.TabIndex = 18
        Me.LPA6.Text = "PA6"
        Me.LPA6.UseVisualStyleBackColor = False
        '
        'LPV4
        '
        Me.LPV4.BackColor = System.Drawing.Color.DodgerBlue
        Me.LPV4.Font = New System.Drawing.Font("Arial", 14.25!)
        Me.LPV4.ImeMode = System.Windows.Forms.ImeMode.NoControl
        Me.LPV4.Location = New System.Drawing.Point(217, 338)
        Me.LPV4.Name = "LPV4"
        Me.LPV4.Size = New System.Drawing.Size(100, 85)
        Me.LPV4.TabIndex = 24
        Me.LPV4.Text = "PV4"
        Me.LPV4.UseVisualStyleBackColor = False
        '
        'LPV9
        '
        Me.LPV9.BackColor = System.Drawing.Color.Red
        Me.LPV9.Font = New System.Drawing.Font("Arial", 14.25!)
        Me.LPV9.ImeMode = System.Windows.Forms.ImeMode.NoControl
        Me.LPV9.Location = New System.Drawing.Point(1013, 239)
        Me.LPV9.Name = "LPV9"
        Me.LPV9.Size = New System.Drawing.Size(100, 85)
        Me.LPV9.TabIndex = 19
        Me.LPV9.Text = "PV9"
        Me.LPV9.UseVisualStyleBackColor = False
        '
        'LPE8
        '
        Me.LPE8.BackColor = System.Drawing.Color.Red
        Me.LPE8.Font = New System.Drawing.Font("Arial", 14.25!)
        Me.LPE8.ImeMode = System.Windows.Forms.ImeMode.NoControl
        Me.LPE8.Location = New System.Drawing.Point(1133, 145)
        Me.LPE8.Name = "LPE8"
        Me.LPE8.Size = New System.Drawing.Size(100, 85)
        Me.LPE8.TabIndex = 20
        Me.LPE8.Text = "PE8"
        Me.LPE8.UseVisualStyleBackColor = False
        '
        'TabHistorial
        '
        Me.TabHistorial.Controls.Add(Me.Lineas)
        Me.TabHistorial.Controls.Add(Me.Tooling)
        Me.TabHistorial.Controls.Add(Me.InformacionHH)
        Me.TabHistorial.Controls.Add(Me.tpEstacion1)
        Me.TabHistorial.Controls.Add(Me.tpEstacion2)
        Me.TabHistorial.Controls.Add(Me.tpEstacion3)
        Me.TabHistorial.Location = New System.Drawing.Point(0, 136)
        Me.TabHistorial.Name = "TabHistorial"
        Me.TabHistorial.SelectedIndex = 0
        Me.TabHistorial.Size = New System.Drawing.Size(1245, 710)
        Me.TabHistorial.TabIndex = 6
        '
        'tpEstacion2
        '
        Me.tpEstacion2.Controls.Add(Me.Label7)
        Me.tpEstacion2.Controls.Add(Me.GridChangeTool2)
        Me.tpEstacion2.Controls.Add(Me.btnRevisarE2)
        Me.tpEstacion2.Controls.Add(Me.btnRepararE2)
        Me.tpEstacion2.Controls.Add(Me.Label88)
        Me.tpEstacion2.Controls.Add(Me.txtVidaE2)
        Me.tpEstacion2.Controls.Add(Me.txtUsoE2)
        Me.tpEstacion2.Controls.Add(Me.Label90)
        Me.tpEstacion2.Controls.Add(Me.txtEmpE2)
        Me.tpEstacion2.Controls.Add(Me.Label91)
        Me.tpEstacion2.Controls.Add(Me.Label92)
        Me.tpEstacion2.Controls.Add(Me.Label93)
        Me.tpEstacion2.Controls.Add(Me.txtTurnoE2)
        Me.tpEstacion2.Controls.Add(Me.txtLadoE2)
        Me.tpEstacion2.Controls.Add(Me.txtPrensaE2)
        Me.tpEstacion2.Controls.Add(Me.txtLineaE2)
        Me.tpEstacion2.Controls.Add(Me.txtHoraE2)
        Me.tpEstacion2.Controls.Add(Me.txtFechE2)
        Me.tpEstacion2.Controls.Add(Me.txtTecE2)
        Me.tpEstacion2.Controls.Add(Me.txtLainaE2)
        Me.tpEstacion2.Controls.Add(Me.txtGreenE2)
        Me.tpEstacion2.Controls.Add(Me.txtAntE2)
        Me.tpEstacion2.Controls.Add(Me.Label94)
        Me.tpEstacion2.Controls.Add(Me.Label95)
        Me.tpEstacion2.Controls.Add(Me.Label96)
        Me.tpEstacion2.Controls.Add(Me.Label97)
        Me.tpEstacion2.Controls.Add(Me.Label98)
        Me.tpEstacion2.Controls.Add(Me.Label99)
        Me.tpEstacion2.Controls.Add(Me.Label100)
        Me.tpEstacion2.Controls.Add(Me.Label101)
        Me.tpEstacion2.Controls.Add(Me.Label102)
        Me.tpEstacion2.Controls.Add(Me.txtToolE2)
        Me.tpEstacion2.Controls.Add(Me.PE13TS)
        Me.tpEstacion2.Controls.Add(Me.PE11TS)
        Me.tpEstacion2.Controls.Add(Me.PE10TS)
        Me.tpEstacion2.Controls.Add(Me.PV13TS)
        Me.tpEstacion2.Controls.Add(Me.PV11TS)
        Me.tpEstacion2.Controls.Add(Me.PV10TS)
        Me.tpEstacion2.Controls.Add(Me.PA13TS)
        Me.tpEstacion2.Controls.Add(Me.PA11TS)
        Me.tpEstacion2.Controls.Add(Me.PA10TS)
        Me.tpEstacion2.Controls.Add(Me.PE9TS)
        Me.tpEstacion2.Controls.Add(Me.PV9TS)
        Me.tpEstacion2.Controls.Add(Me.PA9TS)
        Me.tpEstacion2.Controls.Add(Me.PE8TS)
        Me.tpEstacion2.Controls.Add(Me.PV8TS)
        Me.tpEstacion2.Controls.Add(Me.PA8TS)
        Me.tpEstacion2.Controls.Add(Me.PE7TS)
        Me.tpEstacion2.Controls.Add(Me.PV7TS)
        Me.tpEstacion2.Controls.Add(Me.PA7TS)
        Me.tpEstacion2.Controls.Add(Me.Label11)
        Me.tpEstacion2.Controls.Add(Me.Label9)
        Me.tpEstacion2.Controls.Add(Me.Label62)
        Me.tpEstacion2.Controls.Add(Me.Label63)
        Me.tpEstacion2.Controls.Add(Me.Label64)
        Me.tpEstacion2.Controls.Add(Me.LPA9S)
        Me.tpEstacion2.Controls.Add(Me.Label65)
        Me.tpEstacion2.Controls.Add(Me.LPE13S)
        Me.tpEstacion2.Controls.Add(Me.LPE11S)
        Me.tpEstacion2.Controls.Add(Me.LPV13S)
        Me.tpEstacion2.Controls.Add(Me.LPE10S)
        Me.tpEstacion2.Controls.Add(Me.LPA13S)
        Me.tpEstacion2.Controls.Add(Me.LPV11S)
        Me.tpEstacion2.Controls.Add(Me.LPA11S)
        Me.tpEstacion2.Controls.Add(Me.LPV10S)
        Me.tpEstacion2.Controls.Add(Me.LPA10S)
        Me.tpEstacion2.Controls.Add(Me.LPE9S)
        Me.tpEstacion2.Controls.Add(Me.LPV8S)
        Me.tpEstacion2.Controls.Add(Me.LPA8S)
        Me.tpEstacion2.Controls.Add(Me.LPE7S)
        Me.tpEstacion2.Controls.Add(Me.LPV7S)
        Me.tpEstacion2.Controls.Add(Me.LPA7S)
        Me.tpEstacion2.Controls.Add(Me.LPV9S)
        Me.tpEstacion2.Controls.Add(Me.LPE8S)
        Me.tpEstacion2.Location = New System.Drawing.Point(4, 23)
        Me.tpEstacion2.Name = "tpEstacion2"
        Me.tpEstacion2.Padding = New System.Windows.Forms.Padding(3)
        Me.tpEstacion2.Size = New System.Drawing.Size(1237, 683)
        Me.tpEstacion2.TabIndex = 6
        Me.tpEstacion2.Text = "Estacion2"
        Me.tpEstacion2.UseVisualStyleBackColor = True
        '
        'Label7
        '
        Me.Label7.BackColor = System.Drawing.SystemColors.ButtonHighlight
        Me.Label7.Font = New System.Drawing.Font("Microsoft Sans Serif", 18.0!, System.Drawing.FontStyle.Bold)
        Me.Label7.ForeColor = System.Drawing.Color.Black
        Me.Label7.Location = New System.Drawing.Point(810, 274)
        Me.Label7.Name = "Label7"
        Me.Label7.Size = New System.Drawing.Size(331, 25)
        Me.Label7.TabIndex = 196
        Me.Label7.Text = "CAMBIOS SOLICITADO"
        Me.Label7.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'GridChangeTool2
        '
        Me.GridChangeTool2.AllowUserToAddRows = False
        Me.GridChangeTool2.AllowUserToDeleteRows = False
        Me.GridChangeTool2.AllowUserToResizeColumns = False
        Me.GridChangeTool2.AllowUserToResizeRows = False
        Me.GridChangeTool2.BorderStyle = System.Windows.Forms.BorderStyle.None
        Me.GridChangeTool2.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize
        Me.GridChangeTool2.Location = New System.Drawing.Point(408, 304)
        Me.GridChangeTool2.MultiSelect = False
        Me.GridChangeTool2.Name = "GridChangeTool2"
        Me.GridChangeTool2.ReadOnly = True
        Me.GridChangeTool2.RowHeadersVisible = False
        Me.GridChangeTool2.RowHeadersWidth = 10
        DataGridViewCellStyle5.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.GridChangeTool2.RowsDefaultCellStyle = DataGridViewCellStyle5
        Me.GridChangeTool2.RowTemplate.Height = 25
        Me.GridChangeTool2.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.FullRowSelect
        Me.GridChangeTool2.Size = New System.Drawing.Size(737, 271)
        Me.GridChangeTool2.TabIndex = 195
        '
        'btnRevisarE2
        '
        Me.btnRevisarE2.Font = New System.Drawing.Font("Arial", 20.25!, System.Drawing.FontStyle.Bold)
        Me.btnRevisarE2.ImeMode = System.Windows.Forms.ImeMode.NoControl
        Me.btnRevisarE2.Location = New System.Drawing.Point(14, 513)
        Me.btnRevisarE2.Name = "btnRevisarE2"
        Me.btnRevisarE2.Size = New System.Drawing.Size(161, 62)
        Me.btnRevisarE2.TabIndex = 194
        Me.btnRevisarE2.Text = "REVISAR"
        '
        'btnRepararE2
        '
        Me.btnRepararE2.Font = New System.Drawing.Font("Arial", 20.25!, System.Drawing.FontStyle.Bold)
        Me.btnRepararE2.ImeMode = System.Windows.Forms.ImeMode.NoControl
        Me.btnRepararE2.Location = New System.Drawing.Point(235, 511)
        Me.btnRepararE2.Name = "btnRepararE2"
        Me.btnRepararE2.Size = New System.Drawing.Size(167, 64)
        Me.btnRepararE2.TabIndex = 193
        Me.btnRepararE2.Text = "REPARAR"
        '
        'Label88
        '
        Me.Label88.AutoSize = True
        Me.Label88.Font = New System.Drawing.Font("Arial", 9.75!, System.Drawing.FontStyle.Bold)
        Me.Label88.ImeMode = System.Windows.Forms.ImeMode.NoControl
        Me.Label88.Location = New System.Drawing.Point(540, 186)
        Me.Label88.Name = "Label88"
        Me.Label88.Size = New System.Drawing.Size(72, 16)
        Me.Label88.TabIndex = 192
        Me.Label88.Text = "VIDA UTIL"
        Me.Label88.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'txtVidaE2
        '
        Me.txtVidaE2.Font = New System.Drawing.Font("Microsoft Sans Serif", 15.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.txtVidaE2.ForeColor = System.Drawing.Color.Black
        Me.txtVidaE2.Location = New System.Drawing.Point(539, 205)
        Me.txtVidaE2.Name = "txtVidaE2"
        Me.txtVidaE2.Size = New System.Drawing.Size(142, 31)
        Me.txtVidaE2.TabIndex = 191
        '
        'txtUsoE2
        '
        Me.txtUsoE2.Font = New System.Drawing.Font("Microsoft Sans Serif", 15.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.txtUsoE2.ForeColor = System.Drawing.Color.Black
        Me.txtUsoE2.Location = New System.Drawing.Point(687, 205)
        Me.txtUsoE2.Name = "txtUsoE2"
        Me.txtUsoE2.Size = New System.Drawing.Size(186, 31)
        Me.txtUsoE2.TabIndex = 189
        '
        'Label90
        '
        Me.Label90.AutoSize = True
        Me.Label90.Font = New System.Drawing.Font("Arial", 9.75!, System.Drawing.FontStyle.Bold)
        Me.Label90.ImeMode = System.Windows.Forms.ImeMode.NoControl
        Me.Label90.Location = New System.Drawing.Point(692, 186)
        Me.Label90.Name = "Label90"
        Me.Label90.Size = New System.Drawing.Size(111, 16)
        Me.Label90.TabIndex = 188
        Me.Label90.Text = "TIEMPO DE USO"
        '
        'txtEmpE2
        '
        Me.txtEmpE2.Font = New System.Drawing.Font("Microsoft Sans Serif", 15.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.txtEmpE2.ForeColor = System.Drawing.Color.Black
        Me.txtEmpE2.Location = New System.Drawing.Point(408, 30)
        Me.txtEmpE2.Name = "txtEmpE2"
        Me.txtEmpE2.Size = New System.Drawing.Size(120, 31)
        Me.txtEmpE2.TabIndex = 187
        '
        'Label91
        '
        Me.Label91.AutoSize = True
        Me.Label91.Font = New System.Drawing.Font("Arial", 9.75!, System.Drawing.FontStyle.Bold)
        Me.Label91.ImeMode = System.Windows.Forms.ImeMode.NoControl
        Me.Label91.Location = New System.Drawing.Point(405, 9)
        Me.Label91.Name = "Label91"
        Me.Label91.Size = New System.Drawing.Size(113, 16)
        Me.Label91.TabIndex = 186
        Me.Label91.Text = "NUM EMPLEADO"
        '
        'Label92
        '
        Me.Label92.AutoSize = True
        Me.Label92.Font = New System.Drawing.Font("Arial", 9.75!, System.Drawing.FontStyle.Bold)
        Me.Label92.ImeMode = System.Windows.Forms.ImeMode.NoControl
        Me.Label92.Location = New System.Drawing.Point(546, 9)
        Me.Label92.Name = "Label92"
        Me.Label92.Size = New System.Drawing.Size(113, 16)
        Me.Label92.TabIndex = 185
        Me.Label92.Text = "TEC/AUX -MTTO."
        '
        'Label93
        '
        Me.Label93.AutoSize = True
        Me.Label93.Font = New System.Drawing.Font("Arial", 9.75!, System.Drawing.FontStyle.Bold)
        Me.Label93.ImeMode = System.Windows.Forms.ImeMode.NoControl
        Me.Label93.Location = New System.Drawing.Point(702, 249)
        Me.Label93.Name = "Label93"
        Me.Label93.Size = New System.Drawing.Size(132, 16)
        Me.Label93.TabIndex = 184
        Me.Label93.Text = "LAINA (DIMENSION)"
        '
        'txtTurnoE2
        '
        Me.txtTurnoE2.Font = New System.Drawing.Font("Microsoft Sans Serif", 15.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.txtTurnoE2.ForeColor = System.Drawing.Color.Black
        Me.txtTurnoE2.Location = New System.Drawing.Point(796, 142)
        Me.txtTurnoE2.Name = "txtTurnoE2"
        Me.txtTurnoE2.Size = New System.Drawing.Size(77, 31)
        Me.txtTurnoE2.TabIndex = 183
        '
        'txtLadoE2
        '
        Me.txtLadoE2.Font = New System.Drawing.Font("Microsoft Sans Serif", 15.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.txtLadoE2.ForeColor = System.Drawing.Color.Black
        Me.txtLadoE2.Location = New System.Drawing.Point(695, 87)
        Me.txtLadoE2.Name = "txtLadoE2"
        Me.txtLadoE2.Size = New System.Drawing.Size(100, 31)
        Me.txtLadoE2.TabIndex = 182
        '
        'txtPrensaE2
        '
        Me.txtPrensaE2.Font = New System.Drawing.Font("Microsoft Sans Serif", 15.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.txtPrensaE2.ForeColor = System.Drawing.Color.Black
        Me.txtPrensaE2.Location = New System.Drawing.Point(543, 87)
        Me.txtPrensaE2.Name = "txtPrensaE2"
        Me.txtPrensaE2.Size = New System.Drawing.Size(120, 31)
        Me.txtPrensaE2.TabIndex = 181
        '
        'txtLineaE2
        '
        Me.txtLineaE2.CausesValidation = False
        Me.txtLineaE2.Font = New System.Drawing.Font("Microsoft Sans Serif", 15.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.txtLineaE2.ForeColor = System.Drawing.Color.Black
        Me.txtLineaE2.Location = New System.Drawing.Point(408, 87)
        Me.txtLineaE2.Name = "txtLineaE2"
        Me.txtLineaE2.Size = New System.Drawing.Size(100, 31)
        Me.txtLineaE2.TabIndex = 180
        '
        'txtHoraE2
        '
        Me.txtHoraE2.Font = New System.Drawing.Font("Microsoft Sans Serif", 15.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.txtHoraE2.ForeColor = System.Drawing.Color.Black
        Me.txtHoraE2.Location = New System.Drawing.Point(408, 142)
        Me.txtHoraE2.Name = "txtHoraE2"
        Me.txtHoraE2.Size = New System.Drawing.Size(175, 31)
        Me.txtHoraE2.TabIndex = 179
        '
        'txtFechE2
        '
        Me.txtFechE2.Font = New System.Drawing.Font("Microsoft Sans Serif", 15.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.txtFechE2.ForeColor = System.Drawing.Color.Black
        Me.txtFechE2.Location = New System.Drawing.Point(589, 142)
        Me.txtFechE2.Name = "txtFechE2"
        Me.txtFechE2.Size = New System.Drawing.Size(191, 31)
        Me.txtFechE2.TabIndex = 178
        '
        'txtTecE2
        '
        Me.txtTecE2.Font = New System.Drawing.Font("Microsoft Sans Serif", 15.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.txtTecE2.ForeColor = System.Drawing.Color.Black
        Me.txtTecE2.Location = New System.Drawing.Point(549, 30)
        Me.txtTecE2.Name = "txtTecE2"
        Me.txtTecE2.Size = New System.Drawing.Size(174, 31)
        Me.txtTecE2.TabIndex = 177
        '
        'txtLainaE2
        '
        Me.txtLainaE2.Font = New System.Drawing.Font("Microsoft Sans Serif", 15.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.txtLainaE2.ForeColor = System.Drawing.Color.Black
        Me.txtLainaE2.Location = New System.Drawing.Point(705, 268)
        Me.txtLainaE2.Name = "txtLainaE2"
        Me.txtLainaE2.Size = New System.Drawing.Size(129, 31)
        Me.txtLainaE2.TabIndex = 176
        '
        'txtGreenE2
        '
        Me.txtGreenE2.Font = New System.Drawing.Font("Microsoft Sans Serif", 15.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.txtGreenE2.ForeColor = System.Drawing.Color.Black
        Me.txtGreenE2.Location = New System.Drawing.Point(543, 267)
        Me.txtGreenE2.Name = "txtGreenE2"
        Me.txtGreenE2.Size = New System.Drawing.Size(144, 31)
        Me.txtGreenE2.TabIndex = 175
        '
        'txtAntE2
        '
        Me.txtAntE2.Font = New System.Drawing.Font("Microsoft Sans Serif", 15.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.txtAntE2.ForeColor = System.Drawing.Color.Black
        Me.txtAntE2.Location = New System.Drawing.Point(411, 267)
        Me.txtAntE2.Name = "txtAntE2"
        Me.txtAntE2.Size = New System.Drawing.Size(126, 31)
        Me.txtAntE2.TabIndex = 174
        '
        'Label94
        '
        Me.Label94.AutoSize = True
        Me.Label94.Font = New System.Drawing.Font("Arial", 9.75!, System.Drawing.FontStyle.Bold)
        Me.Label94.ImeMode = System.Windows.Forms.ImeMode.NoControl
        Me.Label94.Location = New System.Drawing.Point(409, 68)
        Me.Label94.Name = "Label94"
        Me.Label94.Size = New System.Drawing.Size(46, 16)
        Me.Label94.TabIndex = 173
        Me.Label94.Text = "LINEA"
        '
        'Label95
        '
        Me.Label95.AutoSize = True
        Me.Label95.Font = New System.Drawing.Font("Arial", 9.75!, System.Drawing.FontStyle.Bold)
        Me.Label95.ImeMode = System.Windows.Forms.ImeMode.NoControl
        Me.Label95.Location = New System.Drawing.Point(546, 249)
        Me.Label95.Name = "Label95"
        Me.Label95.Size = New System.Drawing.Size(97, 16)
        Me.Label95.TabIndex = 172
        Me.Label95.Text = "GREEN PLATE"
        '
        'Label96
        '
        Me.Label96.AutoSize = True
        Me.Label96.Font = New System.Drawing.Font("Arial", 9.75!, System.Drawing.FontStyle.Bold)
        Me.Label96.ImeMode = System.Windows.Forms.ImeMode.NoControl
        Me.Label96.Location = New System.Drawing.Point(409, 249)
        Me.Label96.Name = "Label96"
        Me.Label96.Size = New System.Drawing.Size(104, 16)
        Me.Label96.TabIndex = 171
        Me.Label96.Text = "TOOLING. ANT."
        '
        'Label97
        '
        Me.Label97.AutoSize = True
        Me.Label97.Font = New System.Drawing.Font("Arial", 9.75!, System.Drawing.FontStyle.Bold)
        Me.Label97.ImeMode = System.Windows.Forms.ImeMode.NoControl
        Me.Label97.Location = New System.Drawing.Point(409, 186)
        Me.Label97.Name = "Label97"
        Me.Label97.Size = New System.Drawing.Size(67, 16)
        Me.Label97.TabIndex = 170
        Me.Label97.Text = "TOOLING"
        '
        'Label98
        '
        Me.Label98.AutoSize = True
        Me.Label98.Font = New System.Drawing.Font("Arial", 9.75!, System.Drawing.FontStyle.Bold)
        Me.Label98.ImeMode = System.Windows.Forms.ImeMode.NoControl
        Me.Label98.Location = New System.Drawing.Point(799, 123)
        Me.Label98.Name = "Label98"
        Me.Label98.Size = New System.Drawing.Size(53, 16)
        Me.Label98.TabIndex = 169
        Me.Label98.Text = "TURNO"
        '
        'Label99
        '
        Me.Label99.AutoSize = True
        Me.Label99.Font = New System.Drawing.Font("Arial", 9.75!, System.Drawing.FontStyle.Bold)
        Me.Label99.ImeMode = System.Windows.Forms.ImeMode.NoControl
        Me.Label99.Location = New System.Drawing.Point(409, 123)
        Me.Label99.Name = "Label99"
        Me.Label99.Size = New System.Drawing.Size(45, 16)
        Me.Label99.TabIndex = 168
        Me.Label99.Text = "HORA"
        '
        'Label100
        '
        Me.Label100.AutoSize = True
        Me.Label100.Font = New System.Drawing.Font("Arial", 9.75!, System.Drawing.FontStyle.Bold)
        Me.Label100.ImeMode = System.Windows.Forms.ImeMode.NoControl
        Me.Label100.Location = New System.Drawing.Point(592, 123)
        Me.Label100.Name = "Label100"
        Me.Label100.Size = New System.Drawing.Size(51, 16)
        Me.Label100.TabIndex = 167
        Me.Label100.Text = "FECHA"
        '
        'Label101
        '
        Me.Label101.AutoSize = True
        Me.Label101.Font = New System.Drawing.Font("Arial", 9.75!, System.Drawing.FontStyle.Bold)
        Me.Label101.ImeMode = System.Windows.Forms.ImeMode.NoControl
        Me.Label101.Location = New System.Drawing.Point(692, 68)
        Me.Label101.Name = "Label101"
        Me.Label101.Size = New System.Drawing.Size(44, 16)
        Me.Label101.TabIndex = 166
        Me.Label101.Text = "LADO"
        '
        'Label102
        '
        Me.Label102.AutoSize = True
        Me.Label102.Font = New System.Drawing.Font("Arial", 9.75!, System.Drawing.FontStyle.Bold)
        Me.Label102.ImeMode = System.Windows.Forms.ImeMode.NoControl
        Me.Label102.Location = New System.Drawing.Point(546, 68)
        Me.Label102.Name = "Label102"
        Me.Label102.Size = New System.Drawing.Size(61, 16)
        Me.Label102.TabIndex = 165
        Me.Label102.Text = "PRENSA"
        '
        'txtToolE2
        '
        Me.txtToolE2.Font = New System.Drawing.Font("Microsoft Sans Serif", 15.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.txtToolE2.ForeColor = System.Drawing.Color.Black
        Me.txtToolE2.Location = New System.Drawing.Point(411, 205)
        Me.txtToolE2.Name = "txtToolE2"
        Me.txtToolE2.Size = New System.Drawing.Size(126, 31)
        Me.txtToolE2.TabIndex = 164
        '
        'PE13TS
        '
        Me.PE13TS.AutoSize = True
        Me.PE13TS.Font = New System.Drawing.Font("Arial", 6.75!)
        Me.PE13TS.ImeMode = System.Windows.Forms.ImeMode.NoControl
        Me.PE13TS.Location = New System.Drawing.Point(311, 483)
        Me.PE13TS.Name = "PE13TS"
        Me.PE13TS.Size = New System.Drawing.Size(15, 12)
        Me.PE13TS.TabIndex = 149
        Me.PE13TS.Text = "TT"
        Me.PE13TS.Visible = False
        '
        'PE11TS
        '
        Me.PE11TS.AutoSize = True
        Me.PE11TS.Font = New System.Drawing.Font("Arial", 6.75!)
        Me.PE11TS.ImeMode = System.Windows.Forms.ImeMode.NoControl
        Me.PE11TS.Location = New System.Drawing.Point(311, 393)
        Me.PE11TS.Name = "PE11TS"
        Me.PE11TS.Size = New System.Drawing.Size(15, 12)
        Me.PE11TS.TabIndex = 149
        Me.PE11TS.Text = "TT"
        Me.PE11TS.Visible = False
        '
        'PE10TS
        '
        Me.PE10TS.AutoSize = True
        Me.PE10TS.Font = New System.Drawing.Font("Arial", 6.75!)
        Me.PE10TS.ImeMode = System.Windows.Forms.ImeMode.NoControl
        Me.PE10TS.Location = New System.Drawing.Point(311, 312)
        Me.PE10TS.Name = "PE10TS"
        Me.PE10TS.Size = New System.Drawing.Size(15, 12)
        Me.PE10TS.TabIndex = 149
        Me.PE10TS.Text = "TT"
        Me.PE10TS.Visible = False
        '
        'PV13TS
        '
        Me.PV13TS.AutoSize = True
        Me.PV13TS.Font = New System.Drawing.Font("Arial", 6.75!)
        Me.PV13TS.ImeMode = System.Windows.Forms.ImeMode.NoControl
        Me.PV13TS.Location = New System.Drawing.Point(188, 483)
        Me.PV13TS.Name = "PV13TS"
        Me.PV13TS.Size = New System.Drawing.Size(15, 12)
        Me.PV13TS.TabIndex = 148
        Me.PV13TS.Text = "TT"
        '
        'PV11TS
        '
        Me.PV11TS.AutoSize = True
        Me.PV11TS.Font = New System.Drawing.Font("Arial", 6.75!)
        Me.PV11TS.ImeMode = System.Windows.Forms.ImeMode.NoControl
        Me.PV11TS.Location = New System.Drawing.Point(188, 393)
        Me.PV11TS.Name = "PV11TS"
        Me.PV11TS.Size = New System.Drawing.Size(15, 12)
        Me.PV11TS.TabIndex = 148
        Me.PV11TS.Text = "TT"
        '
        'PV10TS
        '
        Me.PV10TS.AutoSize = True
        Me.PV10TS.Font = New System.Drawing.Font("Arial", 6.75!)
        Me.PV10TS.ImeMode = System.Windows.Forms.ImeMode.NoControl
        Me.PV10TS.Location = New System.Drawing.Point(193, 312)
        Me.PV10TS.Name = "PV10TS"
        Me.PV10TS.Size = New System.Drawing.Size(15, 12)
        Me.PV10TS.TabIndex = 148
        Me.PV10TS.Text = "TT"
        '
        'PA13TS
        '
        Me.PA13TS.AutoSize = True
        Me.PA13TS.Font = New System.Drawing.Font("Arial", 6.75!)
        Me.PA13TS.ImeMode = System.Windows.Forms.ImeMode.NoControl
        Me.PA13TS.Location = New System.Drawing.Point(73, 482)
        Me.PA13TS.Name = "PA13TS"
        Me.PA13TS.Size = New System.Drawing.Size(15, 12)
        Me.PA13TS.TabIndex = 147
        Me.PA13TS.Text = "TT"
        '
        'PA11TS
        '
        Me.PA11TS.AutoSize = True
        Me.PA11TS.Font = New System.Drawing.Font("Arial", 6.75!)
        Me.PA11TS.ImeMode = System.Windows.Forms.ImeMode.NoControl
        Me.PA11TS.Location = New System.Drawing.Point(73, 392)
        Me.PA11TS.Name = "PA11TS"
        Me.PA11TS.Size = New System.Drawing.Size(15, 12)
        Me.PA11TS.TabIndex = 147
        Me.PA11TS.Text = "TT"
        '
        'PA10TS
        '
        Me.PA10TS.AutoSize = True
        Me.PA10TS.Font = New System.Drawing.Font("Arial", 6.75!)
        Me.PA10TS.ImeMode = System.Windows.Forms.ImeMode.NoControl
        Me.PA10TS.Location = New System.Drawing.Point(73, 311)
        Me.PA10TS.Name = "PA10TS"
        Me.PA10TS.Size = New System.Drawing.Size(15, 12)
        Me.PA10TS.TabIndex = 147
        Me.PA10TS.Text = "TT"
        '
        'PE9TS
        '
        Me.PE9TS.AutoSize = True
        Me.PE9TS.Font = New System.Drawing.Font("Arial", 6.75!)
        Me.PE9TS.ImeMode = System.Windows.Forms.ImeMode.NoControl
        Me.PE9TS.Location = New System.Drawing.Point(315, 226)
        Me.PE9TS.Name = "PE9TS"
        Me.PE9TS.Size = New System.Drawing.Size(15, 12)
        Me.PE9TS.TabIndex = 146
        Me.PE9TS.Text = "TT"
        Me.PE9TS.Visible = False
        '
        'PV9TS
        '
        Me.PV9TS.AutoSize = True
        Me.PV9TS.Font = New System.Drawing.Font("Arial", 6.75!)
        Me.PV9TS.ImeMode = System.Windows.Forms.ImeMode.NoControl
        Me.PV9TS.Location = New System.Drawing.Point(193, 226)
        Me.PV9TS.Name = "PV9TS"
        Me.PV9TS.Size = New System.Drawing.Size(15, 12)
        Me.PV9TS.TabIndex = 145
        Me.PV9TS.Text = "TT"
        '
        'PA9TS
        '
        Me.PA9TS.AutoSize = True
        Me.PA9TS.Font = New System.Drawing.Font("Arial", 6.75!)
        Me.PA9TS.ImeMode = System.Windows.Forms.ImeMode.NoControl
        Me.PA9TS.Location = New System.Drawing.Point(72, 230)
        Me.PA9TS.Name = "PA9TS"
        Me.PA9TS.Size = New System.Drawing.Size(15, 12)
        Me.PA9TS.TabIndex = 144
        Me.PA9TS.Text = "TT"
        '
        'PE8TS
        '
        Me.PE8TS.AutoSize = True
        Me.PE8TS.Font = New System.Drawing.Font("Arial", 6.75!)
        Me.PE8TS.ImeMode = System.Windows.Forms.ImeMode.NoControl
        Me.PE8TS.Location = New System.Drawing.Point(315, 145)
        Me.PE8TS.Name = "PE8TS"
        Me.PE8TS.Size = New System.Drawing.Size(15, 12)
        Me.PE8TS.TabIndex = 143
        Me.PE8TS.Text = "TT"
        Me.PE8TS.Visible = False
        '
        'PV8TS
        '
        Me.PV8TS.AutoSize = True
        Me.PV8TS.Font = New System.Drawing.Font("Arial", 6.75!)
        Me.PV8TS.ImeMode = System.Windows.Forms.ImeMode.NoControl
        Me.PV8TS.Location = New System.Drawing.Point(193, 148)
        Me.PV8TS.Name = "PV8TS"
        Me.PV8TS.Size = New System.Drawing.Size(15, 12)
        Me.PV8TS.TabIndex = 142
        Me.PV8TS.Text = "TT"
        '
        'PA8TS
        '
        Me.PA8TS.AutoSize = True
        Me.PA8TS.Font = New System.Drawing.Font("Arial", 6.75!)
        Me.PA8TS.ImeMode = System.Windows.Forms.ImeMode.NoControl
        Me.PA8TS.Location = New System.Drawing.Point(72, 145)
        Me.PA8TS.Name = "PA8TS"
        Me.PA8TS.Size = New System.Drawing.Size(15, 12)
        Me.PA8TS.TabIndex = 141
        Me.PA8TS.Text = "TT"
        '
        'PE7TS
        '
        Me.PE7TS.AutoSize = True
        Me.PE7TS.Font = New System.Drawing.Font("Arial", 6.75!)
        Me.PE7TS.ImeMode = System.Windows.Forms.ImeMode.NoControl
        Me.PE7TS.Location = New System.Drawing.Point(315, 64)
        Me.PE7TS.Name = "PE7TS"
        Me.PE7TS.Size = New System.Drawing.Size(15, 12)
        Me.PE7TS.TabIndex = 140
        Me.PE7TS.Text = "TT"
        Me.PE7TS.Visible = False
        '
        'PV7TS
        '
        Me.PV7TS.AutoSize = True
        Me.PV7TS.Font = New System.Drawing.Font("Arial", 6.75!)
        Me.PV7TS.ImeMode = System.Windows.Forms.ImeMode.NoControl
        Me.PV7TS.Location = New System.Drawing.Point(192, 64)
        Me.PV7TS.Name = "PV7TS"
        Me.PV7TS.Size = New System.Drawing.Size(15, 12)
        Me.PV7TS.TabIndex = 139
        Me.PV7TS.Text = "TT"
        '
        'PA7TS
        '
        Me.PA7TS.AutoSize = True
        Me.PA7TS.Font = New System.Drawing.Font("Arial", 6.75!)
        Me.PA7TS.ImeMode = System.Windows.Forms.ImeMode.NoControl
        Me.PA7TS.Location = New System.Drawing.Point(72, 64)
        Me.PA7TS.Name = "PA7TS"
        Me.PA7TS.Size = New System.Drawing.Size(15, 12)
        Me.PA7TS.TabIndex = 138
        Me.PA7TS.Text = "TT"
        '
        'Label11
        '
        Me.Label11.AutoSize = True
        Me.Label11.Font = New System.Drawing.Font("Arial", 20.25!, System.Drawing.FontStyle.Bold)
        Me.Label11.ImeMode = System.Windows.Forms.ImeMode.NoControl
        Me.Label11.Location = New System.Drawing.Point(8, 463)
        Me.Label11.Name = "Label11"
        Me.Label11.Size = New System.Drawing.Size(62, 32)
        Me.Label11.TabIndex = 134
        Me.Label11.Text = "L13"
        '
        'Label9
        '
        Me.Label9.AutoSize = True
        Me.Label9.Font = New System.Drawing.Font("Arial", 20.25!, System.Drawing.FontStyle.Bold)
        Me.Label9.ImeMode = System.Windows.Forms.ImeMode.NoControl
        Me.Label9.Location = New System.Drawing.Point(8, 386)
        Me.Label9.Name = "Label9"
        Me.Label9.Size = New System.Drawing.Size(61, 32)
        Me.Label9.TabIndex = 134
        Me.Label9.Text = "L11"
        '
        'Label62
        '
        Me.Label62.AutoSize = True
        Me.Label62.Font = New System.Drawing.Font("Arial", 20.25!, System.Drawing.FontStyle.Bold)
        Me.Label62.ImeMode = System.Windows.Forms.ImeMode.NoControl
        Me.Label62.Location = New System.Drawing.Point(8, 305)
        Me.Label62.Name = "Label62"
        Me.Label62.Size = New System.Drawing.Size(62, 32)
        Me.Label62.TabIndex = 134
        Me.Label62.Text = "L10"
        '
        'Label63
        '
        Me.Label63.AutoSize = True
        Me.Label63.Font = New System.Drawing.Font("Arial", 20.25!, System.Drawing.FontStyle.Bold)
        Me.Label63.ImeMode = System.Windows.Forms.ImeMode.NoControl
        Me.Label63.Location = New System.Drawing.Point(8, 220)
        Me.Label63.Name = "Label63"
        Me.Label63.Size = New System.Drawing.Size(47, 32)
        Me.Label63.TabIndex = 133
        Me.Label63.Text = "L9"
        '
        'Label64
        '
        Me.Label64.AutoSize = True
        Me.Label64.Font = New System.Drawing.Font("Arial", 20.25!, System.Drawing.FontStyle.Bold)
        Me.Label64.ImeMode = System.Windows.Forms.ImeMode.NoControl
        Me.Label64.Location = New System.Drawing.Point(8, 129)
        Me.Label64.Name = "Label64"
        Me.Label64.Size = New System.Drawing.Size(47, 32)
        Me.Label64.TabIndex = 132
        Me.Label64.Text = "L8"
        '
        'LPA9S
        '
        Me.LPA9S.BackColor = System.Drawing.Color.Yellow
        Me.LPA9S.Font = New System.Drawing.Font("Arial", 14.25!)
        Me.LPA9S.ImeMode = System.Windows.Forms.ImeMode.NoControl
        Me.LPA9S.Location = New System.Drawing.Point(66, 175)
        Me.LPA9S.Name = "LPA9S"
        Me.LPA9S.Size = New System.Drawing.Size(90, 75)
        Me.LPA9S.TabIndex = 129
        Me.LPA9S.Text = "PA9"
        Me.LPA9S.UseVisualStyleBackColor = False
        '
        'Label65
        '
        Me.Label65.AutoSize = True
        Me.Label65.Font = New System.Drawing.Font("Arial", 20.25!, System.Drawing.FontStyle.Bold)
        Me.Label65.ImeMode = System.Windows.Forms.ImeMode.NoControl
        Me.Label65.Location = New System.Drawing.Point(8, 36)
        Me.Label65.Name = "Label65"
        Me.Label65.Size = New System.Drawing.Size(47, 32)
        Me.Label65.TabIndex = 131
        Me.Label65.Text = "L7"
        '
        'LPE13S
        '
        Me.LPE13S.BackColor = System.Drawing.Color.Red
        Me.LPE13S.Font = New System.Drawing.Font("Arial", 14.25!)
        Me.LPE13S.ImeMode = System.Windows.Forms.ImeMode.NoControl
        Me.LPE13S.Location = New System.Drawing.Point(302, 430)
        Me.LPE13S.Name = "LPE13S"
        Me.LPE13S.Size = New System.Drawing.Size(90, 75)
        Me.LPE13S.TabIndex = 127
        Me.LPE13S.Text = "PE13"
        Me.LPE13S.UseVisualStyleBackColor = False
        Me.LPE13S.Visible = False
        '
        'LPE11S
        '
        Me.LPE11S.BackColor = System.Drawing.Color.Red
        Me.LPE11S.Font = New System.Drawing.Font("Arial", 14.25!)
        Me.LPE11S.ImeMode = System.Windows.Forms.ImeMode.NoControl
        Me.LPE11S.Location = New System.Drawing.Point(302, 340)
        Me.LPE11S.Name = "LPE11S"
        Me.LPE11S.Size = New System.Drawing.Size(90, 75)
        Me.LPE11S.TabIndex = 127
        Me.LPE11S.Text = "PE11"
        Me.LPE11S.UseVisualStyleBackColor = False
        Me.LPE11S.Visible = False
        '
        'LPV13S
        '
        Me.LPV13S.BackColor = System.Drawing.Color.DodgerBlue
        Me.LPV13S.Font = New System.Drawing.Font("Arial", 14.25!)
        Me.LPV13S.ImeMode = System.Windows.Forms.ImeMode.NoControl
        Me.LPV13S.Location = New System.Drawing.Point(182, 429)
        Me.LPV13S.Name = "LPV13S"
        Me.LPV13S.Size = New System.Drawing.Size(90, 75)
        Me.LPV13S.TabIndex = 126
        Me.LPV13S.Text = "PV13"
        Me.LPV13S.UseVisualStyleBackColor = False
        '
        'LPE10S
        '
        Me.LPE10S.BackColor = System.Drawing.Color.Red
        Me.LPE10S.Font = New System.Drawing.Font("Arial", 14.25!)
        Me.LPE10S.ImeMode = System.Windows.Forms.ImeMode.NoControl
        Me.LPE10S.Location = New System.Drawing.Point(302, 259)
        Me.LPE10S.Name = "LPE10S"
        Me.LPE10S.Size = New System.Drawing.Size(90, 75)
        Me.LPE10S.TabIndex = 127
        Me.LPE10S.Text = "PE10"
        Me.LPE10S.UseVisualStyleBackColor = False
        Me.LPE10S.Visible = False
        '
        'LPA13S
        '
        Me.LPA13S.BackColor = System.Drawing.Color.Green
        Me.LPA13S.Font = New System.Drawing.Font("Arial", 14.25!)
        Me.LPA13S.ImeMode = System.Windows.Forms.ImeMode.NoControl
        Me.LPA13S.Location = New System.Drawing.Point(66, 430)
        Me.LPA13S.Name = "LPA13S"
        Me.LPA13S.Size = New System.Drawing.Size(90, 75)
        Me.LPA13S.TabIndex = 125
        Me.LPA13S.Text = "PA13"
        Me.LPA13S.UseVisualStyleBackColor = False
        '
        'LPV11S
        '
        Me.LPV11S.BackColor = System.Drawing.Color.DodgerBlue
        Me.LPV11S.Font = New System.Drawing.Font("Arial", 14.25!)
        Me.LPV11S.ImeMode = System.Windows.Forms.ImeMode.NoControl
        Me.LPV11S.Location = New System.Drawing.Point(182, 339)
        Me.LPV11S.Name = "LPV11S"
        Me.LPV11S.Size = New System.Drawing.Size(90, 75)
        Me.LPV11S.TabIndex = 126
        Me.LPV11S.Text = "PV11"
        Me.LPV11S.UseVisualStyleBackColor = False
        '
        'LPA11S
        '
        Me.LPA11S.BackColor = System.Drawing.Color.Green
        Me.LPA11S.Font = New System.Drawing.Font("Arial", 14.25!)
        Me.LPA11S.ImeMode = System.Windows.Forms.ImeMode.NoControl
        Me.LPA11S.Location = New System.Drawing.Point(66, 340)
        Me.LPA11S.Name = "LPA11S"
        Me.LPA11S.Size = New System.Drawing.Size(90, 75)
        Me.LPA11S.TabIndex = 125
        Me.LPA11S.Text = "PA11"
        Me.LPA11S.UseVisualStyleBackColor = False
        '
        'LPV10S
        '
        Me.LPV10S.BackColor = System.Drawing.Color.DodgerBlue
        Me.LPV10S.Font = New System.Drawing.Font("Arial", 14.25!)
        Me.LPV10S.ImeMode = System.Windows.Forms.ImeMode.NoControl
        Me.LPV10S.Location = New System.Drawing.Point(182, 258)
        Me.LPV10S.Name = "LPV10S"
        Me.LPV10S.Size = New System.Drawing.Size(90, 75)
        Me.LPV10S.TabIndex = 126
        Me.LPV10S.Text = "PV10"
        Me.LPV10S.UseVisualStyleBackColor = False
        '
        'LPA10S
        '
        Me.LPA10S.BackColor = System.Drawing.Color.Green
        Me.LPA10S.Font = New System.Drawing.Font("Arial", 14.25!)
        Me.LPA10S.ImeMode = System.Windows.Forms.ImeMode.NoControl
        Me.LPA10S.Location = New System.Drawing.Point(66, 259)
        Me.LPA10S.Name = "LPA10S"
        Me.LPA10S.Size = New System.Drawing.Size(90, 75)
        Me.LPA10S.TabIndex = 125
        Me.LPA10S.Text = "PA10"
        Me.LPA10S.UseVisualStyleBackColor = False
        '
        'LPE9S
        '
        Me.LPE9S.BackColor = System.Drawing.Color.Red
        Me.LPE9S.Font = New System.Drawing.Font("Arial", 14.25!)
        Me.LPE9S.ImeMode = System.Windows.Forms.ImeMode.NoControl
        Me.LPE9S.Location = New System.Drawing.Point(302, 173)
        Me.LPE9S.Name = "LPE9S"
        Me.LPE9S.Size = New System.Drawing.Size(90, 75)
        Me.LPE9S.TabIndex = 128
        Me.LPE9S.Text = "PE9"
        Me.LPE9S.UseVisualStyleBackColor = False
        Me.LPE9S.Visible = False
        '
        'LPV8S
        '
        Me.LPV8S.BackColor = System.Drawing.Color.DodgerBlue
        Me.LPV8S.Font = New System.Drawing.Font("Arial", 14.25!)
        Me.LPV8S.ImeMode = System.Windows.Forms.ImeMode.NoControl
        Me.LPV8S.Location = New System.Drawing.Point(182, 93)
        Me.LPV8S.Name = "LPV8S"
        Me.LPV8S.Size = New System.Drawing.Size(90, 75)
        Me.LPV8S.TabIndex = 123
        Me.LPV8S.Text = "PV8"
        Me.LPV8S.UseVisualStyleBackColor = False
        '
        'LPA8S
        '
        Me.LPA8S.BackColor = System.Drawing.Color.Green
        Me.LPA8S.Font = New System.Drawing.Font("Arial", 14.25!)
        Me.LPA8S.ImeMode = System.Windows.Forms.ImeMode.NoControl
        Me.LPA8S.Location = New System.Drawing.Point(66, 92)
        Me.LPA8S.Name = "LPA8S"
        Me.LPA8S.Size = New System.Drawing.Size(90, 75)
        Me.LPA8S.TabIndex = 122
        Me.LPA8S.Text = "PA8"
        Me.LPA8S.UseVisualStyleBackColor = False
        '
        'LPE7S
        '
        Me.LPE7S.BackColor = System.Drawing.Color.Red
        Me.LPE7S.Font = New System.Drawing.Font("Arial", 14.25!)
        Me.LPE7S.ImeMode = System.Windows.Forms.ImeMode.NoControl
        Me.LPE7S.Location = New System.Drawing.Point(302, 9)
        Me.LPE7S.Name = "LPE7S"
        Me.LPE7S.Size = New System.Drawing.Size(90, 75)
        Me.LPE7S.TabIndex = 124
        Me.LPE7S.Text = "PE7"
        Me.LPE7S.UseVisualStyleBackColor = False
        Me.LPE7S.Visible = False
        '
        'LPV7S
        '
        Me.LPV7S.BackColor = System.Drawing.Color.DodgerBlue
        Me.LPV7S.Font = New System.Drawing.Font("Arial", 14.25!)
        Me.LPV7S.ImeMode = System.Windows.Forms.ImeMode.NoControl
        Me.LPV7S.Location = New System.Drawing.Point(182, 9)
        Me.LPV7S.Name = "LPV7S"
        Me.LPV7S.Size = New System.Drawing.Size(90, 75)
        Me.LPV7S.TabIndex = 120
        Me.LPV7S.Text = "PV7"
        Me.LPV7S.UseVisualStyleBackColor = False
        '
        'LPA7S
        '
        Me.LPA7S.BackColor = System.Drawing.Color.Green
        Me.LPA7S.Font = New System.Drawing.Font("Arial", 14.25!)
        Me.LPA7S.ImeMode = System.Windows.Forms.ImeMode.NoControl
        Me.LPA7S.Location = New System.Drawing.Point(66, 9)
        Me.LPA7S.Name = "LPA7S"
        Me.LPA7S.Size = New System.Drawing.Size(90, 75)
        Me.LPA7S.TabIndex = 115
        Me.LPA7S.Text = "PA7"
        Me.LPA7S.UseVisualStyleBackColor = False
        '
        'LPV9S
        '
        Me.LPV9S.BackColor = System.Drawing.Color.Red
        Me.LPV9S.Font = New System.Drawing.Font("Arial", 14.25!)
        Me.LPV9S.ImeMode = System.Windows.Forms.ImeMode.NoControl
        Me.LPV9S.Location = New System.Drawing.Point(182, 174)
        Me.LPV9S.Name = "LPV9S"
        Me.LPV9S.Size = New System.Drawing.Size(90, 75)
        Me.LPV9S.TabIndex = 118
        Me.LPV9S.Text = "PV9"
        Me.LPV9S.UseVisualStyleBackColor = False
        '
        'LPE8S
        '
        Me.LPE8S.BackColor = System.Drawing.Color.Red
        Me.LPE8S.Font = New System.Drawing.Font("Arial", 14.25!)
        Me.LPE8S.ImeMode = System.Windows.Forms.ImeMode.NoControl
        Me.LPE8S.Location = New System.Drawing.Point(302, 92)
        Me.LPE8S.Name = "LPE8S"
        Me.LPE8S.Size = New System.Drawing.Size(90, 75)
        Me.LPE8S.TabIndex = 119
        Me.LPE8S.Text = "PE8"
        Me.LPE8S.UseVisualStyleBackColor = False
        Me.LPE8S.Visible = False
        '
        'tpEstacion3
        '
        Me.tpEstacion3.Controls.Add(Me.GrdGrommet)
        Me.tpEstacion3.Location = New System.Drawing.Point(4, 23)
        Me.tpEstacion3.Name = "tpEstacion3"
        Me.tpEstacion3.Padding = New System.Windows.Forms.Padding(3)
        Me.tpEstacion3.Size = New System.Drawing.Size(1237, 683)
        Me.tpEstacion3.TabIndex = 7
        Me.tpEstacion3.Text = "Estacion3"
        Me.tpEstacion3.UseVisualStyleBackColor = True
        '
        'GrdGrommet
        '
        Me.GrdGrommet.AllowUserToAddRows = False
        Me.GrdGrommet.AllowUserToDeleteRows = False
        Me.GrdGrommet.AllowUserToResizeColumns = False
        Me.GrdGrommet.AllowUserToResizeRows = False
        Me.GrdGrommet.BorderStyle = System.Windows.Forms.BorderStyle.None
        Me.GrdGrommet.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize
        Me.GrdGrommet.Location = New System.Drawing.Point(3, 6)
        Me.GrdGrommet.MultiSelect = False
        Me.GrdGrommet.Name = "GrdGrommet"
        Me.GrdGrommet.ReadOnly = True
        Me.GrdGrommet.RowHeadersVisible = False
        Me.GrdGrommet.RowHeadersWidth = 10
        DataGridViewCellStyle6.Font = New System.Drawing.Font("Microsoft Sans Serif", 14.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.GrdGrommet.RowsDefaultCellStyle = DataGridViewCellStyle6
        Me.GrdGrommet.RowTemplate.Height = 40
        Me.GrdGrommet.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.FullRowSelect
        Me.GrdGrommet.Size = New System.Drawing.Size(1412, 683)
        Me.GrdGrommet.TabIndex = 24
        '
        'Button1
        '
        Me.Button1.Location = New System.Drawing.Point(1132, 1)
        Me.Button1.Name = "Button1"
        Me.Button1.Size = New System.Drawing.Size(35, 23)
        Me.Button1.TabIndex = 19
        Me.Button1.Text = "X"
        Me.Button1.UseVisualStyleBackColor = True
        '
        'lblEstacion
        '
        Me.lblEstacion.BackColor = System.Drawing.Color.White
        Me.lblEstacion.Font = New System.Drawing.Font("Times New Roman", 21.75!, System.Drawing.FontStyle.Bold)
        Me.lblEstacion.ForeColor = System.Drawing.Color.Black
        Me.lblEstacion.ImeMode = System.Windows.Forms.ImeMode.NoControl
        Me.lblEstacion.Location = New System.Drawing.Point(456, 90)
        Me.lblEstacion.Name = "lblEstacion"
        Me.lblEstacion.Size = New System.Drawing.Size(428, 36)
        Me.lblEstacion.TabIndex = 11
        Me.lblEstacion.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'tmrChange
        '
        Me.tmrChange.Enabled = True
        Me.tmrChange.Interval = 300000
        '
        'PictureBox1
        '
        Me.PictureBox1.Image = CType(resources.GetObject("PictureBox1.Image"), System.Drawing.Image)
        Me.PictureBox1.Location = New System.Drawing.Point(0, 23)
        Me.PictureBox1.Name = "PictureBox1"
        Me.PictureBox1.Size = New System.Drawing.Size(258, 103)
        Me.PictureBox1.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage
        Me.PictureBox1.TabIndex = 20
        Me.PictureBox1.TabStop = False
        '
        'Form1
        '
        Me.AllowDrop = True
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 14.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.BackColor = System.Drawing.Color.White
        Me.ClientSize = New System.Drawing.Size(1237, 838)
        Me.Controls.Add(Me.PictureBox1)
        Me.Controls.Add(Me.HORA)
        Me.Controls.Add(Me.FECHA)
        Me.Controls.Add(Me.Button1)
        Me.Controls.Add(Me.TabHistorial)
        Me.Controls.Add(Me.Panel2)
        Me.Controls.Add(Me.Panel1)
        Me.Controls.Add(Me.lblEstacion)
        Me.Controls.Add(Me.Label19)
        Me.Controls.Add(Me.MenuStrip1)
        Me.Cursor = System.Windows.Forms.Cursors.Default
        Me.Font = New System.Drawing.Font("Arial", 8.0!)
        Me.FormBorderStyle = System.Windows.Forms.FormBorderStyle.None
        Me.MainMenuStrip = Me.MenuStrip1
        Me.MinimumSize = New System.Drawing.Size(20, 43)
        Me.Name = "Form1"
        Me.RightToLeft = System.Windows.Forms.RightToLeft.No
        Me.RightToLeftLayout = True
        Me.Text = "Control de Tooling Ver. 19.Septiembre.2019 by JR"
        Me.Panel1.ResumeLayout(False)
        Me.MenuStrip1.ResumeLayout(False)
        Me.MenuStrip1.PerformLayout()
        Me.tpEstacion1.ResumeLayout(False)
        Me.tpEstacion1.PerformLayout()
        CType(Me.GridChangeTool, System.ComponentModel.ISupportInitialize).EndInit()
        Me.InformacionHH.ResumeLayout(False)
        Me.Tooling.ResumeLayout(False)
        Me.Tooling.PerformLayout()
        CType(Me.GridTooling, System.ComponentModel.ISupportInitialize).EndInit()
        Me.Lineas.ResumeLayout(False)
        Me.Panel3.ResumeLayout(False)
        Me.Panel3.PerformLayout()
        Me.TabHistorial.ResumeLayout(False)
        Me.tpEstacion2.ResumeLayout(False)
        Me.tpEstacion2.PerformLayout()
        CType(Me.GridChangeTool2, System.ComponentModel.ISupportInitialize).EndInit()
        Me.tpEstacion3.ResumeLayout(False)
        CType(Me.GrdGrommet, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.PictureBox1, System.ComponentModel.ISupportInitialize).EndInit()
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub
    Friend WithEvents Timer1 As System.Windows.Forms.Timer
    Friend WithEvents Timer2 As System.Windows.Forms.Timer
    Friend WithEvents Label19 As System.Windows.Forms.Label
    Friend WithEvents Label20 As System.Windows.Forms.Label
    Friend WithEvents OEE_CURRENT As System.Windows.Forms.Label
    Friend WithEvents Panel1 As System.Windows.Forms.Panel
    Friend WithEvents AVAILABILITY As System.Windows.Forms.Label
    Friend WithEvents Label21 As System.Windows.Forms.Label
    Friend WithEvents QUALITY As System.Windows.Forms.Label
    Friend WithEvents Label23 As System.Windows.Forms.Label
    Friend WithEvents PERFORMANCE As System.Windows.Forms.Label
    Friend WithEvents Label22 As System.Windows.Forms.Label
    Friend WithEvents FECHA As System.Windows.Forms.Label
    Friend WithEvents HORA As System.Windows.Forms.Label
    Friend WithEvents Panel2 As System.Windows.Forms.Panel
    Friend WithEvents Timer3 As System.Windows.Forms.Timer
    Friend WithEvents TimerMain As System.Windows.Forms.Timer
    Friend WithEvents Timer4 As System.Windows.Forms.Timer
    Friend WithEvents MenuStrip1 As System.Windows.Forms.MenuStrip
    Friend WithEvents MantenimientoToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents AcercaDeToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents AjustesToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents TmrDbToFile As System.Windows.Forms.Timer
    Friend WithEvents tpEstacion1 As TabPage
    Friend WithEvents PE5TS As Label
    Friend WithEvents PV5TS As Label
    Friend WithEvents PA5TS As Label
    Friend WithEvents PE4TS As Label
    Friend WithEvents PV4TS As Label
    Friend WithEvents PA4TS As Label
    Friend WithEvents PE3TS As Label
    Friend WithEvents PV3TS As Label
    Friend WithEvents PA3TS As Label
    Friend WithEvents PE2TS As Label
    Friend WithEvents PV2TS As Label
    Friend WithEvents PA2TS As Label
    Friend WithEvents PE1TS As Label
    Friend WithEvents PV1TS As Label
    Friend WithEvents PA1TS As Label
    Friend WithEvents Label45 As Label
    Friend WithEvents Label46 As Label
    Friend WithEvents LPA1S As Button
    Friend WithEvents Label47 As Label
    Friend WithEvents Label48 As Label
    Friend WithEvents LPE4S As Button
    Friend WithEvents LPE1S As Button
    Friend WithEvents LPV5S As Button
    Friend WithEvents LPE5S As Button
    Friend WithEvents Label49 As Label
    Friend WithEvents LPV1S As Button
    Friend WithEvents LPA5S As Button
    Friend WithEvents LPA4S As Button
    Friend WithEvents LPE2S As Button
    Friend WithEvents LPV2S As Button
    Friend WithEvents LPA2S As Button
    Friend WithEvents LPV3S As Button
    Friend WithEvents LPA3S As Button
    Friend WithEvents LPE3S As Button
    Friend WithEvents LPV4S As Button
    Friend WithEvents InformacionHH As TabPage
    Friend WithEvents BtnEnvioHH As Button
    Friend WithEvents Tooling As TabPage
    Friend WithEvents TxtUpdTooling As TextBox
    Friend WithEvents BtnSave As Button
    Friend WithEvents GridTooling As DataGridView
    Friend WithEvents Lineas As TabPage
    Friend WithEvents Panel3 As Panel
    Friend WithEvents PE10T As Label
    Friend WithEvents PV10T As Label
    Friend WithEvents PE9T As Label
    Friend WithEvents PV9T As Label
    Friend WithEvents PA9T As Label
    Friend WithEvents PE8T As Label
    Friend WithEvents PV8T As Label
    Friend WithEvents PA8T As Label
    Friend WithEvents PE7T As Label
    Friend WithEvents PV7T As Label
    Friend WithEvents PA7T As Label
    Friend WithEvents PE6T As Label
    Friend WithEvents PV6T As Label
    Friend WithEvents PA6T As Label
    Friend WithEvents PE5T As Label
    Friend WithEvents PV5T As Label
    Friend WithEvents PA5T As Label
    Friend WithEvents PE4T As Label
    Friend WithEvents PV4T As Label
    Friend WithEvents PA4T As Label
    Friend WithEvents PE3T As Label
    Friend WithEvents PV3T As Label
    Friend WithEvents PA3T As Label
    Friend WithEvents PE2T As Label
    Friend WithEvents PV2T As Label
    Friend WithEvents PA2T As Label
    Friend WithEvents PE1T As Label
    Friend WithEvents PV1T As Label
    Friend WithEvents PA1T As Label
    Friend WithEvents Label5 As Label
    Friend WithEvents Label4 As Label
    Friend WithEvents EdtVida As TextBox
    Friend WithEvents Label3 As Label
    Friend WithEvents EdtTiempoTotal As TextBox
    Friend WithEvents Label2 As Label
    Friend WithEvents EdNumEmpleado As TextBox
    Friend WithEvents Label1 As Label
    Friend WithEvents Label44 As Label
    Friend WithEvents Label15 As Label
    Friend WithEvents Label16 As Label
    Friend WithEvents Label40 As Label
    Friend WithEvents EdtTurno As TextBox
    Friend WithEvents EdtLado As TextBox
    Friend WithEvents EdtPrensa As TextBox
    Friend WithEvents EdtLine As TextBox
    Friend WithEvents EdtHora As TextBox
    Friend WithEvents EdtFecha As TextBox
    Friend WithEvents EdtTecnico As TextBox
    Friend WithEvents EdtLaina As TextBox
    Friend WithEvents EdtGreenPlate As TextBox
    Friend WithEvents EdtPPackAnt As TextBox
    Friend WithEvents Label41 As Label
    Friend WithEvents Label43 As Label
    Friend WithEvents Label37 As Label
    Friend WithEvents Label38 As Label
    Friend WithEvents Label39 As Label
    Friend WithEvents Label34 As Label
    Friend WithEvents Label35 As Label
    Friend WithEvents Label33 As Label
    Friend WithEvents Label32 As Label
    Friend WithEvents EdtTooling As TextBox
    Friend WithEvents Label31 As Label
    Friend WithEvents Label30 As Label
    Friend WithEvents Label29 As Label
    Friend WithEvents LPA9 As Button
    Friend WithEvents Label25 As Label
    Friend WithEvents LPE10 As Button
    Friend WithEvents Label24 As Label
    Friend WithEvents LPV10 As Button
    Friend WithEvents LPA1 As Button
    Friend WithEvents LPA10 As Button
    Friend WithEvents Label27 As Label
    Friend WithEvents Label26 As Label
    Friend WithEvents LPE4 As Button
    Friend WithEvents LPE9 As Button
    Friend WithEvents LPE1 As Button
    Friend WithEvents LPV8 As Button
    Friend WithEvents LPV5 As Button
    Friend WithEvents LPA8 As Button
    Friend WithEvents LPE5 As Button
    Friend WithEvents LPE7 As Button
    Friend WithEvents LPE6 As Button
    Friend WithEvents Label17 As Label
    Friend WithEvents LPV7 As Button
    Friend WithEvents LPV6 As Button
    Friend WithEvents LPV1 As Button
    Friend WithEvents LPA5 As Button
    Friend WithEvents LPA4 As Button
    Friend WithEvents LPE2 As Button
    Friend WithEvents LPV2 As Button
    Friend WithEvents LPA2 As Button
    Friend WithEvents LPA7 As Button
    Friend WithEvents LPV3 As Button
    Friend WithEvents LPA3 As Button
    Friend WithEvents LPE3 As Button
    Friend WithEvents LPA6 As Button
    Friend WithEvents LPV4 As Button
    Friend WithEvents LPV9 As Button
    Friend WithEvents LPE8 As Button
    Friend WithEvents TabHistorial As TabControl
    Friend WithEvents tpEstacion2 As TabPage
    Friend WithEvents PE10TS As Label
    Friend WithEvents PV10TS As Label
    Friend WithEvents PA10TS As Label
    Friend WithEvents PE9TS As Label
    Friend WithEvents PV9TS As Label
    Friend WithEvents PA9TS As Label
    Friend WithEvents PE8TS As Label
    Friend WithEvents PV8TS As Label
    Friend WithEvents PA8TS As Label
    Friend WithEvents PE7TS As Label
    Friend WithEvents PV7TS As Label
    Friend WithEvents PA7TS As Label
    Friend WithEvents Label62 As Label
    Friend WithEvents Label63 As Label
    Friend WithEvents Label64 As Label
    Friend WithEvents LPA9S As Button
    Friend WithEvents Label65 As Label
    Friend WithEvents LPE10S As Button
    Friend WithEvents LPV10S As Button
    Friend WithEvents LPA10S As Button
    Friend WithEvents LPE9S As Button
    Friend WithEvents LPV8S As Button
    Friend WithEvents LPA8S As Button
    Friend WithEvents LPE7S As Button
    Friend WithEvents LPV7S As Button
    Friend WithEvents LPA7S As Button
    Friend WithEvents LPV9S As Button
    Friend WithEvents LPE8S As Button
    Friend WithEvents Label73 As Label
    Friend WithEvents txtVidaE1 As TextBox
    Friend WithEvents txtUsoE1 As TextBox
    Friend WithEvents Label75 As Label
    Friend WithEvents txtEmplE1 As TextBox
    Friend WithEvents Label76 As Label
    Friend WithEvents Label77 As Label
    Friend WithEvents Label78 As Label
    Friend WithEvents txtTurnoE1 As TextBox
    Friend WithEvents txtLadoE1 As TextBox
    Friend WithEvents txtPrenE1 As TextBox
    Friend WithEvents txtLineaE1 As TextBox
    Friend WithEvents txtHoraE1 As TextBox
    Friend WithEvents txtFechE1 As TextBox
    Friend WithEvents txtTecE1 As TextBox
    Friend WithEvents txtLainaE1 As TextBox
    Friend WithEvents txtGreenE1 As TextBox
    Friend WithEvents txtAntE1 As TextBox
    Friend WithEvents Label79 As Label
    Friend WithEvents Label80 As Label
    Friend WithEvents Label81 As Label
    Friend WithEvents Label82 As Label
    Friend WithEvents Label83 As Label
    Friend WithEvents Label84 As Label
    Friend WithEvents Label85 As Label
    Friend WithEvents Label86 As Label
    Friend WithEvents Label87 As Label
    Friend WithEvents txtToolE1 As TextBox
    Friend WithEvents Label88 As Label
    Friend WithEvents txtVidaE2 As TextBox
    Friend WithEvents txtUsoE2 As TextBox
    Friend WithEvents Label90 As Label
    Friend WithEvents txtEmpE2 As TextBox
    Friend WithEvents Label91 As Label
    Friend WithEvents Label92 As Label
    Friend WithEvents Label93 As Label
    Friend WithEvents txtTurnoE2 As TextBox
    Friend WithEvents txtLadoE2 As TextBox
    Friend WithEvents txtPrensaE2 As TextBox
    Friend WithEvents txtLineaE2 As TextBox
    Friend WithEvents txtHoraE2 As TextBox
    Friend WithEvents txtFechE2 As TextBox
    Friend WithEvents txtTecE2 As TextBox
    Friend WithEvents txtLainaE2 As TextBox
    Friend WithEvents txtGreenE2 As TextBox
    Friend WithEvents txtAntE2 As TextBox
    Friend WithEvents Label94 As Label
    Friend WithEvents Label95 As Label
    Friend WithEvents Label96 As Label
    Friend WithEvents Label97 As Label
    Friend WithEvents Label98 As Label
    Friend WithEvents Label99 As Label
    Friend WithEvents Label100 As Label
    Friend WithEvents Label101 As Label
    Friend WithEvents Label102 As Label
    Friend WithEvents txtToolE2 As TextBox
    Friend WithEvents btnRevisarE1 As Button
    Friend WithEvents BtnRepTool As Button
    Friend WithEvents btnRevisarE2 As Button
    Friend WithEvents btnRepararE2 As Button
    Friend WithEvents Button1 As Button
    Friend WithEvents lblEstacion As Label
    Friend WithEvents tmrChange As Timer
    Friend WithEvents tpEstacion3 As TabPage
    Private WithEvents GrdGrommet As DataGridView
    Private WithEvents GridChangeTool As DataGridView
    Friend WithEvents Label6 As Label
    Friend WithEvents Label7 As Label
    Private WithEvents GridChangeTool2 As DataGridView
    Friend WithEvents PE11T As Label
    Friend WithEvents PV11T As Label
    Friend WithEvents PA11T As Label
    Friend WithEvents PA10T As Label
    Friend WithEvents Label8 As Label
    Friend WithEvents LPE11 As Button
    Friend WithEvents LPV11 As Button
    Friend WithEvents LPA11 As Button
    Friend WithEvents PE11TS As Label
    Friend WithEvents PV11TS As Label
    Friend WithEvents PA11TS As Label
    Friend WithEvents Label9 As Label
    Friend WithEvents LPE11S As Button
    Friend WithEvents LPV11S As Button
    Friend WithEvents LPA11S As Button
    Friend WithEvents PE13T As Label
    Friend WithEvents PV13T As Label
    Friend WithEvents PA13T As Label
    Friend WithEvents Label10 As Label
    Friend WithEvents LPE13 As Button
    Friend WithEvents LPV13 As Button
    Friend WithEvents LPA13 As Button
    Friend WithEvents PE6TS As Label
    Friend WithEvents PV6TS As Label
    Friend WithEvents PA6TS As Label
    Friend WithEvents Label66 As Label
    Friend WithEvents LPE6S As Button
    Friend WithEvents LPV6S As Button
    Friend WithEvents LPA6S As Button
    Friend WithEvents PE13TS As Label
    Friend WithEvents PV13TS As Label
    Friend WithEvents PA13TS As Label
    Friend WithEvents Label11 As Label
    Friend WithEvents LPE13S As Button
    Friend WithEvents LPV13S As Button
    Friend WithEvents LPA13S As Button
    Friend WithEvents PictureBox1 As PictureBox
    'Friend WithEvents ShapeContainer1 As Microsoft.VisualBasic.PowerPacks.ShapeContainer
    'Friend WithEvents RectangleShape2 As Microsoft.VisualBasic.PowerPacks.RectangleShape
    'Friend WithEvents RectangleShape1 As Microsoft.VisualBasic.PowerPacks.RectangleShape
    'Friend WithEvents RECTANGULO As Microsoft.VisualBasic.PowerPacks.RectangleShape
#End Region
End Class