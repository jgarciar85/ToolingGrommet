﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class Form2
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.Label19 = New System.Windows.Forms.Label()
        Me.groupBox26 = New System.Windows.Forms.GroupBox()
        Me.flowLayoutPanel23 = New System.Windows.Forms.FlowLayoutPanel()
        Me.rbSinGolpesSI = New System.Windows.Forms.RadioButton()
        Me.rbSinGolpesNO = New System.Windows.Forms.RadioButton()
        Me.txtEmpSinGolpes = New System.Windows.Forms.TextBox()
        Me.txtFechaSinGolpes = New System.Windows.Forms.TextBox()
        Me.txtNpart = New System.Windows.Forms.TextBox()
        Me.Label23 = New System.Windows.Forms.Label()
        Me.Label1 = New System.Windows.Forms.Label()
        Me.Label24 = New System.Windows.Forms.Label()
        Me.Label18 = New System.Windows.Forms.Label()
        Me.txtCantPlat = New System.Windows.Forms.TextBox()
        Me.Label5 = New System.Windows.Forms.Label()
        Me.txtCantGrommet = New System.Windows.Forms.TextBox()
        Me.GroupBox1 = New System.Windows.Forms.GroupBox()
        Me.FlowLayoutPanel1 = New System.Windows.Forms.FlowLayoutPanel()
        Me.rbRevGaugeBuenos = New System.Windows.Forms.RadioButton()
        Me.rbRevGaugeMalos = New System.Windows.Forms.RadioButton()
        Me.txtFechaRevGauge = New System.Windows.Forms.TextBox()
        Me.txtEmpRevGauge = New System.Windows.Forms.TextBox()
        Me.Label2 = New System.Windows.Forms.Label()
        Me.GroupBox2 = New System.Windows.Forms.GroupBox()
        Me.FlowLayoutPanel2 = New System.Windows.Forms.FlowLayoutPanel()
        Me.rbNuevo = New System.Windows.Forms.RadioButton()
        Me.rbReac = New System.Windows.Forms.RadioButton()
        Me.rbNA = New System.Windows.Forms.RadioButton()
        Me.Label3 = New System.Windows.Forms.Label()
        Me.GroupBox3 = New System.Windows.Forms.GroupBox()
        Me.FlowLayoutPanel3 = New System.Windows.Forms.FlowLayoutPanel()
        Me.rbtxtArmaSetSI = New System.Windows.Forms.RadioButton()
        Me.rbtxtArmaSetNO = New System.Windows.Forms.RadioButton()
        Me.txtEmpArmaSet = New System.Windows.Forms.TextBox()
        Me.txtFechaArmaSet = New System.Windows.Forms.TextBox()
        Me.GroupBox4 = New System.Windows.Forms.GroupBox()
        Me.FlowLayoutPanel4 = New System.Windows.Forms.FlowLayoutPanel()
        Me.rbTalquearSI = New System.Windows.Forms.RadioButton()
        Me.rbTalquearNO = New System.Windows.Forms.RadioButton()
        Me.txtEmpTalquear = New System.Windows.Forms.TextBox()
        Me.txtFechaTalquear = New System.Windows.Forms.TextBox()
        Me.GroupBox5 = New System.Windows.Forms.GroupBox()
        Me.FlowLayoutPanel5 = New System.Windows.Forms.FlowLayoutPanel()
        Me.rbPrensarSI = New System.Windows.Forms.RadioButton()
        Me.rbPrensarNO = New System.Windows.Forms.RadioButton()
        Me.txtEmpPrensar = New System.Windows.Forms.TextBox()
        Me.txtFechaPrensar = New System.Windows.Forms.TextBox()
        Me.GroupBox6 = New System.Windows.Forms.GroupBox()
        Me.FlowLayoutPanel6 = New System.Windows.Forms.FlowLayoutPanel()
        Me.rbSopletearSI = New System.Windows.Forms.RadioButton()
        Me.rbSopletearNO = New System.Windows.Forms.RadioButton()
        Me.txtEmpSopletear = New System.Windows.Forms.TextBox()
        Me.txtFechaSopletear = New System.Windows.Forms.TextBox()
        Me.GroupBox7 = New System.Windows.Forms.GroupBox()
        Me.FlowLayoutPanel7 = New System.Windows.Forms.FlowLayoutPanel()
        Me.rbPintarSI = New System.Windows.Forms.RadioButton()
        Me.rbPintarNO = New System.Windows.Forms.RadioButton()
        Me.txtEmpPintar = New System.Windows.Forms.TextBox()
        Me.txtFechaPintar = New System.Windows.Forms.TextBox()
        Me.GroupBox8 = New System.Windows.Forms.GroupBox()
        Me.FlowLayoutPanel8 = New System.Windows.Forms.FlowLayoutPanel()
        Me.tbCurarSI = New System.Windows.Forms.RadioButton()
        Me.rbCurarNO = New System.Windows.Forms.RadioButton()
        Me.txtEmpCurar = New System.Windows.Forms.TextBox()
        Me.txtFechaCurar = New System.Windows.Forms.TextBox()
        Me.GroupBox9 = New System.Windows.Forms.GroupBox()
        Me.FlowLayoutPanel9 = New System.Windows.Forms.FlowLayoutPanel()
        Me.rbRetAntSI = New System.Windows.Forms.RadioButton()
        Me.rbRetAntNO = New System.Windows.Forms.RadioButton()
        Me.txtEmpRetAnt = New System.Windows.Forms.TextBox()
        Me.txtFechaRetAnt = New System.Windows.Forms.TextBox()
        Me.Label4 = New System.Windows.Forms.Label()
        Me.txtVale = New System.Windows.Forms.TextBox()
        Me.GroupBox10 = New System.Windows.Forms.GroupBox()
        Me.FlowLayoutPanel10 = New System.Windows.Forms.FlowLayoutPanel()
        Me.rbDesarmadoSI = New System.Windows.Forms.RadioButton()
        Me.rbDesarmadoNO = New System.Windows.Forms.RadioButton()
        Me.txtEmpDesarmado = New System.Windows.Forms.TextBox()
        Me.txtFechaDesarmado = New System.Windows.Forms.TextBox()
        Me.GroupBox11 = New System.Windows.Forms.GroupBox()
        Me.FlowLayoutPanel11 = New System.Windows.Forms.FlowLayoutPanel()
        Me.rbDBSI = New System.Windows.Forms.RadioButton()
        Me.rbDBNO = New System.Windows.Forms.RadioButton()
        Me.txtEmpAltaDB = New System.Windows.Forms.TextBox()
        Me.txtFechaAltaDB = New System.Windows.Forms.TextBox()
        Me.GroupBox12 = New System.Windows.Forms.GroupBox()
        Me.FlowLayoutPanel12 = New System.Windows.Forms.FlowLayoutPanel()
        Me.rbRevTecSI = New System.Windows.Forms.RadioButton()
        Me.rbRevTecNO = New System.Windows.Forms.RadioButton()
        Me.txtEmpRevTec = New System.Windows.Forms.TextBox()
        Me.txtFechaRevTec = New System.Windows.Forms.TextBox()
        Me.GroupBox13 = New System.Windows.Forms.GroupBox()
        Me.FlowLayoutPanel13 = New System.Windows.Forms.FlowLayoutPanel()
        Me.rbEntregarSI = New System.Windows.Forms.RadioButton()
        Me.rbEntregarNO = New System.Windows.Forms.RadioButton()
        Me.txtEmpEntregar = New System.Windows.Forms.TextBox()
        Me.txtFechaEntregar = New System.Windows.Forms.TextBox()
        Me.GroupBox14 = New System.Windows.Forms.GroupBox()
        Me.FlowLayoutPanel14 = New System.Windows.Forms.FlowLayoutPanel()
        Me.rbEnvioSI = New System.Windows.Forms.RadioButton()
        Me.rbEnvioNO = New System.Windows.Forms.RadioButton()
        Me.txtEmpEnvio = New System.Windows.Forms.TextBox()
        Me.txtFechaEnvio = New System.Windows.Forms.TextBox()
        Me.Label6 = New System.Windows.Forms.Label()
        Me.lblID = New System.Windows.Forms.Label()
        Me.txtColor = New System.Windows.Forms.TextBox()
        Me.txtIdArmar = New System.Windows.Forms.TextBox()
        Me.txtTooling = New System.Windows.Forms.TextBox()
        Me.txtIdAnterior = New System.Windows.Forms.TextBox()
        Me.txtDiametro = New System.Windows.Forms.TextBox()
        Me.groupBox26.SuspendLayout()
        Me.flowLayoutPanel23.SuspendLayout()
        Me.GroupBox1.SuspendLayout()
        Me.FlowLayoutPanel1.SuspendLayout()
        Me.GroupBox2.SuspendLayout()
        Me.FlowLayoutPanel2.SuspendLayout()
        Me.GroupBox3.SuspendLayout()
        Me.FlowLayoutPanel3.SuspendLayout()
        Me.GroupBox4.SuspendLayout()
        Me.FlowLayoutPanel4.SuspendLayout()
        Me.GroupBox5.SuspendLayout()
        Me.FlowLayoutPanel5.SuspendLayout()
        Me.GroupBox6.SuspendLayout()
        Me.FlowLayoutPanel6.SuspendLayout()
        Me.GroupBox7.SuspendLayout()
        Me.FlowLayoutPanel7.SuspendLayout()
        Me.GroupBox8.SuspendLayout()
        Me.FlowLayoutPanel8.SuspendLayout()
        Me.GroupBox9.SuspendLayout()
        Me.FlowLayoutPanel9.SuspendLayout()
        Me.GroupBox10.SuspendLayout()
        Me.FlowLayoutPanel10.SuspendLayout()
        Me.GroupBox11.SuspendLayout()
        Me.FlowLayoutPanel11.SuspendLayout()
        Me.GroupBox12.SuspendLayout()
        Me.FlowLayoutPanel12.SuspendLayout()
        Me.GroupBox13.SuspendLayout()
        Me.FlowLayoutPanel13.SuspendLayout()
        Me.GroupBox14.SuspendLayout()
        Me.FlowLayoutPanel14.SuspendLayout()
        Me.SuspendLayout()
        '
        'Label19
        '
        Me.Label19.BackColor = System.Drawing.SystemColors.ButtonFace
        Me.Label19.Font = New System.Drawing.Font("Times New Roman", 21.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label19.ForeColor = System.Drawing.Color.Navy
        Me.Label19.Location = New System.Drawing.Point(484, -5)
        Me.Label19.Name = "Label19"
        Me.Label19.Size = New System.Drawing.Size(390, 30)
        Me.Label19.TabIndex = 76
        Me.Label19.Text = "INGRESO DE GROMMETS"
        Me.Label19.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'groupBox26
        '
        Me.groupBox26.Anchor = System.Windows.Forms.AnchorStyles.None
        Me.groupBox26.Controls.Add(Me.flowLayoutPanel23)
        Me.groupBox26.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.groupBox26.ForeColor = System.Drawing.Color.Black
        Me.groupBox26.Location = New System.Drawing.Point(-8, 286)
        Me.groupBox26.Name = "groupBox26"
        Me.groupBox26.Size = New System.Drawing.Size(712, 69)
        Me.groupBox26.TabIndex = 84
        Me.groupBox26.TabStop = False
        Me.groupBox26.Text = "SIN GOLPES INTERNOS POR PINES O FICHAS"
        '
        'flowLayoutPanel23
        '
        Me.flowLayoutPanel23.AutoScroll = True
        Me.flowLayoutPanel23.Controls.Add(Me.rbSinGolpesSI)
        Me.flowLayoutPanel23.Controls.Add(Me.rbSinGolpesNO)
        Me.flowLayoutPanel23.Controls.Add(Me.txtEmpSinGolpes)
        Me.flowLayoutPanel23.Controls.Add(Me.txtFechaSinGolpes)
        Me.flowLayoutPanel23.Dock = System.Windows.Forms.DockStyle.Fill
        Me.flowLayoutPanel23.Location = New System.Drawing.Point(3, 22)
        Me.flowLayoutPanel23.Name = "flowLayoutPanel23"
        Me.flowLayoutPanel23.Size = New System.Drawing.Size(706, 44)
        Me.flowLayoutPanel23.TabIndex = 0
        '
        'rbSinGolpesSI
        '
        Me.rbSinGolpesSI.Appearance = System.Windows.Forms.Appearance.Button
        Me.rbSinGolpesSI.BackColor = System.Drawing.Color.White
        Me.rbSinGolpesSI.FlatAppearance.CheckedBackColor = System.Drawing.Color.Lime
        Me.rbSinGolpesSI.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.rbSinGolpesSI.Font = New System.Drawing.Font("Microsoft Sans Serif", 14.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.rbSinGolpesSI.ForeColor = System.Drawing.Color.FromArgb(CType(CType(41, Byte), Integer), CType(CType(121, Byte), Integer), CType(CType(255, Byte), Integer))
        Me.rbSinGolpesSI.Location = New System.Drawing.Point(3, 3)
        Me.rbSinGolpesSI.Name = "rbSinGolpesSI"
        Me.rbSinGolpesSI.Size = New System.Drawing.Size(70, 36)
        Me.rbSinGolpesSI.TabIndex = 0
        Me.rbSinGolpesSI.TabStop = True
        Me.rbSinGolpesSI.Text = "SI"
        Me.rbSinGolpesSI.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        Me.rbSinGolpesSI.UseVisualStyleBackColor = False
        '
        'rbSinGolpesNO
        '
        Me.rbSinGolpesNO.Appearance = System.Windows.Forms.Appearance.Button
        Me.rbSinGolpesNO.BackColor = System.Drawing.Color.White
        Me.rbSinGolpesNO.FlatAppearance.CheckedBackColor = System.Drawing.Color.Lime
        Me.rbSinGolpesNO.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.rbSinGolpesNO.Font = New System.Drawing.Font("Microsoft Sans Serif", 14.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.rbSinGolpesNO.ForeColor = System.Drawing.Color.FromArgb(CType(CType(41, Byte), Integer), CType(CType(121, Byte), Integer), CType(CType(255, Byte), Integer))
        Me.rbSinGolpesNO.Location = New System.Drawing.Point(79, 3)
        Me.rbSinGolpesNO.Name = "rbSinGolpesNO"
        Me.rbSinGolpesNO.Size = New System.Drawing.Size(73, 36)
        Me.rbSinGolpesNO.TabIndex = 1
        Me.rbSinGolpesNO.TabStop = True
        Me.rbSinGolpesNO.Text = "NO"
        Me.rbSinGolpesNO.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        Me.rbSinGolpesNO.UseVisualStyleBackColor = False
        '
        'txtEmpSinGolpes
        '
        Me.txtEmpSinGolpes.AcceptsReturn = True
        Me.txtEmpSinGolpes.AcceptsTab = True
        Me.txtEmpSinGolpes.Font = New System.Drawing.Font("Microsoft Sans Serif", 15.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.txtEmpSinGolpes.ForeColor = System.Drawing.SystemColors.GrayText
        Me.txtEmpSinGolpes.Location = New System.Drawing.Point(158, 3)
        Me.txtEmpSinGolpes.Name = "txtEmpSinGolpes"
        Me.txtEmpSinGolpes.Size = New System.Drawing.Size(201, 31)
        Me.txtEmpSinGolpes.TabIndex = 85
        Me.txtEmpSinGolpes.Text = "Empleado"
        '
        'txtFechaSinGolpes
        '
        Me.txtFechaSinGolpes.AcceptsReturn = True
        Me.txtFechaSinGolpes.AcceptsTab = True
        Me.txtFechaSinGolpes.Font = New System.Drawing.Font("Microsoft Sans Serif", 15.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.txtFechaSinGolpes.ForeColor = System.Drawing.SystemColors.GrayText
        Me.txtFechaSinGolpes.Location = New System.Drawing.Point(365, 3)
        Me.txtFechaSinGolpes.Name = "txtFechaSinGolpes"
        Me.txtFechaSinGolpes.Size = New System.Drawing.Size(201, 31)
        Me.txtFechaSinGolpes.TabIndex = 85
        Me.txtFechaSinGolpes.Text = "Fecha"
        '
        'txtNpart
        '
        Me.txtNpart.AcceptsReturn = True
        Me.txtNpart.AcceptsTab = True
        Me.txtNpart.Font = New System.Drawing.Font("Microsoft Sans Serif", 15.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.txtNpart.Location = New System.Drawing.Point(278, 26)
        Me.txtNpart.Name = "txtNpart"
        Me.txtNpart.Size = New System.Drawing.Size(270, 31)
        Me.txtNpart.TabIndex = 85
        '
        'Label23
        '
        Me.Label23.Font = New System.Drawing.Font("Microsoft Sans Serif", 15.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label23.Location = New System.Drawing.Point(7, 29)
        Me.Label23.Name = "Label23"
        Me.Label23.Size = New System.Drawing.Size(239, 28)
        Me.Label23.TabIndex = 86
        Me.Label23.Text = "NUMERO DE PARTE:"
        '
        'Label1
        '
        Me.Label1.Font = New System.Drawing.Font("Microsoft Sans Serif", 15.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label1.Location = New System.Drawing.Point(4, 65)
        Me.Label1.Name = "Label1"
        Me.Label1.Size = New System.Drawing.Size(265, 26)
        Me.Label1.TabIndex = 86
        Me.Label1.Text = "COLOR DE GROMMET:"
        '
        'Label24
        '
        Me.Label24.Font = New System.Drawing.Font("Microsoft Sans Serif", 15.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label24.Location = New System.Drawing.Point(894, 112)
        Me.Label24.Name = "Label24"
        Me.Label24.Size = New System.Drawing.Size(139, 30)
        Me.Label24.TabIndex = 86
        Me.Label24.Text = "DIAMETRO:"
        '
        'Label18
        '
        Me.Label18.Font = New System.Drawing.Font("Microsoft Sans Serif", 15.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label18.Location = New System.Drawing.Point(714, 306)
        Me.Label18.Name = "Label18"
        Me.Label18.Size = New System.Drawing.Size(299, 33)
        Me.Label18.TabIndex = 86
        Me.Label18.Text = "CANTIDAD FINAL PLATOS"
        '
        'txtCantPlat
        '
        Me.txtCantPlat.AcceptsReturn = True
        Me.txtCantPlat.AcceptsTab = True
        Me.txtCantPlat.Font = New System.Drawing.Font("Microsoft Sans Serif", 15.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.txtCantPlat.Location = New System.Drawing.Point(1039, 303)
        Me.txtCantPlat.Name = "txtCantPlat"
        Me.txtCantPlat.Size = New System.Drawing.Size(270, 31)
        Me.txtCantPlat.TabIndex = 85
        '
        'Label5
        '
        Me.Label5.Font = New System.Drawing.Font("Microsoft Sans Serif", 15.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label5.Location = New System.Drawing.Point(735, 184)
        Me.Label5.Name = "Label5"
        Me.Label5.Size = New System.Drawing.Size(301, 31)
        Me.Label5.TabIndex = 86
        Me.Label5.Text = "CANTIDAD DE GROMMET:"
        '
        'txtCantGrommet
        '
        Me.txtCantGrommet.AcceptsReturn = True
        Me.txtCantGrommet.AcceptsTab = True
        Me.txtCantGrommet.Font = New System.Drawing.Font("Microsoft Sans Serif", 15.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.txtCantGrommet.Location = New System.Drawing.Point(1042, 181)
        Me.txtCantGrommet.Name = "txtCantGrommet"
        Me.txtCantGrommet.Size = New System.Drawing.Size(270, 31)
        Me.txtCantGrommet.TabIndex = 85
        '
        'GroupBox1
        '
        Me.GroupBox1.Anchor = System.Windows.Forms.AnchorStyles.None
        Me.GroupBox1.Controls.Add(Me.FlowLayoutPanel1)
        Me.GroupBox1.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.GroupBox1.ForeColor = System.Drawing.Color.Black
        Me.GroupBox1.Location = New System.Drawing.Point(-8, 212)
        Me.GroupBox1.Name = "GroupBox1"
        Me.GroupBox1.Size = New System.Drawing.Size(715, 68)
        Me.GroupBox1.TabIndex = 84
        Me.GroupBox1.TabStop = False
        Me.GroupBox1.Text = "REVISAR ESQUELETOS EN GAUGE / CONDICIONES FISICAS PIN GAUGE MENOR A 0.256"""
        '
        'FlowLayoutPanel1
        '
        Me.FlowLayoutPanel1.AutoScroll = True
        Me.FlowLayoutPanel1.Controls.Add(Me.rbRevGaugeBuenos)
        Me.FlowLayoutPanel1.Controls.Add(Me.rbRevGaugeMalos)
        Me.FlowLayoutPanel1.Controls.Add(Me.txtFechaRevGauge)
        Me.FlowLayoutPanel1.Controls.Add(Me.txtEmpRevGauge)
        Me.FlowLayoutPanel1.Dock = System.Windows.Forms.DockStyle.Fill
        Me.FlowLayoutPanel1.Location = New System.Drawing.Point(3, 22)
        Me.FlowLayoutPanel1.Name = "FlowLayoutPanel1"
        Me.FlowLayoutPanel1.Size = New System.Drawing.Size(709, 43)
        Me.FlowLayoutPanel1.TabIndex = 0
        '
        'rbRevGaugeBuenos
        '
        Me.rbRevGaugeBuenos.Appearance = System.Windows.Forms.Appearance.Button
        Me.rbRevGaugeBuenos.BackColor = System.Drawing.Color.White
        Me.rbRevGaugeBuenos.FlatAppearance.CheckedBackColor = System.Drawing.Color.Lime
        Me.rbRevGaugeBuenos.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.rbRevGaugeBuenos.Font = New System.Drawing.Font("Microsoft Sans Serif", 14.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.rbRevGaugeBuenos.ForeColor = System.Drawing.Color.FromArgb(CType(CType(41, Byte), Integer), CType(CType(121, Byte), Integer), CType(CType(255, Byte), Integer))
        Me.rbRevGaugeBuenos.Location = New System.Drawing.Point(3, 3)
        Me.rbRevGaugeBuenos.Name = "rbRevGaugeBuenos"
        Me.rbRevGaugeBuenos.Size = New System.Drawing.Size(104, 35)
        Me.rbRevGaugeBuenos.TabIndex = 0
        Me.rbRevGaugeBuenos.TabStop = True
        Me.rbRevGaugeBuenos.Text = "BUENOS"
        Me.rbRevGaugeBuenos.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        Me.rbRevGaugeBuenos.UseVisualStyleBackColor = False
        '
        'rbRevGaugeMalos
        '
        Me.rbRevGaugeMalos.Appearance = System.Windows.Forms.Appearance.Button
        Me.rbRevGaugeMalos.BackColor = System.Drawing.Color.White
        Me.rbRevGaugeMalos.FlatAppearance.CheckedBackColor = System.Drawing.Color.Lime
        Me.rbRevGaugeMalos.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.rbRevGaugeMalos.Font = New System.Drawing.Font("Microsoft Sans Serif", 14.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.rbRevGaugeMalos.ForeColor = System.Drawing.Color.FromArgb(CType(CType(41, Byte), Integer), CType(CType(121, Byte), Integer), CType(CType(255, Byte), Integer))
        Me.rbRevGaugeMalos.Location = New System.Drawing.Point(113, 3)
        Me.rbRevGaugeMalos.Name = "rbRevGaugeMalos"
        Me.rbRevGaugeMalos.Size = New System.Drawing.Size(107, 35)
        Me.rbRevGaugeMalos.TabIndex = 1
        Me.rbRevGaugeMalos.TabStop = True
        Me.rbRevGaugeMalos.Text = "MALOS"
        Me.rbRevGaugeMalos.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        Me.rbRevGaugeMalos.UseVisualStyleBackColor = False
        '
        'txtFechaRevGauge
        '
        Me.txtFechaRevGauge.AcceptsReturn = True
        Me.txtFechaRevGauge.AcceptsTab = True
        Me.txtFechaRevGauge.Font = New System.Drawing.Font("Microsoft Sans Serif", 15.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.txtFechaRevGauge.ForeColor = System.Drawing.SystemColors.GrayText
        Me.txtFechaRevGauge.Location = New System.Drawing.Point(226, 3)
        Me.txtFechaRevGauge.Name = "txtFechaRevGauge"
        Me.txtFechaRevGauge.Size = New System.Drawing.Size(201, 31)
        Me.txtFechaRevGauge.TabIndex = 85
        Me.txtFechaRevGauge.Text = "Fecha"
        '
        'txtEmpRevGauge
        '
        Me.txtEmpRevGauge.AcceptsReturn = True
        Me.txtEmpRevGauge.AcceptsTab = True
        Me.txtEmpRevGauge.Font = New System.Drawing.Font("Microsoft Sans Serif", 15.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.txtEmpRevGauge.ForeColor = System.Drawing.SystemColors.GrayText
        Me.txtEmpRevGauge.Location = New System.Drawing.Point(433, 3)
        Me.txtEmpRevGauge.Name = "txtEmpRevGauge"
        Me.txtEmpRevGauge.Size = New System.Drawing.Size(201, 31)
        Me.txtEmpRevGauge.TabIndex = 85
        Me.txtEmpRevGauge.Text = "Empleado"
        '
        'Label2
        '
        Me.Label2.Font = New System.Drawing.Font("Microsoft Sans Serif", 15.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label2.Location = New System.Drawing.Point(7, 90)
        Me.Label2.Name = "Label2"
        Me.Label2.Size = New System.Drawing.Size(265, 50)
        Me.Label2.TabIndex = 86
        Me.Label2.Text = "ID DE ESQUELETO A ARMAR:"
        '
        'GroupBox2
        '
        Me.GroupBox2.Anchor = System.Windows.Forms.AnchorStyles.None
        Me.GroupBox2.Controls.Add(Me.FlowLayoutPanel2)
        Me.GroupBox2.Font = New System.Drawing.Font("Microsoft Sans Serif", 15.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.GroupBox2.ForeColor = System.Drawing.Color.Black
        Me.GroupBox2.Location = New System.Drawing.Point(949, 2)
        Me.GroupBox2.Name = "GroupBox2"
        Me.GroupBox2.Size = New System.Drawing.Size(363, 103)
        Me.GroupBox2.TabIndex = 84
        Me.GroupBox2.TabStop = False
        Me.GroupBox2.Text = "TIPO:"
        '
        'FlowLayoutPanel2
        '
        Me.FlowLayoutPanel2.AutoScroll = True
        Me.FlowLayoutPanel2.Controls.Add(Me.rbNuevo)
        Me.FlowLayoutPanel2.Controls.Add(Me.rbReac)
        Me.FlowLayoutPanel2.Controls.Add(Me.rbNA)
        Me.FlowLayoutPanel2.Dock = System.Windows.Forms.DockStyle.Fill
        Me.FlowLayoutPanel2.Location = New System.Drawing.Point(3, 27)
        Me.FlowLayoutPanel2.Name = "FlowLayoutPanel2"
        Me.FlowLayoutPanel2.Size = New System.Drawing.Size(357, 73)
        Me.FlowLayoutPanel2.TabIndex = 0
        '
        'rbNuevo
        '
        Me.rbNuevo.Appearance = System.Windows.Forms.Appearance.Button
        Me.rbNuevo.BackColor = System.Drawing.Color.White
        Me.rbNuevo.FlatAppearance.CheckedBackColor = System.Drawing.Color.Lime
        Me.rbNuevo.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.rbNuevo.Font = New System.Drawing.Font("Microsoft Sans Serif", 15.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.rbNuevo.ForeColor = System.Drawing.Color.FromArgb(CType(CType(41, Byte), Integer), CType(CType(121, Byte), Integer), CType(CType(255, Byte), Integer))
        Me.rbNuevo.Location = New System.Drawing.Point(3, 3)
        Me.rbNuevo.Name = "rbNuevo"
        Me.rbNuevo.Size = New System.Drawing.Size(101, 46)
        Me.rbNuevo.TabIndex = 0
        Me.rbNuevo.TabStop = True
        Me.rbNuevo.Text = "NUEVO"
        Me.rbNuevo.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        Me.rbNuevo.UseVisualStyleBackColor = False
        '
        'rbReac
        '
        Me.rbReac.Appearance = System.Windows.Forms.Appearance.Button
        Me.rbReac.BackColor = System.Drawing.Color.White
        Me.rbReac.FlatAppearance.CheckedBackColor = System.Drawing.Color.Lime
        Me.rbReac.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.rbReac.Font = New System.Drawing.Font("Microsoft Sans Serif", 15.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.rbReac.ForeColor = System.Drawing.Color.FromArgb(CType(CType(41, Byte), Integer), CType(CType(121, Byte), Integer), CType(CType(255, Byte), Integer))
        Me.rbReac.Location = New System.Drawing.Point(110, 3)
        Me.rbReac.Name = "rbReac"
        Me.rbReac.Size = New System.Drawing.Size(104, 46)
        Me.rbReac.TabIndex = 1
        Me.rbReac.TabStop = True
        Me.rbReac.Text = "REAC"
        Me.rbReac.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        Me.rbReac.UseVisualStyleBackColor = False
        '
        'rbNA
        '
        Me.rbNA.Appearance = System.Windows.Forms.Appearance.Button
        Me.rbNA.BackColor = System.Drawing.Color.White
        Me.rbNA.FlatAppearance.CheckedBackColor = System.Drawing.Color.Lime
        Me.rbNA.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.rbNA.Font = New System.Drawing.Font("Microsoft Sans Serif", 15.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.rbNA.ForeColor = System.Drawing.Color.FromArgb(CType(CType(41, Byte), Integer), CType(CType(121, Byte), Integer), CType(CType(255, Byte), Integer))
        Me.rbNA.Location = New System.Drawing.Point(220, 3)
        Me.rbNA.Name = "rbNA"
        Me.rbNA.Size = New System.Drawing.Size(104, 46)
        Me.rbNA.TabIndex = 1
        Me.rbNA.TabStop = True
        Me.rbNA.Text = "N/A"
        Me.rbNA.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        Me.rbNA.UseVisualStyleBackColor = False
        '
        'Label3
        '
        Me.Label3.Font = New System.Drawing.Font("Microsoft Sans Serif", 15.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label3.Location = New System.Drawing.Point(8, 182)
        Me.Label3.Name = "Label3"
        Me.Label3.Size = New System.Drawing.Size(265, 26)
        Me.Label3.TabIndex = 86
        Me.Label3.Text = "ID ANTERIOR:"
        '
        'GroupBox3
        '
        Me.GroupBox3.Anchor = System.Windows.Forms.AnchorStyles.None
        Me.GroupBox3.Controls.Add(Me.FlowLayoutPanel3)
        Me.GroupBox3.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.GroupBox3.ForeColor = System.Drawing.Color.Black
        Me.GroupBox3.Location = New System.Drawing.Point(-2, 361)
        Me.GroupBox3.Name = "GroupBox3"
        Me.GroupBox3.Size = New System.Drawing.Size(709, 69)
        Me.GroupBox3.TabIndex = 84
        Me.GroupBox3.TabStop = False
        Me.GroupBox3.Text = "ARMAR SET"
        '
        'FlowLayoutPanel3
        '
        Me.FlowLayoutPanel3.AutoScroll = True
        Me.FlowLayoutPanel3.Controls.Add(Me.rbtxtArmaSetSI)
        Me.FlowLayoutPanel3.Controls.Add(Me.rbtxtArmaSetNO)
        Me.FlowLayoutPanel3.Controls.Add(Me.txtEmpArmaSet)
        Me.FlowLayoutPanel3.Controls.Add(Me.txtFechaArmaSet)
        Me.FlowLayoutPanel3.Dock = System.Windows.Forms.DockStyle.Fill
        Me.FlowLayoutPanel3.Location = New System.Drawing.Point(3, 22)
        Me.FlowLayoutPanel3.Name = "FlowLayoutPanel3"
        Me.FlowLayoutPanel3.Size = New System.Drawing.Size(703, 44)
        Me.FlowLayoutPanel3.TabIndex = 0
        '
        'rbtxtArmaSetSI
        '
        Me.rbtxtArmaSetSI.Appearance = System.Windows.Forms.Appearance.Button
        Me.rbtxtArmaSetSI.BackColor = System.Drawing.Color.White
        Me.rbtxtArmaSetSI.FlatAppearance.CheckedBackColor = System.Drawing.Color.Lime
        Me.rbtxtArmaSetSI.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.rbtxtArmaSetSI.Font = New System.Drawing.Font("Microsoft Sans Serif", 14.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.rbtxtArmaSetSI.ForeColor = System.Drawing.Color.FromArgb(CType(CType(41, Byte), Integer), CType(CType(121, Byte), Integer), CType(CType(255, Byte), Integer))
        Me.rbtxtArmaSetSI.Location = New System.Drawing.Point(3, 3)
        Me.rbtxtArmaSetSI.Name = "rbtxtArmaSetSI"
        Me.rbtxtArmaSetSI.Size = New System.Drawing.Size(70, 36)
        Me.rbtxtArmaSetSI.TabIndex = 0
        Me.rbtxtArmaSetSI.TabStop = True
        Me.rbtxtArmaSetSI.Text = "SI"
        Me.rbtxtArmaSetSI.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        Me.rbtxtArmaSetSI.UseVisualStyleBackColor = False
        '
        'rbtxtArmaSetNO
        '
        Me.rbtxtArmaSetNO.Appearance = System.Windows.Forms.Appearance.Button
        Me.rbtxtArmaSetNO.BackColor = System.Drawing.Color.White
        Me.rbtxtArmaSetNO.FlatAppearance.CheckedBackColor = System.Drawing.Color.Lime
        Me.rbtxtArmaSetNO.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.rbtxtArmaSetNO.Font = New System.Drawing.Font("Microsoft Sans Serif", 14.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.rbtxtArmaSetNO.ForeColor = System.Drawing.Color.FromArgb(CType(CType(41, Byte), Integer), CType(CType(121, Byte), Integer), CType(CType(255, Byte), Integer))
        Me.rbtxtArmaSetNO.Location = New System.Drawing.Point(79, 3)
        Me.rbtxtArmaSetNO.Name = "rbtxtArmaSetNO"
        Me.rbtxtArmaSetNO.Size = New System.Drawing.Size(73, 36)
        Me.rbtxtArmaSetNO.TabIndex = 1
        Me.rbtxtArmaSetNO.TabStop = True
        Me.rbtxtArmaSetNO.Text = "NO"
        Me.rbtxtArmaSetNO.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        Me.rbtxtArmaSetNO.UseVisualStyleBackColor = False
        '
        'txtEmpArmaSet
        '
        Me.txtEmpArmaSet.AcceptsReturn = True
        Me.txtEmpArmaSet.AcceptsTab = True
        Me.txtEmpArmaSet.Font = New System.Drawing.Font("Microsoft Sans Serif", 15.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.txtEmpArmaSet.ForeColor = System.Drawing.SystemColors.GrayText
        Me.txtEmpArmaSet.Location = New System.Drawing.Point(158, 3)
        Me.txtEmpArmaSet.Name = "txtEmpArmaSet"
        Me.txtEmpArmaSet.Size = New System.Drawing.Size(201, 31)
        Me.txtEmpArmaSet.TabIndex = 85
        Me.txtEmpArmaSet.Text = "Empleado"
        '
        'txtFechaArmaSet
        '
        Me.txtFechaArmaSet.AcceptsReturn = True
        Me.txtFechaArmaSet.AcceptsTab = True
        Me.txtFechaArmaSet.Font = New System.Drawing.Font("Microsoft Sans Serif", 15.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.txtFechaArmaSet.ForeColor = System.Drawing.SystemColors.GrayText
        Me.txtFechaArmaSet.Location = New System.Drawing.Point(365, 3)
        Me.txtFechaArmaSet.Name = "txtFechaArmaSet"
        Me.txtFechaArmaSet.Size = New System.Drawing.Size(201, 31)
        Me.txtFechaArmaSet.TabIndex = 85
        Me.txtFechaArmaSet.Text = "Fecha"
        '
        'GroupBox4
        '
        Me.GroupBox4.Anchor = System.Windows.Forms.AnchorStyles.None
        Me.GroupBox4.Controls.Add(Me.FlowLayoutPanel4)
        Me.GroupBox4.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.GroupBox4.ForeColor = System.Drawing.Color.Black
        Me.GroupBox4.Location = New System.Drawing.Point(1, 436)
        Me.GroupBox4.Name = "GroupBox4"
        Me.GroupBox4.Size = New System.Drawing.Size(703, 69)
        Me.GroupBox4.TabIndex = 84
        Me.GroupBox4.TabStop = False
        Me.GroupBox4.Text = "TALQUEAR"
        '
        'FlowLayoutPanel4
        '
        Me.FlowLayoutPanel4.AutoScroll = True
        Me.FlowLayoutPanel4.Controls.Add(Me.rbTalquearSI)
        Me.FlowLayoutPanel4.Controls.Add(Me.rbTalquearNO)
        Me.FlowLayoutPanel4.Controls.Add(Me.txtEmpTalquear)
        Me.FlowLayoutPanel4.Controls.Add(Me.txtFechaTalquear)
        Me.FlowLayoutPanel4.Dock = System.Windows.Forms.DockStyle.Fill
        Me.FlowLayoutPanel4.Location = New System.Drawing.Point(3, 22)
        Me.FlowLayoutPanel4.Name = "FlowLayoutPanel4"
        Me.FlowLayoutPanel4.Size = New System.Drawing.Size(697, 44)
        Me.FlowLayoutPanel4.TabIndex = 0
        '
        'rbTalquearSI
        '
        Me.rbTalquearSI.Appearance = System.Windows.Forms.Appearance.Button
        Me.rbTalquearSI.BackColor = System.Drawing.Color.White
        Me.rbTalquearSI.FlatAppearance.CheckedBackColor = System.Drawing.Color.Lime
        Me.rbTalquearSI.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.rbTalquearSI.Font = New System.Drawing.Font("Microsoft Sans Serif", 14.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.rbTalquearSI.ForeColor = System.Drawing.Color.FromArgb(CType(CType(41, Byte), Integer), CType(CType(121, Byte), Integer), CType(CType(255, Byte), Integer))
        Me.rbTalquearSI.Location = New System.Drawing.Point(3, 3)
        Me.rbTalquearSI.Name = "rbTalquearSI"
        Me.rbTalquearSI.Size = New System.Drawing.Size(70, 36)
        Me.rbTalquearSI.TabIndex = 0
        Me.rbTalquearSI.TabStop = True
        Me.rbTalquearSI.Text = "SI"
        Me.rbTalquearSI.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        Me.rbTalquearSI.UseVisualStyleBackColor = False
        '
        'rbTalquearNO
        '
        Me.rbTalquearNO.Appearance = System.Windows.Forms.Appearance.Button
        Me.rbTalquearNO.BackColor = System.Drawing.Color.White
        Me.rbTalquearNO.FlatAppearance.CheckedBackColor = System.Drawing.Color.Lime
        Me.rbTalquearNO.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.rbTalquearNO.Font = New System.Drawing.Font("Microsoft Sans Serif", 14.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.rbTalquearNO.ForeColor = System.Drawing.Color.FromArgb(CType(CType(41, Byte), Integer), CType(CType(121, Byte), Integer), CType(CType(255, Byte), Integer))
        Me.rbTalquearNO.Location = New System.Drawing.Point(79, 3)
        Me.rbTalquearNO.Name = "rbTalquearNO"
        Me.rbTalquearNO.Size = New System.Drawing.Size(73, 36)
        Me.rbTalquearNO.TabIndex = 1
        Me.rbTalquearNO.TabStop = True
        Me.rbTalquearNO.Text = "NO"
        Me.rbTalquearNO.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        Me.rbTalquearNO.UseVisualStyleBackColor = False
        '
        'txtEmpTalquear
        '
        Me.txtEmpTalquear.AcceptsReturn = True
        Me.txtEmpTalquear.AcceptsTab = True
        Me.txtEmpTalquear.Font = New System.Drawing.Font("Microsoft Sans Serif", 15.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.txtEmpTalquear.ForeColor = System.Drawing.SystemColors.GrayText
        Me.txtEmpTalquear.Location = New System.Drawing.Point(158, 3)
        Me.txtEmpTalquear.Name = "txtEmpTalquear"
        Me.txtEmpTalquear.Size = New System.Drawing.Size(201, 31)
        Me.txtEmpTalquear.TabIndex = 85
        Me.txtEmpTalquear.Text = "Empleado"
        '
        'txtFechaTalquear
        '
        Me.txtFechaTalquear.AcceptsReturn = True
        Me.txtFechaTalquear.AcceptsTab = True
        Me.txtFechaTalquear.Font = New System.Drawing.Font("Microsoft Sans Serif", 15.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.txtFechaTalquear.ForeColor = System.Drawing.SystemColors.GrayText
        Me.txtFechaTalquear.Location = New System.Drawing.Point(365, 3)
        Me.txtFechaTalquear.Name = "txtFechaTalquear"
        Me.txtFechaTalquear.Size = New System.Drawing.Size(201, 31)
        Me.txtFechaTalquear.TabIndex = 85
        Me.txtFechaTalquear.Text = "Fecha"
        '
        'GroupBox5
        '
        Me.GroupBox5.Anchor = System.Windows.Forms.AnchorStyles.None
        Me.GroupBox5.Controls.Add(Me.FlowLayoutPanel5)
        Me.GroupBox5.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.GroupBox5.ForeColor = System.Drawing.Color.Black
        Me.GroupBox5.Location = New System.Drawing.Point(4, 511)
        Me.GroupBox5.Name = "GroupBox5"
        Me.GroupBox5.Size = New System.Drawing.Size(703, 69)
        Me.GroupBox5.TabIndex = 84
        Me.GroupBox5.TabStop = False
        Me.GroupBox5.Text = "PRENSAR"
        '
        'FlowLayoutPanel5
        '
        Me.FlowLayoutPanel5.AutoScroll = True
        Me.FlowLayoutPanel5.Controls.Add(Me.rbPrensarSI)
        Me.FlowLayoutPanel5.Controls.Add(Me.rbPrensarNO)
        Me.FlowLayoutPanel5.Controls.Add(Me.txtEmpPrensar)
        Me.FlowLayoutPanel5.Controls.Add(Me.txtFechaPrensar)
        Me.FlowLayoutPanel5.Dock = System.Windows.Forms.DockStyle.Fill
        Me.FlowLayoutPanel5.Location = New System.Drawing.Point(3, 22)
        Me.FlowLayoutPanel5.Name = "FlowLayoutPanel5"
        Me.FlowLayoutPanel5.Size = New System.Drawing.Size(697, 44)
        Me.FlowLayoutPanel5.TabIndex = 0
        '
        'rbPrensarSI
        '
        Me.rbPrensarSI.Appearance = System.Windows.Forms.Appearance.Button
        Me.rbPrensarSI.BackColor = System.Drawing.Color.White
        Me.rbPrensarSI.FlatAppearance.CheckedBackColor = System.Drawing.Color.Lime
        Me.rbPrensarSI.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.rbPrensarSI.Font = New System.Drawing.Font("Microsoft Sans Serif", 14.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.rbPrensarSI.ForeColor = System.Drawing.Color.FromArgb(CType(CType(41, Byte), Integer), CType(CType(121, Byte), Integer), CType(CType(255, Byte), Integer))
        Me.rbPrensarSI.Location = New System.Drawing.Point(3, 3)
        Me.rbPrensarSI.Name = "rbPrensarSI"
        Me.rbPrensarSI.Size = New System.Drawing.Size(70, 36)
        Me.rbPrensarSI.TabIndex = 0
        Me.rbPrensarSI.TabStop = True
        Me.rbPrensarSI.Text = "SI"
        Me.rbPrensarSI.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        Me.rbPrensarSI.UseVisualStyleBackColor = False
        '
        'rbPrensarNO
        '
        Me.rbPrensarNO.Appearance = System.Windows.Forms.Appearance.Button
        Me.rbPrensarNO.BackColor = System.Drawing.Color.White
        Me.rbPrensarNO.FlatAppearance.CheckedBackColor = System.Drawing.Color.Lime
        Me.rbPrensarNO.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.rbPrensarNO.Font = New System.Drawing.Font("Microsoft Sans Serif", 14.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.rbPrensarNO.ForeColor = System.Drawing.Color.FromArgb(CType(CType(41, Byte), Integer), CType(CType(121, Byte), Integer), CType(CType(255, Byte), Integer))
        Me.rbPrensarNO.Location = New System.Drawing.Point(79, 3)
        Me.rbPrensarNO.Name = "rbPrensarNO"
        Me.rbPrensarNO.Size = New System.Drawing.Size(73, 36)
        Me.rbPrensarNO.TabIndex = 1
        Me.rbPrensarNO.TabStop = True
        Me.rbPrensarNO.Text = "NO"
        Me.rbPrensarNO.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        Me.rbPrensarNO.UseVisualStyleBackColor = False
        '
        'txtEmpPrensar
        '
        Me.txtEmpPrensar.AcceptsReturn = True
        Me.txtEmpPrensar.AcceptsTab = True
        Me.txtEmpPrensar.Font = New System.Drawing.Font("Microsoft Sans Serif", 15.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.txtEmpPrensar.ForeColor = System.Drawing.SystemColors.GrayText
        Me.txtEmpPrensar.Location = New System.Drawing.Point(158, 3)
        Me.txtEmpPrensar.Name = "txtEmpPrensar"
        Me.txtEmpPrensar.Size = New System.Drawing.Size(201, 31)
        Me.txtEmpPrensar.TabIndex = 85
        Me.txtEmpPrensar.Text = "Empleado"
        '
        'txtFechaPrensar
        '
        Me.txtFechaPrensar.AcceptsReturn = True
        Me.txtFechaPrensar.AcceptsTab = True
        Me.txtFechaPrensar.Font = New System.Drawing.Font("Microsoft Sans Serif", 15.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.txtFechaPrensar.ForeColor = System.Drawing.SystemColors.GrayText
        Me.txtFechaPrensar.Location = New System.Drawing.Point(365, 3)
        Me.txtFechaPrensar.Name = "txtFechaPrensar"
        Me.txtFechaPrensar.Size = New System.Drawing.Size(201, 31)
        Me.txtFechaPrensar.TabIndex = 85
        Me.txtFechaPrensar.Text = "Fecha"
        '
        'GroupBox6
        '
        Me.GroupBox6.Anchor = System.Windows.Forms.AnchorStyles.None
        Me.GroupBox6.Controls.Add(Me.FlowLayoutPanel6)
        Me.GroupBox6.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.GroupBox6.ForeColor = System.Drawing.Color.Black
        Me.GroupBox6.Location = New System.Drawing.Point(7, 586)
        Me.GroupBox6.Name = "GroupBox6"
        Me.GroupBox6.Size = New System.Drawing.Size(700, 69)
        Me.GroupBox6.TabIndex = 84
        Me.GroupBox6.TabStop = False
        Me.GroupBox6.Text = "SOPLETEAR"
        '
        'FlowLayoutPanel6
        '
        Me.FlowLayoutPanel6.AutoScroll = True
        Me.FlowLayoutPanel6.Controls.Add(Me.rbSopletearSI)
        Me.FlowLayoutPanel6.Controls.Add(Me.rbSopletearNO)
        Me.FlowLayoutPanel6.Controls.Add(Me.txtEmpSopletear)
        Me.FlowLayoutPanel6.Controls.Add(Me.txtFechaSopletear)
        Me.FlowLayoutPanel6.Dock = System.Windows.Forms.DockStyle.Fill
        Me.FlowLayoutPanel6.Location = New System.Drawing.Point(3, 22)
        Me.FlowLayoutPanel6.Name = "FlowLayoutPanel6"
        Me.FlowLayoutPanel6.Size = New System.Drawing.Size(694, 44)
        Me.FlowLayoutPanel6.TabIndex = 0
        '
        'rbSopletearSI
        '
        Me.rbSopletearSI.Appearance = System.Windows.Forms.Appearance.Button
        Me.rbSopletearSI.BackColor = System.Drawing.Color.White
        Me.rbSopletearSI.FlatAppearance.CheckedBackColor = System.Drawing.Color.Lime
        Me.rbSopletearSI.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.rbSopletearSI.Font = New System.Drawing.Font("Microsoft Sans Serif", 14.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.rbSopletearSI.ForeColor = System.Drawing.Color.FromArgb(CType(CType(41, Byte), Integer), CType(CType(121, Byte), Integer), CType(CType(255, Byte), Integer))
        Me.rbSopletearSI.Location = New System.Drawing.Point(3, 3)
        Me.rbSopletearSI.Name = "rbSopletearSI"
        Me.rbSopletearSI.Size = New System.Drawing.Size(70, 36)
        Me.rbSopletearSI.TabIndex = 0
        Me.rbSopletearSI.TabStop = True
        Me.rbSopletearSI.Text = "SI"
        Me.rbSopletearSI.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        Me.rbSopletearSI.UseVisualStyleBackColor = False
        '
        'rbSopletearNO
        '
        Me.rbSopletearNO.Appearance = System.Windows.Forms.Appearance.Button
        Me.rbSopletearNO.BackColor = System.Drawing.Color.White
        Me.rbSopletearNO.FlatAppearance.CheckedBackColor = System.Drawing.Color.Lime
        Me.rbSopletearNO.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.rbSopletearNO.Font = New System.Drawing.Font("Microsoft Sans Serif", 14.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.rbSopletearNO.ForeColor = System.Drawing.Color.FromArgb(CType(CType(41, Byte), Integer), CType(CType(121, Byte), Integer), CType(CType(255, Byte), Integer))
        Me.rbSopletearNO.Location = New System.Drawing.Point(79, 3)
        Me.rbSopletearNO.Name = "rbSopletearNO"
        Me.rbSopletearNO.Size = New System.Drawing.Size(73, 36)
        Me.rbSopletearNO.TabIndex = 1
        Me.rbSopletearNO.TabStop = True
        Me.rbSopletearNO.Text = "NO"
        Me.rbSopletearNO.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        Me.rbSopletearNO.UseVisualStyleBackColor = False
        '
        'txtEmpSopletear
        '
        Me.txtEmpSopletear.AcceptsReturn = True
        Me.txtEmpSopletear.AcceptsTab = True
        Me.txtEmpSopletear.Font = New System.Drawing.Font("Microsoft Sans Serif", 15.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.txtEmpSopletear.ForeColor = System.Drawing.SystemColors.GrayText
        Me.txtEmpSopletear.Location = New System.Drawing.Point(158, 3)
        Me.txtEmpSopletear.Name = "txtEmpSopletear"
        Me.txtEmpSopletear.Size = New System.Drawing.Size(201, 31)
        Me.txtEmpSopletear.TabIndex = 85
        Me.txtEmpSopletear.Text = "Empleado"
        '
        'txtFechaSopletear
        '
        Me.txtFechaSopletear.AcceptsReturn = True
        Me.txtFechaSopletear.AcceptsTab = True
        Me.txtFechaSopletear.Font = New System.Drawing.Font("Microsoft Sans Serif", 15.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.txtFechaSopletear.ForeColor = System.Drawing.SystemColors.GrayText
        Me.txtFechaSopletear.Location = New System.Drawing.Point(365, 3)
        Me.txtFechaSopletear.Name = "txtFechaSopletear"
        Me.txtFechaSopletear.Size = New System.Drawing.Size(201, 31)
        Me.txtFechaSopletear.TabIndex = 85
        Me.txtFechaSopletear.Text = "Fecha"
        '
        'GroupBox7
        '
        Me.GroupBox7.Anchor = System.Windows.Forms.AnchorStyles.None
        Me.GroupBox7.Controls.Add(Me.FlowLayoutPanel7)
        Me.GroupBox7.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.GroupBox7.ForeColor = System.Drawing.Color.Black
        Me.GroupBox7.Location = New System.Drawing.Point(10, 661)
        Me.GroupBox7.Name = "GroupBox7"
        Me.GroupBox7.Size = New System.Drawing.Size(697, 69)
        Me.GroupBox7.TabIndex = 84
        Me.GroupBox7.TabStop = False
        Me.GroupBox7.Text = "PINTAR"
        '
        'FlowLayoutPanel7
        '
        Me.FlowLayoutPanel7.AutoScroll = True
        Me.FlowLayoutPanel7.Controls.Add(Me.rbPintarSI)
        Me.FlowLayoutPanel7.Controls.Add(Me.rbPintarNO)
        Me.FlowLayoutPanel7.Controls.Add(Me.txtEmpPintar)
        Me.FlowLayoutPanel7.Controls.Add(Me.txtFechaPintar)
        Me.FlowLayoutPanel7.Dock = System.Windows.Forms.DockStyle.Fill
        Me.FlowLayoutPanel7.Location = New System.Drawing.Point(3, 22)
        Me.FlowLayoutPanel7.Name = "FlowLayoutPanel7"
        Me.FlowLayoutPanel7.Size = New System.Drawing.Size(691, 44)
        Me.FlowLayoutPanel7.TabIndex = 0
        '
        'rbPintarSI
        '
        Me.rbPintarSI.Appearance = System.Windows.Forms.Appearance.Button
        Me.rbPintarSI.BackColor = System.Drawing.Color.White
        Me.rbPintarSI.FlatAppearance.CheckedBackColor = System.Drawing.Color.Lime
        Me.rbPintarSI.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.rbPintarSI.Font = New System.Drawing.Font("Microsoft Sans Serif", 14.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.rbPintarSI.ForeColor = System.Drawing.Color.FromArgb(CType(CType(41, Byte), Integer), CType(CType(121, Byte), Integer), CType(CType(255, Byte), Integer))
        Me.rbPintarSI.Location = New System.Drawing.Point(3, 3)
        Me.rbPintarSI.Name = "rbPintarSI"
        Me.rbPintarSI.Size = New System.Drawing.Size(70, 36)
        Me.rbPintarSI.TabIndex = 0
        Me.rbPintarSI.TabStop = True
        Me.rbPintarSI.Text = "SI"
        Me.rbPintarSI.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        Me.rbPintarSI.UseVisualStyleBackColor = False
        '
        'rbPintarNO
        '
        Me.rbPintarNO.Appearance = System.Windows.Forms.Appearance.Button
        Me.rbPintarNO.BackColor = System.Drawing.Color.White
        Me.rbPintarNO.FlatAppearance.CheckedBackColor = System.Drawing.Color.Lime
        Me.rbPintarNO.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.rbPintarNO.Font = New System.Drawing.Font("Microsoft Sans Serif", 14.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.rbPintarNO.ForeColor = System.Drawing.Color.FromArgb(CType(CType(41, Byte), Integer), CType(CType(121, Byte), Integer), CType(CType(255, Byte), Integer))
        Me.rbPintarNO.Location = New System.Drawing.Point(79, 3)
        Me.rbPintarNO.Name = "rbPintarNO"
        Me.rbPintarNO.Size = New System.Drawing.Size(73, 36)
        Me.rbPintarNO.TabIndex = 1
        Me.rbPintarNO.TabStop = True
        Me.rbPintarNO.Text = "NO"
        Me.rbPintarNO.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        Me.rbPintarNO.UseVisualStyleBackColor = False
        '
        'txtEmpPintar
        '
        Me.txtEmpPintar.AcceptsReturn = True
        Me.txtEmpPintar.AcceptsTab = True
        Me.txtEmpPintar.Font = New System.Drawing.Font("Microsoft Sans Serif", 15.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.txtEmpPintar.ForeColor = System.Drawing.SystemColors.GrayText
        Me.txtEmpPintar.Location = New System.Drawing.Point(158, 3)
        Me.txtEmpPintar.Name = "txtEmpPintar"
        Me.txtEmpPintar.Size = New System.Drawing.Size(201, 31)
        Me.txtEmpPintar.TabIndex = 85
        Me.txtEmpPintar.Text = "Empleado"
        '
        'txtFechaPintar
        '
        Me.txtFechaPintar.AcceptsReturn = True
        Me.txtFechaPintar.AcceptsTab = True
        Me.txtFechaPintar.Font = New System.Drawing.Font("Microsoft Sans Serif", 15.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.txtFechaPintar.ForeColor = System.Drawing.SystemColors.GrayText
        Me.txtFechaPintar.Location = New System.Drawing.Point(365, 3)
        Me.txtFechaPintar.Name = "txtFechaPintar"
        Me.txtFechaPintar.Size = New System.Drawing.Size(201, 31)
        Me.txtFechaPintar.TabIndex = 85
        Me.txtFechaPintar.Text = "Fecha"
        '
        'GroupBox8
        '
        Me.GroupBox8.Anchor = System.Windows.Forms.AnchorStyles.None
        Me.GroupBox8.Controls.Add(Me.FlowLayoutPanel8)
        Me.GroupBox8.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.GroupBox8.ForeColor = System.Drawing.Color.Black
        Me.GroupBox8.Location = New System.Drawing.Point(713, 218)
        Me.GroupBox8.Name = "GroupBox8"
        Me.GroupBox8.Size = New System.Drawing.Size(599, 69)
        Me.GroupBox8.TabIndex = 84
        Me.GroupBox8.TabStop = False
        Me.GroupBox8.Text = "CURAR"
        '
        'FlowLayoutPanel8
        '
        Me.FlowLayoutPanel8.AutoScroll = True
        Me.FlowLayoutPanel8.Controls.Add(Me.tbCurarSI)
        Me.FlowLayoutPanel8.Controls.Add(Me.rbCurarNO)
        Me.FlowLayoutPanel8.Controls.Add(Me.txtEmpCurar)
        Me.FlowLayoutPanel8.Controls.Add(Me.txtFechaCurar)
        Me.FlowLayoutPanel8.Dock = System.Windows.Forms.DockStyle.Fill
        Me.FlowLayoutPanel8.Location = New System.Drawing.Point(3, 22)
        Me.FlowLayoutPanel8.Name = "FlowLayoutPanel8"
        Me.FlowLayoutPanel8.Size = New System.Drawing.Size(593, 44)
        Me.FlowLayoutPanel8.TabIndex = 0
        '
        'tbCurarSI
        '
        Me.tbCurarSI.Appearance = System.Windows.Forms.Appearance.Button
        Me.tbCurarSI.BackColor = System.Drawing.Color.White
        Me.tbCurarSI.FlatAppearance.CheckedBackColor = System.Drawing.Color.Lime
        Me.tbCurarSI.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.tbCurarSI.Font = New System.Drawing.Font("Microsoft Sans Serif", 14.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.tbCurarSI.ForeColor = System.Drawing.Color.FromArgb(CType(CType(41, Byte), Integer), CType(CType(121, Byte), Integer), CType(CType(255, Byte), Integer))
        Me.tbCurarSI.Location = New System.Drawing.Point(3, 3)
        Me.tbCurarSI.Name = "tbCurarSI"
        Me.tbCurarSI.Size = New System.Drawing.Size(70, 36)
        Me.tbCurarSI.TabIndex = 0
        Me.tbCurarSI.TabStop = True
        Me.tbCurarSI.Text = "SI"
        Me.tbCurarSI.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        Me.tbCurarSI.UseVisualStyleBackColor = False
        '
        'rbCurarNO
        '
        Me.rbCurarNO.Appearance = System.Windows.Forms.Appearance.Button
        Me.rbCurarNO.BackColor = System.Drawing.Color.White
        Me.rbCurarNO.FlatAppearance.CheckedBackColor = System.Drawing.Color.Lime
        Me.rbCurarNO.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.rbCurarNO.Font = New System.Drawing.Font("Microsoft Sans Serif", 14.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.rbCurarNO.ForeColor = System.Drawing.Color.FromArgb(CType(CType(41, Byte), Integer), CType(CType(121, Byte), Integer), CType(CType(255, Byte), Integer))
        Me.rbCurarNO.Location = New System.Drawing.Point(79, 3)
        Me.rbCurarNO.Name = "rbCurarNO"
        Me.rbCurarNO.Size = New System.Drawing.Size(73, 36)
        Me.rbCurarNO.TabIndex = 1
        Me.rbCurarNO.TabStop = True
        Me.rbCurarNO.Text = "NO"
        Me.rbCurarNO.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        Me.rbCurarNO.UseVisualStyleBackColor = False
        '
        'txtEmpCurar
        '
        Me.txtEmpCurar.AcceptsReturn = True
        Me.txtEmpCurar.AcceptsTab = True
        Me.txtEmpCurar.Font = New System.Drawing.Font("Microsoft Sans Serif", 15.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.txtEmpCurar.ForeColor = System.Drawing.SystemColors.GrayText
        Me.txtEmpCurar.Location = New System.Drawing.Point(158, 3)
        Me.txtEmpCurar.Name = "txtEmpCurar"
        Me.txtEmpCurar.Size = New System.Drawing.Size(201, 31)
        Me.txtEmpCurar.TabIndex = 85
        Me.txtEmpCurar.Text = "Empleado"
        '
        'txtFechaCurar
        '
        Me.txtFechaCurar.AcceptsReturn = True
        Me.txtFechaCurar.AcceptsTab = True
        Me.txtFechaCurar.Font = New System.Drawing.Font("Microsoft Sans Serif", 15.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.txtFechaCurar.ForeColor = System.Drawing.SystemColors.GrayText
        Me.txtFechaCurar.Location = New System.Drawing.Point(365, 3)
        Me.txtFechaCurar.Name = "txtFechaCurar"
        Me.txtFechaCurar.Size = New System.Drawing.Size(201, 31)
        Me.txtFechaCurar.TabIndex = 85
        Me.txtFechaCurar.Text = "Fecha"
        '
        'GroupBox9
        '
        Me.GroupBox9.Anchor = System.Windows.Forms.AnchorStyles.None
        Me.GroupBox9.Controls.Add(Me.FlowLayoutPanel9)
        Me.GroupBox9.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.GroupBox9.ForeColor = System.Drawing.Color.Black
        Me.GroupBox9.Location = New System.Drawing.Point(554, 42)
        Me.GroupBox9.Name = "GroupBox9"
        Me.GroupBox9.Size = New System.Drawing.Size(342, 146)
        Me.GroupBox9.TabIndex = 87
        Me.GroupBox9.TabStop = False
        Me.GroupBox9.Text = "RETIRAR SET ANTERIOR"
        '
        'FlowLayoutPanel9
        '
        Me.FlowLayoutPanel9.AutoScroll = True
        Me.FlowLayoutPanel9.Controls.Add(Me.rbRetAntSI)
        Me.FlowLayoutPanel9.Controls.Add(Me.rbRetAntNO)
        Me.FlowLayoutPanel9.Controls.Add(Me.txtEmpRetAnt)
        Me.FlowLayoutPanel9.Controls.Add(Me.txtFechaRetAnt)
        Me.FlowLayoutPanel9.Dock = System.Windows.Forms.DockStyle.Fill
        Me.FlowLayoutPanel9.Location = New System.Drawing.Point(3, 22)
        Me.FlowLayoutPanel9.Name = "FlowLayoutPanel9"
        Me.FlowLayoutPanel9.Size = New System.Drawing.Size(336, 121)
        Me.FlowLayoutPanel9.TabIndex = 0
        '
        'rbRetAntSI
        '
        Me.rbRetAntSI.Appearance = System.Windows.Forms.Appearance.Button
        Me.rbRetAntSI.BackColor = System.Drawing.Color.White
        Me.rbRetAntSI.FlatAppearance.CheckedBackColor = System.Drawing.Color.Lime
        Me.rbRetAntSI.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.rbRetAntSI.Font = New System.Drawing.Font("Microsoft Sans Serif", 14.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.rbRetAntSI.ForeColor = System.Drawing.Color.FromArgb(CType(CType(41, Byte), Integer), CType(CType(121, Byte), Integer), CType(CType(255, Byte), Integer))
        Me.rbRetAntSI.Location = New System.Drawing.Point(3, 3)
        Me.rbRetAntSI.Name = "rbRetAntSI"
        Me.rbRetAntSI.Size = New System.Drawing.Size(70, 36)
        Me.rbRetAntSI.TabIndex = 0
        Me.rbRetAntSI.TabStop = True
        Me.rbRetAntSI.Text = "SI"
        Me.rbRetAntSI.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        Me.rbRetAntSI.UseVisualStyleBackColor = False
        '
        'rbRetAntNO
        '
        Me.rbRetAntNO.Appearance = System.Windows.Forms.Appearance.Button
        Me.rbRetAntNO.BackColor = System.Drawing.Color.White
        Me.rbRetAntNO.FlatAppearance.CheckedBackColor = System.Drawing.Color.Lime
        Me.rbRetAntNO.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.rbRetAntNO.Font = New System.Drawing.Font("Microsoft Sans Serif", 14.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.rbRetAntNO.ForeColor = System.Drawing.Color.FromArgb(CType(CType(41, Byte), Integer), CType(CType(121, Byte), Integer), CType(CType(255, Byte), Integer))
        Me.rbRetAntNO.Location = New System.Drawing.Point(79, 3)
        Me.rbRetAntNO.Name = "rbRetAntNO"
        Me.rbRetAntNO.Size = New System.Drawing.Size(73, 36)
        Me.rbRetAntNO.TabIndex = 1
        Me.rbRetAntNO.TabStop = True
        Me.rbRetAntNO.Text = "NO"
        Me.rbRetAntNO.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        Me.rbRetAntNO.UseVisualStyleBackColor = False
        '
        'txtEmpRetAnt
        '
        Me.txtEmpRetAnt.AcceptsReturn = True
        Me.txtEmpRetAnt.AcceptsTab = True
        Me.txtEmpRetAnt.Font = New System.Drawing.Font("Microsoft Sans Serif", 15.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.txtEmpRetAnt.ForeColor = System.Drawing.SystemColors.GrayText
        Me.txtEmpRetAnt.Location = New System.Drawing.Point(3, 45)
        Me.txtEmpRetAnt.Name = "txtEmpRetAnt"
        Me.txtEmpRetAnt.Size = New System.Drawing.Size(201, 31)
        Me.txtEmpRetAnt.TabIndex = 85
        Me.txtEmpRetAnt.Text = "Empleado"
        '
        'txtFechaRetAnt
        '
        Me.txtFechaRetAnt.AcceptsReturn = True
        Me.txtFechaRetAnt.AcceptsTab = True
        Me.txtFechaRetAnt.Font = New System.Drawing.Font("Microsoft Sans Serif", 15.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.txtFechaRetAnt.ForeColor = System.Drawing.SystemColors.GrayText
        Me.txtFechaRetAnt.Location = New System.Drawing.Point(3, 82)
        Me.txtFechaRetAnt.Name = "txtFechaRetAnt"
        Me.txtFechaRetAnt.Size = New System.Drawing.Size(201, 31)
        Me.txtFechaRetAnt.TabIndex = 85
        Me.txtFechaRetAnt.Text = "Fecha"
        '
        'Label4
        '
        Me.Label4.Font = New System.Drawing.Font("Microsoft Sans Serif", 15.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label4.Location = New System.Drawing.Point(894, 146)
        Me.Label4.Name = "Label4"
        Me.Label4.Size = New System.Drawing.Size(301, 31)
        Me.Label4.TabIndex = 86
        Me.Label4.Text = "NUM VALE"
        '
        'txtVale
        '
        Me.txtVale.AcceptsReturn = True
        Me.txtVale.AcceptsTab = True
        Me.txtVale.Font = New System.Drawing.Font("Microsoft Sans Serif", 15.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.txtVale.Location = New System.Drawing.Point(1039, 145)
        Me.txtVale.Name = "txtVale"
        Me.txtVale.Size = New System.Drawing.Size(270, 31)
        Me.txtVale.TabIndex = 85
        '
        'GroupBox10
        '
        Me.GroupBox10.Anchor = System.Windows.Forms.AnchorStyles.None
        Me.GroupBox10.Controls.Add(Me.FlowLayoutPanel10)
        Me.GroupBox10.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.GroupBox10.ForeColor = System.Drawing.Color.Black
        Me.GroupBox10.Location = New System.Drawing.Point(719, 342)
        Me.GroupBox10.Name = "GroupBox10"
        Me.GroupBox10.Size = New System.Drawing.Size(599, 69)
        Me.GroupBox10.TabIndex = 84
        Me.GroupBox10.TabStop = False
        Me.GroupBox10.Text = "DESARMADO"
        '
        'FlowLayoutPanel10
        '
        Me.FlowLayoutPanel10.AutoScroll = True
        Me.FlowLayoutPanel10.Controls.Add(Me.rbDesarmadoSI)
        Me.FlowLayoutPanel10.Controls.Add(Me.rbDesarmadoNO)
        Me.FlowLayoutPanel10.Controls.Add(Me.txtEmpDesarmado)
        Me.FlowLayoutPanel10.Controls.Add(Me.txtFechaDesarmado)
        Me.FlowLayoutPanel10.Dock = System.Windows.Forms.DockStyle.Fill
        Me.FlowLayoutPanel10.Location = New System.Drawing.Point(3, 22)
        Me.FlowLayoutPanel10.Name = "FlowLayoutPanel10"
        Me.FlowLayoutPanel10.Size = New System.Drawing.Size(593, 44)
        Me.FlowLayoutPanel10.TabIndex = 0
        '
        'rbDesarmadoSI
        '
        Me.rbDesarmadoSI.Appearance = System.Windows.Forms.Appearance.Button
        Me.rbDesarmadoSI.BackColor = System.Drawing.Color.White
        Me.rbDesarmadoSI.FlatAppearance.CheckedBackColor = System.Drawing.Color.Lime
        Me.rbDesarmadoSI.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.rbDesarmadoSI.Font = New System.Drawing.Font("Microsoft Sans Serif", 14.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.rbDesarmadoSI.ForeColor = System.Drawing.Color.FromArgb(CType(CType(41, Byte), Integer), CType(CType(121, Byte), Integer), CType(CType(255, Byte), Integer))
        Me.rbDesarmadoSI.Location = New System.Drawing.Point(3, 3)
        Me.rbDesarmadoSI.Name = "rbDesarmadoSI"
        Me.rbDesarmadoSI.Size = New System.Drawing.Size(70, 36)
        Me.rbDesarmadoSI.TabIndex = 0
        Me.rbDesarmadoSI.TabStop = True
        Me.rbDesarmadoSI.Text = "SI"
        Me.rbDesarmadoSI.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        Me.rbDesarmadoSI.UseVisualStyleBackColor = False
        '
        'rbDesarmadoNO
        '
        Me.rbDesarmadoNO.Appearance = System.Windows.Forms.Appearance.Button
        Me.rbDesarmadoNO.BackColor = System.Drawing.Color.White
        Me.rbDesarmadoNO.FlatAppearance.CheckedBackColor = System.Drawing.Color.Lime
        Me.rbDesarmadoNO.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.rbDesarmadoNO.Font = New System.Drawing.Font("Microsoft Sans Serif", 14.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.rbDesarmadoNO.ForeColor = System.Drawing.Color.FromArgb(CType(CType(41, Byte), Integer), CType(CType(121, Byte), Integer), CType(CType(255, Byte), Integer))
        Me.rbDesarmadoNO.Location = New System.Drawing.Point(79, 3)
        Me.rbDesarmadoNO.Name = "rbDesarmadoNO"
        Me.rbDesarmadoNO.Size = New System.Drawing.Size(73, 36)
        Me.rbDesarmadoNO.TabIndex = 1
        Me.rbDesarmadoNO.TabStop = True
        Me.rbDesarmadoNO.Text = "NO"
        Me.rbDesarmadoNO.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        Me.rbDesarmadoNO.UseVisualStyleBackColor = False
        '
        'txtEmpDesarmado
        '
        Me.txtEmpDesarmado.AcceptsReturn = True
        Me.txtEmpDesarmado.AcceptsTab = True
        Me.txtEmpDesarmado.Font = New System.Drawing.Font("Microsoft Sans Serif", 15.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.txtEmpDesarmado.ForeColor = System.Drawing.SystemColors.GrayText
        Me.txtEmpDesarmado.Location = New System.Drawing.Point(158, 3)
        Me.txtEmpDesarmado.Name = "txtEmpDesarmado"
        Me.txtEmpDesarmado.Size = New System.Drawing.Size(201, 31)
        Me.txtEmpDesarmado.TabIndex = 85
        Me.txtEmpDesarmado.Text = "Empleado"
        '
        'txtFechaDesarmado
        '
        Me.txtFechaDesarmado.AcceptsReturn = True
        Me.txtFechaDesarmado.AcceptsTab = True
        Me.txtFechaDesarmado.Font = New System.Drawing.Font("Microsoft Sans Serif", 15.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.txtFechaDesarmado.ForeColor = System.Drawing.SystemColors.GrayText
        Me.txtFechaDesarmado.Location = New System.Drawing.Point(365, 3)
        Me.txtFechaDesarmado.Name = "txtFechaDesarmado"
        Me.txtFechaDesarmado.Size = New System.Drawing.Size(201, 31)
        Me.txtFechaDesarmado.TabIndex = 85
        Me.txtFechaDesarmado.Text = "Fecha"
        '
        'GroupBox11
        '
        Me.GroupBox11.Anchor = System.Windows.Forms.AnchorStyles.None
        Me.GroupBox11.Controls.Add(Me.FlowLayoutPanel11)
        Me.GroupBox11.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.GroupBox11.ForeColor = System.Drawing.Color.Black
        Me.GroupBox11.Location = New System.Drawing.Point(719, 417)
        Me.GroupBox11.Name = "GroupBox11"
        Me.GroupBox11.Size = New System.Drawing.Size(599, 69)
        Me.GroupBox11.TabIndex = 84
        Me.GroupBox11.TabStop = False
        Me.GroupBox11.Text = "DAR DE ALTA EN BASE DATOS"
        '
        'FlowLayoutPanel11
        '
        Me.FlowLayoutPanel11.AutoScroll = True
        Me.FlowLayoutPanel11.Controls.Add(Me.rbDBSI)
        Me.FlowLayoutPanel11.Controls.Add(Me.rbDBNO)
        Me.FlowLayoutPanel11.Controls.Add(Me.txtEmpAltaDB)
        Me.FlowLayoutPanel11.Controls.Add(Me.txtFechaAltaDB)
        Me.FlowLayoutPanel11.Dock = System.Windows.Forms.DockStyle.Fill
        Me.FlowLayoutPanel11.Location = New System.Drawing.Point(3, 22)
        Me.FlowLayoutPanel11.Name = "FlowLayoutPanel11"
        Me.FlowLayoutPanel11.Size = New System.Drawing.Size(593, 44)
        Me.FlowLayoutPanel11.TabIndex = 0
        '
        'rbDBSI
        '
        Me.rbDBSI.Appearance = System.Windows.Forms.Appearance.Button
        Me.rbDBSI.BackColor = System.Drawing.Color.White
        Me.rbDBSI.FlatAppearance.CheckedBackColor = System.Drawing.Color.Lime
        Me.rbDBSI.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.rbDBSI.Font = New System.Drawing.Font("Microsoft Sans Serif", 14.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.rbDBSI.ForeColor = System.Drawing.Color.FromArgb(CType(CType(41, Byte), Integer), CType(CType(121, Byte), Integer), CType(CType(255, Byte), Integer))
        Me.rbDBSI.Location = New System.Drawing.Point(3, 3)
        Me.rbDBSI.Name = "rbDBSI"
        Me.rbDBSI.Size = New System.Drawing.Size(70, 36)
        Me.rbDBSI.TabIndex = 0
        Me.rbDBSI.TabStop = True
        Me.rbDBSI.Text = "SI"
        Me.rbDBSI.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        Me.rbDBSI.UseVisualStyleBackColor = False
        '
        'rbDBNO
        '
        Me.rbDBNO.Appearance = System.Windows.Forms.Appearance.Button
        Me.rbDBNO.BackColor = System.Drawing.Color.White
        Me.rbDBNO.FlatAppearance.CheckedBackColor = System.Drawing.Color.Lime
        Me.rbDBNO.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.rbDBNO.Font = New System.Drawing.Font("Microsoft Sans Serif", 14.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.rbDBNO.ForeColor = System.Drawing.Color.FromArgb(CType(CType(41, Byte), Integer), CType(CType(121, Byte), Integer), CType(CType(255, Byte), Integer))
        Me.rbDBNO.Location = New System.Drawing.Point(79, 3)
        Me.rbDBNO.Name = "rbDBNO"
        Me.rbDBNO.Size = New System.Drawing.Size(73, 36)
        Me.rbDBNO.TabIndex = 1
        Me.rbDBNO.TabStop = True
        Me.rbDBNO.Text = "NO"
        Me.rbDBNO.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        Me.rbDBNO.UseVisualStyleBackColor = False
        '
        'txtEmpAltaDB
        '
        Me.txtEmpAltaDB.AcceptsReturn = True
        Me.txtEmpAltaDB.AcceptsTab = True
        Me.txtEmpAltaDB.Font = New System.Drawing.Font("Microsoft Sans Serif", 15.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.txtEmpAltaDB.ForeColor = System.Drawing.SystemColors.GrayText
        Me.txtEmpAltaDB.Location = New System.Drawing.Point(158, 3)
        Me.txtEmpAltaDB.Name = "txtEmpAltaDB"
        Me.txtEmpAltaDB.Size = New System.Drawing.Size(201, 31)
        Me.txtEmpAltaDB.TabIndex = 85
        Me.txtEmpAltaDB.Text = "Empleado"
        '
        'txtFechaAltaDB
        '
        Me.txtFechaAltaDB.AcceptsReturn = True
        Me.txtFechaAltaDB.AcceptsTab = True
        Me.txtFechaAltaDB.Font = New System.Drawing.Font("Microsoft Sans Serif", 15.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.txtFechaAltaDB.ForeColor = System.Drawing.SystemColors.GrayText
        Me.txtFechaAltaDB.Location = New System.Drawing.Point(365, 3)
        Me.txtFechaAltaDB.Name = "txtFechaAltaDB"
        Me.txtFechaAltaDB.Size = New System.Drawing.Size(201, 31)
        Me.txtFechaAltaDB.TabIndex = 85
        Me.txtFechaAltaDB.Text = "Fecha"
        '
        'GroupBox12
        '
        Me.GroupBox12.Anchor = System.Windows.Forms.AnchorStyles.None
        Me.GroupBox12.Controls.Add(Me.FlowLayoutPanel12)
        Me.GroupBox12.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.GroupBox12.ForeColor = System.Drawing.Color.Black
        Me.GroupBox12.Location = New System.Drawing.Point(725, 492)
        Me.GroupBox12.Name = "GroupBox12"
        Me.GroupBox12.Size = New System.Drawing.Size(599, 69)
        Me.GroupBox12.TabIndex = 84
        Me.GroupBox12.TabStop = False
        Me.GroupBox12.Text = "REVISO TECNICO TOOLING"
        '
        'FlowLayoutPanel12
        '
        Me.FlowLayoutPanel12.AutoScroll = True
        Me.FlowLayoutPanel12.Controls.Add(Me.rbRevTecSI)
        Me.FlowLayoutPanel12.Controls.Add(Me.rbRevTecNO)
        Me.FlowLayoutPanel12.Controls.Add(Me.txtEmpRevTec)
        Me.FlowLayoutPanel12.Controls.Add(Me.txtFechaRevTec)
        Me.FlowLayoutPanel12.Dock = System.Windows.Forms.DockStyle.Fill
        Me.FlowLayoutPanel12.Location = New System.Drawing.Point(3, 22)
        Me.FlowLayoutPanel12.Name = "FlowLayoutPanel12"
        Me.FlowLayoutPanel12.Size = New System.Drawing.Size(593, 44)
        Me.FlowLayoutPanel12.TabIndex = 0
        '
        'rbRevTecSI
        '
        Me.rbRevTecSI.Appearance = System.Windows.Forms.Appearance.Button
        Me.rbRevTecSI.BackColor = System.Drawing.Color.White
        Me.rbRevTecSI.FlatAppearance.CheckedBackColor = System.Drawing.Color.Lime
        Me.rbRevTecSI.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.rbRevTecSI.Font = New System.Drawing.Font("Microsoft Sans Serif", 14.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.rbRevTecSI.ForeColor = System.Drawing.Color.FromArgb(CType(CType(41, Byte), Integer), CType(CType(121, Byte), Integer), CType(CType(255, Byte), Integer))
        Me.rbRevTecSI.Location = New System.Drawing.Point(3, 3)
        Me.rbRevTecSI.Name = "rbRevTecSI"
        Me.rbRevTecSI.Size = New System.Drawing.Size(70, 36)
        Me.rbRevTecSI.TabIndex = 0
        Me.rbRevTecSI.TabStop = True
        Me.rbRevTecSI.Text = "SI"
        Me.rbRevTecSI.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        Me.rbRevTecSI.UseVisualStyleBackColor = False
        '
        'rbRevTecNO
        '
        Me.rbRevTecNO.Appearance = System.Windows.Forms.Appearance.Button
        Me.rbRevTecNO.BackColor = System.Drawing.Color.White
        Me.rbRevTecNO.FlatAppearance.CheckedBackColor = System.Drawing.Color.Lime
        Me.rbRevTecNO.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.rbRevTecNO.Font = New System.Drawing.Font("Microsoft Sans Serif", 14.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.rbRevTecNO.ForeColor = System.Drawing.Color.FromArgb(CType(CType(41, Byte), Integer), CType(CType(121, Byte), Integer), CType(CType(255, Byte), Integer))
        Me.rbRevTecNO.Location = New System.Drawing.Point(79, 3)
        Me.rbRevTecNO.Name = "rbRevTecNO"
        Me.rbRevTecNO.Size = New System.Drawing.Size(73, 36)
        Me.rbRevTecNO.TabIndex = 1
        Me.rbRevTecNO.TabStop = True
        Me.rbRevTecNO.Text = "NO"
        Me.rbRevTecNO.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        Me.rbRevTecNO.UseVisualStyleBackColor = False
        '
        'txtEmpRevTec
        '
        Me.txtEmpRevTec.AcceptsReturn = True
        Me.txtEmpRevTec.AcceptsTab = True
        Me.txtEmpRevTec.Font = New System.Drawing.Font("Microsoft Sans Serif", 15.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.txtEmpRevTec.ForeColor = System.Drawing.SystemColors.GrayText
        Me.txtEmpRevTec.Location = New System.Drawing.Point(158, 3)
        Me.txtEmpRevTec.Name = "txtEmpRevTec"
        Me.txtEmpRevTec.Size = New System.Drawing.Size(201, 31)
        Me.txtEmpRevTec.TabIndex = 85
        Me.txtEmpRevTec.Text = "Empleado"
        '
        'txtFechaRevTec
        '
        Me.txtFechaRevTec.AcceptsReturn = True
        Me.txtFechaRevTec.AcceptsTab = True
        Me.txtFechaRevTec.Font = New System.Drawing.Font("Microsoft Sans Serif", 15.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.txtFechaRevTec.ForeColor = System.Drawing.SystemColors.GrayText
        Me.txtFechaRevTec.Location = New System.Drawing.Point(365, 3)
        Me.txtFechaRevTec.Name = "txtFechaRevTec"
        Me.txtFechaRevTec.Size = New System.Drawing.Size(201, 31)
        Me.txtFechaRevTec.TabIndex = 85
        Me.txtFechaRevTec.Text = "Fecha"
        '
        'GroupBox13
        '
        Me.GroupBox13.Anchor = System.Windows.Forms.AnchorStyles.None
        Me.GroupBox13.Controls.Add(Me.FlowLayoutPanel13)
        Me.GroupBox13.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.GroupBox13.ForeColor = System.Drawing.Color.Black
        Me.GroupBox13.Location = New System.Drawing.Point(725, 567)
        Me.GroupBox13.Name = "GroupBox13"
        Me.GroupBox13.Size = New System.Drawing.Size(599, 69)
        Me.GroupBox13.TabIndex = 84
        Me.GroupBox13.TabStop = False
        Me.GroupBox13.Text = "ENTREGAR A PRODUCCION"
        '
        'FlowLayoutPanel13
        '
        Me.FlowLayoutPanel13.AutoScroll = True
        Me.FlowLayoutPanel13.Controls.Add(Me.rbEntregarSI)
        Me.FlowLayoutPanel13.Controls.Add(Me.rbEntregarNO)
        Me.FlowLayoutPanel13.Controls.Add(Me.txtEmpEntregar)
        Me.FlowLayoutPanel13.Controls.Add(Me.txtFechaEntregar)
        Me.FlowLayoutPanel13.Dock = System.Windows.Forms.DockStyle.Fill
        Me.FlowLayoutPanel13.Location = New System.Drawing.Point(3, 22)
        Me.FlowLayoutPanel13.Name = "FlowLayoutPanel13"
        Me.FlowLayoutPanel13.Size = New System.Drawing.Size(593, 44)
        Me.FlowLayoutPanel13.TabIndex = 0
        '
        'rbEntregarSI
        '
        Me.rbEntregarSI.Appearance = System.Windows.Forms.Appearance.Button
        Me.rbEntregarSI.BackColor = System.Drawing.Color.White
        Me.rbEntregarSI.FlatAppearance.CheckedBackColor = System.Drawing.Color.Lime
        Me.rbEntregarSI.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.rbEntregarSI.Font = New System.Drawing.Font("Microsoft Sans Serif", 14.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.rbEntregarSI.ForeColor = System.Drawing.Color.FromArgb(CType(CType(41, Byte), Integer), CType(CType(121, Byte), Integer), CType(CType(255, Byte), Integer))
        Me.rbEntregarSI.Location = New System.Drawing.Point(3, 3)
        Me.rbEntregarSI.Name = "rbEntregarSI"
        Me.rbEntregarSI.Size = New System.Drawing.Size(70, 36)
        Me.rbEntregarSI.TabIndex = 0
        Me.rbEntregarSI.TabStop = True
        Me.rbEntregarSI.Text = "SI"
        Me.rbEntregarSI.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        Me.rbEntregarSI.UseVisualStyleBackColor = False
        '
        'rbEntregarNO
        '
        Me.rbEntregarNO.Appearance = System.Windows.Forms.Appearance.Button
        Me.rbEntregarNO.BackColor = System.Drawing.Color.White
        Me.rbEntregarNO.FlatAppearance.CheckedBackColor = System.Drawing.Color.Lime
        Me.rbEntregarNO.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.rbEntregarNO.Font = New System.Drawing.Font("Microsoft Sans Serif", 14.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.rbEntregarNO.ForeColor = System.Drawing.Color.FromArgb(CType(CType(41, Byte), Integer), CType(CType(121, Byte), Integer), CType(CType(255, Byte), Integer))
        Me.rbEntregarNO.Location = New System.Drawing.Point(79, 3)
        Me.rbEntregarNO.Name = "rbEntregarNO"
        Me.rbEntregarNO.Size = New System.Drawing.Size(73, 36)
        Me.rbEntregarNO.TabIndex = 1
        Me.rbEntregarNO.TabStop = True
        Me.rbEntregarNO.Text = "NO"
        Me.rbEntregarNO.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        Me.rbEntregarNO.UseVisualStyleBackColor = False
        '
        'txtEmpEntregar
        '
        Me.txtEmpEntregar.AcceptsReturn = True
        Me.txtEmpEntregar.AcceptsTab = True
        Me.txtEmpEntregar.Font = New System.Drawing.Font("Microsoft Sans Serif", 15.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.txtEmpEntregar.ForeColor = System.Drawing.SystemColors.GrayText
        Me.txtEmpEntregar.Location = New System.Drawing.Point(158, 3)
        Me.txtEmpEntregar.Name = "txtEmpEntregar"
        Me.txtEmpEntregar.Size = New System.Drawing.Size(201, 31)
        Me.txtEmpEntregar.TabIndex = 85
        Me.txtEmpEntregar.Text = "Empleado"
        '
        'txtFechaEntregar
        '
        Me.txtFechaEntregar.AcceptsReturn = True
        Me.txtFechaEntregar.AcceptsTab = True
        Me.txtFechaEntregar.Font = New System.Drawing.Font("Microsoft Sans Serif", 15.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.txtFechaEntregar.ForeColor = System.Drawing.SystemColors.GrayText
        Me.txtFechaEntregar.Location = New System.Drawing.Point(365, 3)
        Me.txtFechaEntregar.Name = "txtFechaEntregar"
        Me.txtFechaEntregar.Size = New System.Drawing.Size(201, 31)
        Me.txtFechaEntregar.TabIndex = 85
        Me.txtFechaEntregar.Text = "Fecha"
        '
        'GroupBox14
        '
        Me.GroupBox14.Anchor = System.Windows.Forms.AnchorStyles.None
        Me.GroupBox14.Controls.Add(Me.FlowLayoutPanel14)
        Me.GroupBox14.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.GroupBox14.ForeColor = System.Drawing.Color.Black
        Me.GroupBox14.Location = New System.Drawing.Point(725, 642)
        Me.GroupBox14.Name = "GroupBox14"
        Me.GroupBox14.Size = New System.Drawing.Size(599, 69)
        Me.GroupBox14.TabIndex = 84
        Me.GroupBox14.TabStop = False
        Me.GroupBox14.Text = "ENVIO A ALMACEN"
        '
        'FlowLayoutPanel14
        '
        Me.FlowLayoutPanel14.AutoScroll = True
        Me.FlowLayoutPanel14.Controls.Add(Me.rbEnvioSI)
        Me.FlowLayoutPanel14.Controls.Add(Me.rbEnvioNO)
        Me.FlowLayoutPanel14.Controls.Add(Me.txtEmpEnvio)
        Me.FlowLayoutPanel14.Controls.Add(Me.txtFechaEnvio)
        Me.FlowLayoutPanel14.Dock = System.Windows.Forms.DockStyle.Fill
        Me.FlowLayoutPanel14.Location = New System.Drawing.Point(3, 22)
        Me.FlowLayoutPanel14.Name = "FlowLayoutPanel14"
        Me.FlowLayoutPanel14.Size = New System.Drawing.Size(593, 44)
        Me.FlowLayoutPanel14.TabIndex = 0
        '
        'rbEnvioSI
        '
        Me.rbEnvioSI.Appearance = System.Windows.Forms.Appearance.Button
        Me.rbEnvioSI.BackColor = System.Drawing.Color.White
        Me.rbEnvioSI.FlatAppearance.CheckedBackColor = System.Drawing.Color.Lime
        Me.rbEnvioSI.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.rbEnvioSI.Font = New System.Drawing.Font("Microsoft Sans Serif", 14.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.rbEnvioSI.ForeColor = System.Drawing.Color.FromArgb(CType(CType(41, Byte), Integer), CType(CType(121, Byte), Integer), CType(CType(255, Byte), Integer))
        Me.rbEnvioSI.Location = New System.Drawing.Point(3, 3)
        Me.rbEnvioSI.Name = "rbEnvioSI"
        Me.rbEnvioSI.Size = New System.Drawing.Size(70, 36)
        Me.rbEnvioSI.TabIndex = 0
        Me.rbEnvioSI.TabStop = True
        Me.rbEnvioSI.Text = "SI"
        Me.rbEnvioSI.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        Me.rbEnvioSI.UseVisualStyleBackColor = False
        '
        'rbEnvioNO
        '
        Me.rbEnvioNO.Appearance = System.Windows.Forms.Appearance.Button
        Me.rbEnvioNO.BackColor = System.Drawing.Color.White
        Me.rbEnvioNO.FlatAppearance.CheckedBackColor = System.Drawing.Color.Lime
        Me.rbEnvioNO.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.rbEnvioNO.Font = New System.Drawing.Font("Microsoft Sans Serif", 14.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.rbEnvioNO.ForeColor = System.Drawing.Color.FromArgb(CType(CType(41, Byte), Integer), CType(CType(121, Byte), Integer), CType(CType(255, Byte), Integer))
        Me.rbEnvioNO.Location = New System.Drawing.Point(79, 3)
        Me.rbEnvioNO.Name = "rbEnvioNO"
        Me.rbEnvioNO.Size = New System.Drawing.Size(73, 36)
        Me.rbEnvioNO.TabIndex = 1
        Me.rbEnvioNO.TabStop = True
        Me.rbEnvioNO.Text = "NO"
        Me.rbEnvioNO.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        Me.rbEnvioNO.UseVisualStyleBackColor = False
        '
        'txtEmpEnvio
        '
        Me.txtEmpEnvio.AcceptsReturn = True
        Me.txtEmpEnvio.AcceptsTab = True
        Me.txtEmpEnvio.Font = New System.Drawing.Font("Microsoft Sans Serif", 15.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.txtEmpEnvio.ForeColor = System.Drawing.SystemColors.GrayText
        Me.txtEmpEnvio.Location = New System.Drawing.Point(158, 3)
        Me.txtEmpEnvio.Name = "txtEmpEnvio"
        Me.txtEmpEnvio.Size = New System.Drawing.Size(201, 31)
        Me.txtEmpEnvio.TabIndex = 85
        Me.txtEmpEnvio.Text = "Empleado"
        '
        'txtFechaEnvio
        '
        Me.txtFechaEnvio.AcceptsReturn = True
        Me.txtFechaEnvio.AcceptsTab = True
        Me.txtFechaEnvio.Font = New System.Drawing.Font("Microsoft Sans Serif", 15.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.txtFechaEnvio.ForeColor = System.Drawing.SystemColors.GrayText
        Me.txtFechaEnvio.Location = New System.Drawing.Point(365, 3)
        Me.txtFechaEnvio.Name = "txtFechaEnvio"
        Me.txtFechaEnvio.Size = New System.Drawing.Size(201, 31)
        Me.txtFechaEnvio.TabIndex = 85
        Me.txtFechaEnvio.Text = "Fecha"
        '
        'Label6
        '
        Me.Label6.Font = New System.Drawing.Font("Microsoft Sans Serif", 15.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label6.Location = New System.Drawing.Point(8, 144)
        Me.Label6.Name = "Label6"
        Me.Label6.Size = New System.Drawing.Size(265, 26)
        Me.Label6.TabIndex = 86
        Me.Label6.Text = "TOOLING:"
        '
        'lblID
        '
        Me.lblID.Font = New System.Drawing.Font("Microsoft Sans Serif", 15.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblID.Location = New System.Drawing.Point(7, 2)
        Me.lblID.Name = "lblID"
        Me.lblID.Size = New System.Drawing.Size(239, 28)
        Me.lblID.TabIndex = 86
        Me.lblID.Text = "ID"
        '
        'txtColor
        '
        Me.txtColor.AcceptsReturn = True
        Me.txtColor.AcceptsTab = True
        Me.txtColor.Font = New System.Drawing.Font("Microsoft Sans Serif", 15.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.txtColor.Location = New System.Drawing.Point(278, 63)
        Me.txtColor.Name = "txtColor"
        Me.txtColor.Size = New System.Drawing.Size(270, 31)
        Me.txtColor.TabIndex = 88
        '
        'txtIdArmar
        '
        Me.txtIdArmar.AcceptsReturn = True
        Me.txtIdArmar.AcceptsTab = True
        Me.txtIdArmar.Font = New System.Drawing.Font("Microsoft Sans Serif", 15.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.txtIdArmar.Location = New System.Drawing.Point(278, 100)
        Me.txtIdArmar.Name = "txtIdArmar"
        Me.txtIdArmar.Size = New System.Drawing.Size(270, 31)
        Me.txtIdArmar.TabIndex = 89
        '
        'txtTooling
        '
        Me.txtTooling.AcceptsReturn = True
        Me.txtTooling.AcceptsTab = True
        Me.txtTooling.Font = New System.Drawing.Font("Microsoft Sans Serif", 15.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.txtTooling.Location = New System.Drawing.Point(278, 137)
        Me.txtTooling.Name = "txtTooling"
        Me.txtTooling.Size = New System.Drawing.Size(270, 31)
        Me.txtTooling.TabIndex = 90
        '
        'txtIdAnterior
        '
        Me.txtIdAnterior.AcceptsReturn = True
        Me.txtIdAnterior.AcceptsTab = True
        Me.txtIdAnterior.Font = New System.Drawing.Font("Microsoft Sans Serif", 15.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.txtIdAnterior.Location = New System.Drawing.Point(278, 177)
        Me.txtIdAnterior.Name = "txtIdAnterior"
        Me.txtIdAnterior.Size = New System.Drawing.Size(270, 31)
        Me.txtIdAnterior.TabIndex = 90
        '
        'txtDiametro
        '
        Me.txtDiametro.AcceptsReturn = True
        Me.txtDiametro.AcceptsTab = True
        Me.txtDiametro.Font = New System.Drawing.Font("Microsoft Sans Serif", 15.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.txtDiametro.Location = New System.Drawing.Point(1039, 108)
        Me.txtDiametro.Name = "txtDiametro"
        Me.txtDiametro.Size = New System.Drawing.Size(270, 31)
        Me.txtDiametro.TabIndex = 91
        '
        'Form2
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.ClientSize = New System.Drawing.Size(1324, 741)
        Me.Controls.Add(Me.txtDiametro)
        Me.Controls.Add(Me.txtIdAnterior)
        Me.Controls.Add(Me.txtTooling)
        Me.Controls.Add(Me.txtIdArmar)
        Me.Controls.Add(Me.txtColor)
        Me.Controls.Add(Me.GroupBox9)
        Me.Controls.Add(Me.txtVale)
        Me.Controls.Add(Me.txtCantGrommet)
        Me.Controls.Add(Me.txtCantPlat)
        Me.Controls.Add(Me.txtNpart)
        Me.Controls.Add(Me.Label24)
        Me.Controls.Add(Me.Label4)
        Me.Controls.Add(Me.Label5)
        Me.Controls.Add(Me.Label18)
        Me.Controls.Add(Me.Label6)
        Me.Controls.Add(Me.Label3)
        Me.Controls.Add(Me.Label2)
        Me.Controls.Add(Me.Label1)
        Me.Controls.Add(Me.lblID)
        Me.Controls.Add(Me.Label23)
        Me.Controls.Add(Me.GroupBox1)
        Me.Controls.Add(Me.GroupBox2)
        Me.Controls.Add(Me.GroupBox14)
        Me.Controls.Add(Me.GroupBox13)
        Me.Controls.Add(Me.GroupBox12)
        Me.Controls.Add(Me.GroupBox11)
        Me.Controls.Add(Me.GroupBox10)
        Me.Controls.Add(Me.GroupBox8)
        Me.Controls.Add(Me.GroupBox7)
        Me.Controls.Add(Me.GroupBox6)
        Me.Controls.Add(Me.GroupBox5)
        Me.Controls.Add(Me.GroupBox4)
        Me.Controls.Add(Me.GroupBox3)
        Me.Controls.Add(Me.groupBox26)
        Me.Controls.Add(Me.Label19)
        Me.Name = "Form2"
        Me.Text = "Form2"
        Me.groupBox26.ResumeLayout(False)
        Me.flowLayoutPanel23.ResumeLayout(False)
        Me.flowLayoutPanel23.PerformLayout()
        Me.GroupBox1.ResumeLayout(False)
        Me.FlowLayoutPanel1.ResumeLayout(False)
        Me.FlowLayoutPanel1.PerformLayout()
        Me.GroupBox2.ResumeLayout(False)
        Me.FlowLayoutPanel2.ResumeLayout(False)
        Me.GroupBox3.ResumeLayout(False)
        Me.FlowLayoutPanel3.ResumeLayout(False)
        Me.FlowLayoutPanel3.PerformLayout()
        Me.GroupBox4.ResumeLayout(False)
        Me.FlowLayoutPanel4.ResumeLayout(False)
        Me.FlowLayoutPanel4.PerformLayout()
        Me.GroupBox5.ResumeLayout(False)
        Me.FlowLayoutPanel5.ResumeLayout(False)
        Me.FlowLayoutPanel5.PerformLayout()
        Me.GroupBox6.ResumeLayout(False)
        Me.FlowLayoutPanel6.ResumeLayout(False)
        Me.FlowLayoutPanel6.PerformLayout()
        Me.GroupBox7.ResumeLayout(False)
        Me.FlowLayoutPanel7.ResumeLayout(False)
        Me.FlowLayoutPanel7.PerformLayout()
        Me.GroupBox8.ResumeLayout(False)
        Me.FlowLayoutPanel8.ResumeLayout(False)
        Me.FlowLayoutPanel8.PerformLayout()
        Me.GroupBox9.ResumeLayout(False)
        Me.FlowLayoutPanel9.ResumeLayout(False)
        Me.FlowLayoutPanel9.PerformLayout()
        Me.GroupBox10.ResumeLayout(False)
        Me.FlowLayoutPanel10.ResumeLayout(False)
        Me.FlowLayoutPanel10.PerformLayout()
        Me.GroupBox11.ResumeLayout(False)
        Me.FlowLayoutPanel11.ResumeLayout(False)
        Me.FlowLayoutPanel11.PerformLayout()
        Me.GroupBox12.ResumeLayout(False)
        Me.FlowLayoutPanel12.ResumeLayout(False)
        Me.FlowLayoutPanel12.PerformLayout()
        Me.GroupBox13.ResumeLayout(False)
        Me.FlowLayoutPanel13.ResumeLayout(False)
        Me.FlowLayoutPanel13.PerformLayout()
        Me.GroupBox14.ResumeLayout(False)
        Me.FlowLayoutPanel14.ResumeLayout(False)
        Me.FlowLayoutPanel14.PerformLayout()
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub

    Friend WithEvents Label19 As Label
    Private WithEvents groupBox26 As GroupBox
    Private WithEvents flowLayoutPanel23 As FlowLayoutPanel
    Private WithEvents rbSinGolpesSI As RadioButton
    Private WithEvents rbSinGolpesNO As RadioButton
    Friend WithEvents Label23 As Label
    Friend WithEvents txtEmpSinGolpes As TextBox
    Friend WithEvents txtFechaSinGolpes As TextBox
    Friend WithEvents Label1 As Label
    Friend WithEvents Label24 As Label
    Friend WithEvents Label18 As Label
    Friend WithEvents txtCantPlat As TextBox
    Friend WithEvents Label5 As Label
    Friend WithEvents txtCantGrommet As TextBox
    Private WithEvents GroupBox1 As GroupBox
    Private WithEvents FlowLayoutPanel1 As FlowLayoutPanel
    Private WithEvents rbRevGaugeBuenos As RadioButton
    Private WithEvents rbRevGaugeMalos As RadioButton
    Friend WithEvents txtFechaRevGauge As TextBox
    Friend WithEvents txtEmpRevGauge As TextBox
    Friend WithEvents Label2 As Label
    Private WithEvents GroupBox2 As GroupBox
    Private WithEvents FlowLayoutPanel2 As FlowLayoutPanel
    Private WithEvents rbNuevo As RadioButton
    Private WithEvents rbReac As RadioButton
    Private WithEvents rbNA As RadioButton
    Friend WithEvents Label3 As Label
    Private WithEvents GroupBox3 As GroupBox
    Private WithEvents FlowLayoutPanel3 As FlowLayoutPanel
    Private WithEvents rbtxtArmaSetSI As RadioButton
    Private WithEvents rbtxtArmaSetNO As RadioButton
    Friend WithEvents txtEmpArmaSet As TextBox
    Friend WithEvents txtFechaArmaSet As TextBox
    Private WithEvents GroupBox4 As GroupBox
    Private WithEvents FlowLayoutPanel4 As FlowLayoutPanel
    Private WithEvents rbTalquearSI As RadioButton
    Private WithEvents rbTalquearNO As RadioButton
    Friend WithEvents txtEmpTalquear As TextBox
    Friend WithEvents txtFechaTalquear As TextBox
    Private WithEvents GroupBox5 As GroupBox
    Private WithEvents FlowLayoutPanel5 As FlowLayoutPanel
    Private WithEvents rbPrensarSI As RadioButton
    Private WithEvents rbPrensarNO As RadioButton
    Friend WithEvents txtEmpPrensar As TextBox
    Friend WithEvents txtFechaPrensar As TextBox
    Private WithEvents GroupBox6 As GroupBox
    Private WithEvents FlowLayoutPanel6 As FlowLayoutPanel
    Private WithEvents rbSopletearSI As RadioButton
    Private WithEvents rbSopletearNO As RadioButton
    Friend WithEvents txtEmpSopletear As TextBox
    Friend WithEvents txtFechaSopletear As TextBox
    Private WithEvents GroupBox7 As GroupBox
    Private WithEvents FlowLayoutPanel7 As FlowLayoutPanel
    Private WithEvents rbPintarSI As RadioButton
    Private WithEvents rbPintarNO As RadioButton
    Friend WithEvents txtEmpPintar As TextBox
    Friend WithEvents txtFechaPintar As TextBox
    Private WithEvents GroupBox8 As GroupBox
    Private WithEvents FlowLayoutPanel8 As FlowLayoutPanel
    Private WithEvents tbCurarSI As RadioButton
    Private WithEvents rbCurarNO As RadioButton
    Friend WithEvents txtEmpCurar As TextBox
    Friend WithEvents txtFechaCurar As TextBox
    Private WithEvents GroupBox9 As GroupBox
    Private WithEvents FlowLayoutPanel9 As FlowLayoutPanel
    Private WithEvents rbRetAntSI As RadioButton
    Private WithEvents rbRetAntNO As RadioButton
    Friend WithEvents txtEmpRetAnt As TextBox
    Friend WithEvents txtFechaRetAnt As TextBox
    Friend WithEvents Label4 As Label
    Friend WithEvents txtVale As TextBox
    Private WithEvents GroupBox10 As GroupBox
    Private WithEvents FlowLayoutPanel10 As FlowLayoutPanel
    Private WithEvents rbDesarmadoNO As RadioButton
    Friend WithEvents txtEmpDesarmado As TextBox
    Friend WithEvents txtFechaDesarmado As TextBox
    Private WithEvents GroupBox11 As GroupBox
    Private WithEvents FlowLayoutPanel11 As FlowLayoutPanel
    Private WithEvents rbDBSI As RadioButton
    Private WithEvents rbDBNO As RadioButton
    Friend WithEvents txtEmpAltaDB As TextBox
    Friend WithEvents txtFechaAltaDB As TextBox
    Private WithEvents GroupBox12 As GroupBox
    Private WithEvents FlowLayoutPanel12 As FlowLayoutPanel
    Private WithEvents rbRevTecSI As RadioButton
    Private WithEvents rbRevTecNO As RadioButton
    Friend WithEvents txtEmpRevTec As TextBox
    Friend WithEvents txtFechaRevTec As TextBox
    Private WithEvents GroupBox13 As GroupBox
    Private WithEvents FlowLayoutPanel13 As FlowLayoutPanel
    Private WithEvents rbEntregarSI As RadioButton
    Private WithEvents rbEntregarNO As RadioButton
    Friend WithEvents txtEmpEntregar As TextBox
    Friend WithEvents txtFechaEntregar As TextBox
    Private WithEvents GroupBox14 As GroupBox
    Private WithEvents FlowLayoutPanel14 As FlowLayoutPanel
    Private WithEvents rbEnvioSI As RadioButton
    Private WithEvents rbEnvioNO As RadioButton
    Friend WithEvents txtEmpEnvio As TextBox
    Friend WithEvents txtFechaEnvio As TextBox
    Friend WithEvents Label6 As Label
    Public WithEvents txtNpart As TextBox
    Friend WithEvents lblID As Label
    Private WithEvents rbDesarmadoSI As RadioButton
    Public WithEvents txtColor As TextBox
    Public WithEvents txtIdArmar As TextBox
    Public WithEvents txtTooling As TextBox
    Public WithEvents txtIdAnterior As TextBox
    Friend WithEvents txtDiametro As TextBox
End Class
