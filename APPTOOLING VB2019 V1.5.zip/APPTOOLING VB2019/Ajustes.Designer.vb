﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class Ajustes
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Dim resources As System.ComponentModel.ComponentResourceManager = New System.ComponentModel.ComponentResourceManager(GetType(Ajustes))
        Me.tabAjustes = New System.Windows.Forms.TabControl()
        Me.tabTecnicos = New System.Windows.Forms.TabPage()
        Me.lblEmail = New System.Windows.Forms.Label()
        Me.Permisos = New System.Windows.Forms.GroupBox()
        Me.rbAdministrador = New System.Windows.Forms.RadioButton()
        Me.rbTecnico = New System.Windows.Forms.RadioButton()
        Me.GroupBox1 = New System.Windows.Forms.GroupBox()
        Me.rbEmailSi = New System.Windows.Forms.RadioButton()
        Me.rbEmailNo = New System.Windows.Forms.RadioButton()
        Me.txtEmail = New System.Windows.Forms.TextBox()
        Me.txtApellido = New System.Windows.Forms.TextBox()
        Me.Label18 = New System.Windows.Forms.Label()
        Me.btnRegistrar = New System.Windows.Forms.Button()
        Me.btnCancelar = New System.Windows.Forms.Button()
        Me.lblAlta = New System.Windows.Forms.Label()
        Me.txtNumero = New System.Windows.Forms.TextBox()
        Me.Empleado = New System.Windows.Forms.Label()
        Me.txtNombre = New System.Windows.Forms.TextBox()
        Me.Nombre = New System.Windows.Forms.Label()
        Me.tabTooling = New System.Windows.Forms.TabPage()
        Me.txtVida = New System.Windows.Forms.TextBox()
        Me.Label20 = New System.Windows.Forms.Label()
        Me.btnAlta = New System.Windows.Forms.Button()
        Me.txtID = New System.Windows.Forms.TextBox()
        Me.cmbDesc = New System.Windows.Forms.ComboBox()
        Me.txtTipoT = New System.Windows.Forms.TextBox()
        Me.Label5 = New System.Windows.Forms.Label()
        Me.Label4 = New System.Windows.Forms.Label()
        Me.Label3 = New System.Windows.Forms.Label()
        Me.Label2 = New System.Windows.Forms.Label()
        Me.Label1 = New System.Windows.Forms.Label()
        Me.tabDeshabilitar = New System.Windows.Forms.TabPage()
        Me.btnCreateFiles = New System.Windows.Forms.Button()
        Me.btnCerrar = New System.Windows.Forms.Button()
        Me.Label15 = New System.Windows.Forms.Label()
        Me.L11E = New System.Windows.Forms.Button()
        Me.L11V = New System.Windows.Forms.Button()
        Me.L10E = New System.Windows.Forms.Button()
        Me.Label17 = New System.Windows.Forms.Label()
        Me.L10V = New System.Windows.Forms.Button()
        Me.L11A = New System.Windows.Forms.Button()
        Me.Label11 = New System.Windows.Forms.Label()
        Me.L10A = New System.Windows.Forms.Button()
        Me.L09E = New System.Windows.Forms.Button()
        Me.L09V = New System.Windows.Forms.Button()
        Me.Label12 = New System.Windows.Forms.Label()
        Me.L09A = New System.Windows.Forms.Button()
        Me.L08E = New System.Windows.Forms.Button()
        Me.L08V = New System.Windows.Forms.Button()
        Me.Label13 = New System.Windows.Forms.Label()
        Me.L08A = New System.Windows.Forms.Button()
        Me.L07E = New System.Windows.Forms.Button()
        Me.L07V = New System.Windows.Forms.Button()
        Me.Label14 = New System.Windows.Forms.Label()
        Me.L07A = New System.Windows.Forms.Button()
        Me.L06E = New System.Windows.Forms.Button()
        Me.L06V = New System.Windows.Forms.Button()
        Me.Label16 = New System.Windows.Forms.Label()
        Me.L06A = New System.Windows.Forms.Button()
        Me.L05E = New System.Windows.Forms.Button()
        Me.L05V = New System.Windows.Forms.Button()
        Me.Label10 = New System.Windows.Forms.Label()
        Me.L05A = New System.Windows.Forms.Button()
        Me.L04E = New System.Windows.Forms.Button()
        Me.L04V = New System.Windows.Forms.Button()
        Me.Label9 = New System.Windows.Forms.Label()
        Me.L04A = New System.Windows.Forms.Button()
        Me.L03E = New System.Windows.Forms.Button()
        Me.L03V = New System.Windows.Forms.Button()
        Me.Label8 = New System.Windows.Forms.Label()
        Me.L03A = New System.Windows.Forms.Button()
        Me.L02E = New System.Windows.Forms.Button()
        Me.L02V = New System.Windows.Forms.Button()
        Me.Label7 = New System.Windows.Forms.Label()
        Me.L02A = New System.Windows.Forms.Button()
        Me.L01E = New System.Windows.Forms.Button()
        Me.L01V = New System.Windows.Forms.Button()
        Me.Line1 = New System.Windows.Forms.Label()
        Me.L01A = New System.Windows.Forms.Button()
        Me.bntLineaPM = New System.Windows.Forms.Button()
        Me.btnHabilita = New System.Windows.Forms.Button()
        Me.btnLineDis = New System.Windows.Forms.Button()
        Me.txtLineDis = New System.Windows.Forms.TextBox()
        Me.Label6 = New System.Windows.Forms.Label()
        Me.tabReporte = New System.Windows.Forms.TabPage()
        Me.btnEnvReport = New System.Windows.Forms.Button()
        Me.txtPrivilegios = New System.Windows.Forms.Label()
        Me.txtNumEm = New System.Windows.Forms.Label()
        Me.txtNom = New System.Windows.Forms.Label()
        Me.L13A = New System.Windows.Forms.Button()
        Me.Label19 = New System.Windows.Forms.Label()
        Me.L13V = New System.Windows.Forms.Button()
        Me.L13E = New System.Windows.Forms.Button()
        Me.tabAjustes.SuspendLayout()
        Me.tabTecnicos.SuspendLayout()
        Me.Permisos.SuspendLayout()
        Me.GroupBox1.SuspendLayout()
        Me.tabTooling.SuspendLayout()
        Me.tabDeshabilitar.SuspendLayout()
        Me.tabReporte.SuspendLayout()
        Me.SuspendLayout()
        '
        'tabAjustes
        '
        Me.tabAjustes.Controls.Add(Me.tabTecnicos)
        Me.tabAjustes.Controls.Add(Me.tabTooling)
        Me.tabAjustes.Controls.Add(Me.tabDeshabilitar)
        Me.tabAjustes.Controls.Add(Me.tabReporte)
        Me.tabAjustes.Location = New System.Drawing.Point(12, 12)
        Me.tabAjustes.Name = "tabAjustes"
        Me.tabAjustes.SelectedIndex = 0
        Me.tabAjustes.Size = New System.Drawing.Size(492, 437)
        Me.tabAjustes.TabIndex = 0
        '
        'tabTecnicos
        '
        Me.tabTecnicos.Controls.Add(Me.lblEmail)
        Me.tabTecnicos.Controls.Add(Me.Permisos)
        Me.tabTecnicos.Controls.Add(Me.GroupBox1)
        Me.tabTecnicos.Controls.Add(Me.txtEmail)
        Me.tabTecnicos.Controls.Add(Me.txtApellido)
        Me.tabTecnicos.Controls.Add(Me.Label18)
        Me.tabTecnicos.Controls.Add(Me.btnRegistrar)
        Me.tabTecnicos.Controls.Add(Me.btnCancelar)
        Me.tabTecnicos.Controls.Add(Me.lblAlta)
        Me.tabTecnicos.Controls.Add(Me.txtNumero)
        Me.tabTecnicos.Controls.Add(Me.Empleado)
        Me.tabTecnicos.Controls.Add(Me.txtNombre)
        Me.tabTecnicos.Controls.Add(Me.Nombre)
        Me.tabTecnicos.Location = New System.Drawing.Point(4, 22)
        Me.tabTecnicos.Name = "tabTecnicos"
        Me.tabTecnicos.Padding = New System.Windows.Forms.Padding(3)
        Me.tabTecnicos.Size = New System.Drawing.Size(484, 411)
        Me.tabTecnicos.TabIndex = 0
        Me.tabTecnicos.Text = "Tecnicos"
        Me.tabTecnicos.UseVisualStyleBackColor = True
        '
        'lblEmail
        '
        Me.lblEmail.AutoSize = True
        Me.lblEmail.Location = New System.Drawing.Point(106, 232)
        Me.lblEmail.Name = "lblEmail"
        Me.lblEmail.Size = New System.Drawing.Size(35, 13)
        Me.lblEmail.TabIndex = 29
        Me.lblEmail.Text = "eMail:"
        Me.lblEmail.Visible = False
        '
        'Permisos
        '
        Me.Permisos.Controls.Add(Me.rbAdministrador)
        Me.Permisos.Controls.Add(Me.rbTecnico)
        Me.Permisos.Location = New System.Drawing.Point(102, 251)
        Me.Permisos.Name = "Permisos"
        Me.Permisos.Size = New System.Drawing.Size(216, 56)
        Me.Permisos.TabIndex = 28
        Me.Permisos.TabStop = False
        Me.Permisos.Text = "Permisos"
        '
        'rbAdministrador
        '
        Me.rbAdministrador.AutoSize = True
        Me.rbAdministrador.Location = New System.Drawing.Point(122, 19)
        Me.rbAdministrador.Name = "rbAdministrador"
        Me.rbAdministrador.Size = New System.Drawing.Size(88, 17)
        Me.rbAdministrador.TabIndex = 1
        Me.rbAdministrador.Text = "Administrador"
        Me.rbAdministrador.UseVisualStyleBackColor = True
        '
        'rbTecnico
        '
        Me.rbTecnico.AutoSize = True
        Me.rbTecnico.Checked = True
        Me.rbTecnico.Location = New System.Drawing.Point(7, 19)
        Me.rbTecnico.Name = "rbTecnico"
        Me.rbTecnico.Size = New System.Drawing.Size(64, 17)
        Me.rbTecnico.TabIndex = 0
        Me.rbTecnico.TabStop = True
        Me.rbTecnico.Text = "Tecnico"
        Me.rbTecnico.UseVisualStyleBackColor = True
        '
        'GroupBox1
        '
        Me.GroupBox1.Controls.Add(Me.rbEmailSi)
        Me.GroupBox1.Controls.Add(Me.rbEmailNo)
        Me.GroupBox1.Location = New System.Drawing.Point(102, 173)
        Me.GroupBox1.Name = "GroupBox1"
        Me.GroupBox1.Size = New System.Drawing.Size(215, 46)
        Me.GroupBox1.TabIndex = 27
        Me.GroupBox1.TabStop = False
        Me.GroupBox1.Text = "eMail"
        '
        'rbEmailSi
        '
        Me.rbEmailSi.AutoSize = True
        Me.rbEmailSi.Location = New System.Drawing.Point(122, 19)
        Me.rbEmailSi.Name = "rbEmailSi"
        Me.rbEmailSi.Size = New System.Drawing.Size(71, 17)
        Me.rbEmailSi.TabIndex = 1
        Me.rbEmailSi.Text = "Si Recibe"
        Me.rbEmailSi.UseVisualStyleBackColor = True
        '
        'rbEmailNo
        '
        Me.rbEmailNo.AutoSize = True
        Me.rbEmailNo.Checked = True
        Me.rbEmailNo.Location = New System.Drawing.Point(7, 19)
        Me.rbEmailNo.Name = "rbEmailNo"
        Me.rbEmailNo.Size = New System.Drawing.Size(76, 17)
        Me.rbEmailNo.TabIndex = 0
        Me.rbEmailNo.TabStop = True
        Me.rbEmailNo.Text = "No Recibe"
        Me.rbEmailNo.UseVisualStyleBackColor = True
        '
        'txtEmail
        '
        Me.txtEmail.Location = New System.Drawing.Point(147, 225)
        Me.txtEmail.Name = "txtEmail"
        Me.txtEmail.Size = New System.Drawing.Size(168, 20)
        Me.txtEmail.TabIndex = 4
        Me.txtEmail.Visible = False
        '
        'txtApellido
        '
        Me.txtApellido.Location = New System.Drawing.Point(149, 136)
        Me.txtApellido.Name = "txtApellido"
        Me.txtApellido.Size = New System.Drawing.Size(168, 20)
        Me.txtApellido.TabIndex = 3
        '
        'Label18
        '
        Me.Label18.AutoSize = True
        Me.Label18.Location = New System.Drawing.Point(99, 143)
        Me.Label18.Name = "Label18"
        Me.Label18.Size = New System.Drawing.Size(44, 13)
        Me.Label18.TabIndex = 22
        Me.Label18.Text = "Apellido"
        '
        'btnRegistrar
        '
        Me.btnRegistrar.Location = New System.Drawing.Point(221, 331)
        Me.btnRegistrar.Name = "btnRegistrar"
        Me.btnRegistrar.Size = New System.Drawing.Size(79, 24)
        Me.btnRegistrar.TabIndex = 5
        Me.btnRegistrar.Text = "Registrar"
        Me.btnRegistrar.UseVisualStyleBackColor = True
        '
        'btnCancelar
        '
        Me.btnCancelar.Location = New System.Drawing.Point(106, 331)
        Me.btnCancelar.Name = "btnCancelar"
        Me.btnCancelar.Size = New System.Drawing.Size(79, 24)
        Me.btnCancelar.TabIndex = 15
        Me.btnCancelar.Text = "Cancelar"
        Me.btnCancelar.UseVisualStyleBackColor = True
        '
        'lblAlta
        '
        Me.lblAlta.AutoSize = True
        Me.lblAlta.Location = New System.Drawing.Point(98, 41)
        Me.lblAlta.Name = "lblAlta"
        Me.lblAlta.Size = New System.Drawing.Size(87, 13)
        Me.lblAlta.TabIndex = 18
        Me.lblAlta.Text = "Alta de Tecnicos"
        '
        'txtNumero
        '
        Me.txtNumero.Location = New System.Drawing.Point(149, 65)
        Me.txtNumero.Name = "txtNumero"
        Me.txtNumero.Size = New System.Drawing.Size(168, 20)
        Me.txtNumero.TabIndex = 1
        '
        'Empleado
        '
        Me.Empleado.AutoSize = True
        Me.Empleado.Location = New System.Drawing.Point(89, 68)
        Me.Empleado.Name = "Empleado"
        Me.Empleado.Size = New System.Drawing.Size(54, 13)
        Me.Empleado.TabIndex = 17
        Me.Empleado.Text = "Empleado"
        '
        'txtNombre
        '
        Me.txtNombre.Location = New System.Drawing.Point(149, 100)
        Me.txtNombre.Name = "txtNombre"
        Me.txtNombre.Size = New System.Drawing.Size(168, 20)
        Me.txtNombre.TabIndex = 2
        '
        'Nombre
        '
        Me.Nombre.AutoSize = True
        Me.Nombre.Location = New System.Drawing.Point(99, 107)
        Me.Nombre.Name = "Nombre"
        Me.Nombre.Size = New System.Drawing.Size(44, 13)
        Me.Nombre.TabIndex = 16
        Me.Nombre.Text = "Nombre"
        '
        'tabTooling
        '
        Me.tabTooling.Controls.Add(Me.txtVida)
        Me.tabTooling.Controls.Add(Me.Label20)
        Me.tabTooling.Controls.Add(Me.btnAlta)
        Me.tabTooling.Controls.Add(Me.txtID)
        Me.tabTooling.Controls.Add(Me.cmbDesc)
        Me.tabTooling.Controls.Add(Me.txtTipoT)
        Me.tabTooling.Controls.Add(Me.Label5)
        Me.tabTooling.Controls.Add(Me.Label4)
        Me.tabTooling.Controls.Add(Me.Label3)
        Me.tabTooling.Controls.Add(Me.Label2)
        Me.tabTooling.Controls.Add(Me.Label1)
        Me.tabTooling.Location = New System.Drawing.Point(4, 22)
        Me.tabTooling.Name = "tabTooling"
        Me.tabTooling.Padding = New System.Windows.Forms.Padding(3)
        Me.tabTooling.Size = New System.Drawing.Size(484, 411)
        Me.tabTooling.TabIndex = 1
        Me.tabTooling.Text = "Tooling"
        Me.tabTooling.UseVisualStyleBackColor = True
        '
        'txtVida
        '
        Me.txtVida.Location = New System.Drawing.Point(153, 200)
        Me.txtVida.Name = "txtVida"
        Me.txtVida.Size = New System.Drawing.Size(133, 20)
        Me.txtVida.TabIndex = 20
        '
        'Label20
        '
        Me.Label20.AutoSize = True
        Me.Label20.Location = New System.Drawing.Point(81, 203)
        Me.Label20.Name = "Label20"
        Me.Label20.Size = New System.Drawing.Size(46, 13)
        Me.Label20.TabIndex = 19
        Me.Label20.Text = "Vida Util"
        '
        'btnAlta
        '
        Me.btnAlta.Location = New System.Drawing.Point(178, 238)
        Me.btnAlta.Name = "btnAlta"
        Me.btnAlta.Size = New System.Drawing.Size(75, 23)
        Me.btnAlta.TabIndex = 18
        Me.btnAlta.Text = "Aceptar"
        Me.btnAlta.UseVisualStyleBackColor = True
        '
        'txtID
        '
        Me.txtID.Location = New System.Drawing.Point(153, 122)
        Me.txtID.Name = "txtID"
        Me.txtID.Size = New System.Drawing.Size(133, 20)
        Me.txtID.TabIndex = 17
        '
        'cmbDesc
        '
        Me.cmbDesc.FormattingEnabled = True
        Me.cmbDesc.Items.AddRange(New Object() {"PIN PACK", "GRATE PLATE"})
        Me.cmbDesc.Location = New System.Drawing.Point(153, 163)
        Me.cmbDesc.Name = "cmbDesc"
        Me.cmbDesc.Size = New System.Drawing.Size(133, 21)
        Me.cmbDesc.TabIndex = 16
        '
        'txtTipoT
        '
        Me.txtTipoT.Location = New System.Drawing.Point(153, 73)
        Me.txtTipoT.Name = "txtTipoT"
        Me.txtTipoT.Size = New System.Drawing.Size(133, 20)
        Me.txtTipoT.TabIndex = 15
        '
        'Label5
        '
        Me.Label5.AutoSize = True
        Me.Label5.Location = New System.Drawing.Point(66, 214)
        Me.Label5.Name = "Label5"
        Me.Label5.Size = New System.Drawing.Size(0, 13)
        Me.Label5.TabIndex = 14
        '
        'Label4
        '
        Me.Label4.AutoSize = True
        Me.Label4.Location = New System.Drawing.Point(81, 166)
        Me.Label4.Name = "Label4"
        Me.Label4.Size = New System.Drawing.Size(63, 13)
        Me.Label4.TabIndex = 13
        Me.Label4.Text = "Descripcion"
        '
        'Label3
        '
        Me.Label3.AutoSize = True
        Me.Label3.Location = New System.Drawing.Point(88, 129)
        Me.Label3.Name = "Label3"
        Me.Label3.Size = New System.Drawing.Size(56, 13)
        Me.Label3.TabIndex = 12
        Me.Label3.Text = "Tooling ID"
        Me.Label3.TextAlign = System.Drawing.ContentAlignment.MiddleRight
        '
        'Label2
        '
        Me.Label2.AutoSize = True
        Me.Label2.Font = New System.Drawing.Font("Microsoft Sans Serif", 15.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label2.Location = New System.Drawing.Point(95, 20)
        Me.Label2.Name = "Label2"
        Me.Label2.Size = New System.Drawing.Size(232, 25)
        Me.Label2.TabIndex = 11
        Me.Label2.Text = "Alta de nuevos Tooling"
        '
        'Label1
        '
        Me.Label1.AutoSize = True
        Me.Label1.Location = New System.Drawing.Point(66, 80)
        Me.Label1.Name = "Label1"
        Me.Label1.Size = New System.Drawing.Size(81, 13)
        Me.Label1.TabIndex = 10
        Me.Label1.Text = "Tipo de Tooling"
        '
        'tabDeshabilitar
        '
        Me.tabDeshabilitar.Controls.Add(Me.btnCreateFiles)
        Me.tabDeshabilitar.Controls.Add(Me.btnCerrar)
        Me.tabDeshabilitar.Controls.Add(Me.Label15)
        Me.tabDeshabilitar.Controls.Add(Me.L13E)
        Me.tabDeshabilitar.Controls.Add(Me.L13V)
        Me.tabDeshabilitar.Controls.Add(Me.L11E)
        Me.tabDeshabilitar.Controls.Add(Me.L11V)
        Me.tabDeshabilitar.Controls.Add(Me.Label19)
        Me.tabDeshabilitar.Controls.Add(Me.L10E)
        Me.tabDeshabilitar.Controls.Add(Me.Label17)
        Me.tabDeshabilitar.Controls.Add(Me.L13A)
        Me.tabDeshabilitar.Controls.Add(Me.L10V)
        Me.tabDeshabilitar.Controls.Add(Me.L11A)
        Me.tabDeshabilitar.Controls.Add(Me.Label11)
        Me.tabDeshabilitar.Controls.Add(Me.L10A)
        Me.tabDeshabilitar.Controls.Add(Me.L09E)
        Me.tabDeshabilitar.Controls.Add(Me.L09V)
        Me.tabDeshabilitar.Controls.Add(Me.Label12)
        Me.tabDeshabilitar.Controls.Add(Me.L09A)
        Me.tabDeshabilitar.Controls.Add(Me.L08E)
        Me.tabDeshabilitar.Controls.Add(Me.L08V)
        Me.tabDeshabilitar.Controls.Add(Me.Label13)
        Me.tabDeshabilitar.Controls.Add(Me.L08A)
        Me.tabDeshabilitar.Controls.Add(Me.L07E)
        Me.tabDeshabilitar.Controls.Add(Me.L07V)
        Me.tabDeshabilitar.Controls.Add(Me.Label14)
        Me.tabDeshabilitar.Controls.Add(Me.L07A)
        Me.tabDeshabilitar.Controls.Add(Me.L06E)
        Me.tabDeshabilitar.Controls.Add(Me.L06V)
        Me.tabDeshabilitar.Controls.Add(Me.Label16)
        Me.tabDeshabilitar.Controls.Add(Me.L06A)
        Me.tabDeshabilitar.Controls.Add(Me.L05E)
        Me.tabDeshabilitar.Controls.Add(Me.L05V)
        Me.tabDeshabilitar.Controls.Add(Me.Label10)
        Me.tabDeshabilitar.Controls.Add(Me.L05A)
        Me.tabDeshabilitar.Controls.Add(Me.L04E)
        Me.tabDeshabilitar.Controls.Add(Me.L04V)
        Me.tabDeshabilitar.Controls.Add(Me.Label9)
        Me.tabDeshabilitar.Controls.Add(Me.L04A)
        Me.tabDeshabilitar.Controls.Add(Me.L03E)
        Me.tabDeshabilitar.Controls.Add(Me.L03V)
        Me.tabDeshabilitar.Controls.Add(Me.Label8)
        Me.tabDeshabilitar.Controls.Add(Me.L03A)
        Me.tabDeshabilitar.Controls.Add(Me.L02E)
        Me.tabDeshabilitar.Controls.Add(Me.L02V)
        Me.tabDeshabilitar.Controls.Add(Me.Label7)
        Me.tabDeshabilitar.Controls.Add(Me.L02A)
        Me.tabDeshabilitar.Controls.Add(Me.L01E)
        Me.tabDeshabilitar.Controls.Add(Me.L01V)
        Me.tabDeshabilitar.Controls.Add(Me.Line1)
        Me.tabDeshabilitar.Controls.Add(Me.L01A)
        Me.tabDeshabilitar.Controls.Add(Me.bntLineaPM)
        Me.tabDeshabilitar.Controls.Add(Me.btnHabilita)
        Me.tabDeshabilitar.Controls.Add(Me.btnLineDis)
        Me.tabDeshabilitar.Controls.Add(Me.txtLineDis)
        Me.tabDeshabilitar.Controls.Add(Me.Label6)
        Me.tabDeshabilitar.Location = New System.Drawing.Point(4, 22)
        Me.tabDeshabilitar.Name = "tabDeshabilitar"
        Me.tabDeshabilitar.Padding = New System.Windows.Forms.Padding(3)
        Me.tabDeshabilitar.Size = New System.Drawing.Size(484, 411)
        Me.tabDeshabilitar.TabIndex = 2
        Me.tabDeshabilitar.Text = "Deshabilitar"
        Me.tabDeshabilitar.UseVisualStyleBackColor = True
        '
        'btnCreateFiles
        '
        Me.btnCreateFiles.Location = New System.Drawing.Point(181, 369)
        Me.btnCreateFiles.Name = "btnCreateFiles"
        Me.btnCreateFiles.Size = New System.Drawing.Size(98, 33)
        Me.btnCreateFiles.TabIndex = 82
        Me.btnCreateFiles.Text = "Crear Archivos"
        Me.btnCreateFiles.UseVisualStyleBackColor = True
        '
        'btnCerrar
        '
        Me.btnCerrar.Location = New System.Drawing.Point(51, 324)
        Me.btnCerrar.Name = "btnCerrar"
        Me.btnCerrar.Size = New System.Drawing.Size(98, 33)
        Me.btnCerrar.TabIndex = 81
        Me.btnCerrar.Text = "Cerrar"
        Me.btnCerrar.UseVisualStyleBackColor = True
        '
        'Label15
        '
        Me.Label15.AutoSize = True
        Me.Label15.Location = New System.Drawing.Point(34, 22)
        Me.Label15.MaximumSize = New System.Drawing.Size(400, 0)
        Me.Label15.Name = "Label15"
        Me.Label15.Size = New System.Drawing.Size(394, 39)
        Me.Label15.TabIndex = 80
        Me.Label15.Text = resources.GetString("Label15.Text")
        Me.Label15.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'L11E
        '
        Me.L11E.BackColor = System.Drawing.Color.Green
        Me.L11E.Font = New System.Drawing.Font("Microsoft Sans Serif", 6.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.L11E.ImeMode = System.Windows.Forms.ImeMode.NoControl
        Me.L11E.Location = New System.Drawing.Point(359, 214)
        Me.L11E.Name = "L11E"
        Me.L11E.Size = New System.Drawing.Size(39, 27)
        Me.L11E.TabIndex = 79
        Me.L11E.Text = "PE11"
        Me.L11E.UseVisualStyleBackColor = False
        '
        'L11V
        '
        Me.L11V.BackColor = System.Drawing.Color.Green
        Me.L11V.Font = New System.Drawing.Font("Microsoft Sans Serif", 6.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.L11V.ImeMode = System.Windows.Forms.ImeMode.NoControl
        Me.L11V.Location = New System.Drawing.Point(314, 214)
        Me.L11V.Name = "L11V"
        Me.L11V.Size = New System.Drawing.Size(39, 27)
        Me.L11V.TabIndex = 78
        Me.L11V.Text = "PV11"
        Me.L11V.UseVisualStyleBackColor = False
        '
        'L10E
        '
        Me.L10E.BackColor = System.Drawing.Color.Green
        Me.L10E.Font = New System.Drawing.Font("Microsoft Sans Serif", 6.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.L10E.ImeMode = System.Windows.Forms.ImeMode.NoControl
        Me.L10E.Location = New System.Drawing.Point(359, 183)
        Me.L10E.Name = "L10E"
        Me.L10E.Size = New System.Drawing.Size(39, 27)
        Me.L10E.TabIndex = 79
        Me.L10E.Text = "PE10"
        Me.L10E.UseVisualStyleBackColor = False
        '
        'Label17
        '
        Me.Label17.AutoSize = True
        Me.Label17.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label17.ImeMode = System.Windows.Forms.ImeMode.NoControl
        Me.Label17.Location = New System.Drawing.Point(242, 222)
        Me.Label17.Name = "Label17"
        Me.Label17.Size = New System.Drawing.Size(28, 15)
        Me.Label17.TabIndex = 77
        Me.Label17.Text = "L11"
        '
        'L10V
        '
        Me.L10V.BackColor = System.Drawing.Color.Green
        Me.L10V.Font = New System.Drawing.Font("Microsoft Sans Serif", 6.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.L10V.ImeMode = System.Windows.Forms.ImeMode.NoControl
        Me.L10V.Location = New System.Drawing.Point(314, 183)
        Me.L10V.Name = "L10V"
        Me.L10V.Size = New System.Drawing.Size(39, 27)
        Me.L10V.TabIndex = 78
        Me.L10V.Text = "PV10"
        Me.L10V.UseVisualStyleBackColor = False
        '
        'L11A
        '
        Me.L11A.BackColor = System.Drawing.Color.Green
        Me.L11A.Font = New System.Drawing.Font("Microsoft Sans Serif", 6.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.L11A.ImeMode = System.Windows.Forms.ImeMode.NoControl
        Me.L11A.Location = New System.Drawing.Point(269, 214)
        Me.L11A.Name = "L11A"
        Me.L11A.Size = New System.Drawing.Size(39, 27)
        Me.L11A.TabIndex = 76
        Me.L11A.Text = "PA11"
        Me.L11A.UseVisualStyleBackColor = False
        '
        'Label11
        '
        Me.Label11.AutoSize = True
        Me.Label11.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label11.ImeMode = System.Windows.Forms.ImeMode.NoControl
        Me.Label11.Location = New System.Drawing.Point(242, 189)
        Me.Label11.Name = "Label11"
        Me.Label11.Size = New System.Drawing.Size(28, 15)
        Me.Label11.TabIndex = 77
        Me.Label11.Text = "L10"
        '
        'L10A
        '
        Me.L10A.BackColor = System.Drawing.Color.Green
        Me.L10A.Font = New System.Drawing.Font("Microsoft Sans Serif", 6.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.L10A.ImeMode = System.Windows.Forms.ImeMode.NoControl
        Me.L10A.Location = New System.Drawing.Point(269, 183)
        Me.L10A.Name = "L10A"
        Me.L10A.Size = New System.Drawing.Size(39, 27)
        Me.L10A.TabIndex = 76
        Me.L10A.Text = "PA10"
        Me.L10A.UseVisualStyleBackColor = False
        '
        'L09E
        '
        Me.L09E.BackColor = System.Drawing.Color.Green
        Me.L09E.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.L09E.ImeMode = System.Windows.Forms.ImeMode.NoControl
        Me.L09E.Location = New System.Drawing.Point(359, 150)
        Me.L09E.Name = "L09E"
        Me.L09E.Size = New System.Drawing.Size(39, 27)
        Me.L09E.TabIndex = 75
        Me.L09E.Text = "PE9"
        Me.L09E.UseVisualStyleBackColor = False
        '
        'L09V
        '
        Me.L09V.BackColor = System.Drawing.Color.Green
        Me.L09V.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.L09V.ImeMode = System.Windows.Forms.ImeMode.NoControl
        Me.L09V.Location = New System.Drawing.Point(314, 150)
        Me.L09V.Name = "L09V"
        Me.L09V.Size = New System.Drawing.Size(39, 27)
        Me.L09V.TabIndex = 74
        Me.L09V.Text = "PV9"
        Me.L09V.UseVisualStyleBackColor = False
        '
        'Label12
        '
        Me.Label12.AutoSize = True
        Me.Label12.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label12.ImeMode = System.Windows.Forms.ImeMode.NoControl
        Me.Label12.Location = New System.Drawing.Point(242, 156)
        Me.Label12.Name = "Label12"
        Me.Label12.Size = New System.Drawing.Size(21, 15)
        Me.Label12.TabIndex = 73
        Me.Label12.Text = "L9"
        '
        'L09A
        '
        Me.L09A.BackColor = System.Drawing.Color.Green
        Me.L09A.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.L09A.ImeMode = System.Windows.Forms.ImeMode.NoControl
        Me.L09A.Location = New System.Drawing.Point(269, 150)
        Me.L09A.Name = "L09A"
        Me.L09A.Size = New System.Drawing.Size(39, 27)
        Me.L09A.TabIndex = 72
        Me.L09A.Text = "PA9"
        Me.L09A.UseVisualStyleBackColor = False
        '
        'L08E
        '
        Me.L08E.BackColor = System.Drawing.Color.Green
        Me.L08E.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.L08E.ImeMode = System.Windows.Forms.ImeMode.NoControl
        Me.L08E.Location = New System.Drawing.Point(359, 117)
        Me.L08E.Name = "L08E"
        Me.L08E.Size = New System.Drawing.Size(39, 27)
        Me.L08E.TabIndex = 71
        Me.L08E.Text = "PE8"
        Me.L08E.UseVisualStyleBackColor = False
        '
        'L08V
        '
        Me.L08V.BackColor = System.Drawing.Color.Green
        Me.L08V.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.L08V.ImeMode = System.Windows.Forms.ImeMode.NoControl
        Me.L08V.Location = New System.Drawing.Point(314, 117)
        Me.L08V.Name = "L08V"
        Me.L08V.Size = New System.Drawing.Size(39, 27)
        Me.L08V.TabIndex = 70
        Me.L08V.Text = "PV8"
        Me.L08V.UseVisualStyleBackColor = False
        '
        'Label13
        '
        Me.Label13.AutoSize = True
        Me.Label13.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label13.ImeMode = System.Windows.Forms.ImeMode.NoControl
        Me.Label13.Location = New System.Drawing.Point(242, 123)
        Me.Label13.Name = "Label13"
        Me.Label13.Size = New System.Drawing.Size(21, 15)
        Me.Label13.TabIndex = 69
        Me.Label13.Text = "L8"
        '
        'L08A
        '
        Me.L08A.BackColor = System.Drawing.Color.Green
        Me.L08A.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.L08A.ImeMode = System.Windows.Forms.ImeMode.NoControl
        Me.L08A.Location = New System.Drawing.Point(269, 117)
        Me.L08A.Name = "L08A"
        Me.L08A.Size = New System.Drawing.Size(39, 27)
        Me.L08A.TabIndex = 68
        Me.L08A.Text = "PA8"
        Me.L08A.UseVisualStyleBackColor = False
        '
        'L07E
        '
        Me.L07E.BackColor = System.Drawing.Color.Green
        Me.L07E.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.L07E.ImeMode = System.Windows.Forms.ImeMode.NoControl
        Me.L07E.Location = New System.Drawing.Point(359, 84)
        Me.L07E.Name = "L07E"
        Me.L07E.Size = New System.Drawing.Size(39, 27)
        Me.L07E.TabIndex = 67
        Me.L07E.Text = "PE7"
        Me.L07E.UseVisualStyleBackColor = False
        '
        'L07V
        '
        Me.L07V.BackColor = System.Drawing.Color.Green
        Me.L07V.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.L07V.ImeMode = System.Windows.Forms.ImeMode.NoControl
        Me.L07V.Location = New System.Drawing.Point(314, 84)
        Me.L07V.Name = "L07V"
        Me.L07V.Size = New System.Drawing.Size(39, 27)
        Me.L07V.TabIndex = 66
        Me.L07V.Text = "PV7"
        Me.L07V.UseVisualStyleBackColor = False
        '
        'Label14
        '
        Me.Label14.AutoSize = True
        Me.Label14.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label14.ImeMode = System.Windows.Forms.ImeMode.NoControl
        Me.Label14.Location = New System.Drawing.Point(242, 90)
        Me.Label14.Name = "Label14"
        Me.Label14.Size = New System.Drawing.Size(21, 15)
        Me.Label14.TabIndex = 65
        Me.Label14.Text = "L7"
        '
        'L07A
        '
        Me.L07A.BackColor = System.Drawing.Color.Green
        Me.L07A.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.L07A.ImeMode = System.Windows.Forms.ImeMode.NoControl
        Me.L07A.Location = New System.Drawing.Point(269, 84)
        Me.L07A.Name = "L07A"
        Me.L07A.Size = New System.Drawing.Size(39, 27)
        Me.L07A.TabIndex = 64
        Me.L07A.Text = "PA7"
        Me.L07A.UseVisualStyleBackColor = False
        '
        'L06E
        '
        Me.L06E.BackColor = System.Drawing.Color.Green
        Me.L06E.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.L06E.ImeMode = System.Windows.Forms.ImeMode.NoControl
        Me.L06E.Location = New System.Drawing.Point(165, 248)
        Me.L06E.Name = "L06E"
        Me.L06E.Size = New System.Drawing.Size(39, 27)
        Me.L06E.TabIndex = 63
        Me.L06E.Text = "PE6"
        Me.L06E.UseVisualStyleBackColor = False
        '
        'L06V
        '
        Me.L06V.BackColor = System.Drawing.Color.Green
        Me.L06V.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.L06V.ImeMode = System.Windows.Forms.ImeMode.NoControl
        Me.L06V.Location = New System.Drawing.Point(120, 248)
        Me.L06V.Name = "L06V"
        Me.L06V.Size = New System.Drawing.Size(39, 27)
        Me.L06V.TabIndex = 62
        Me.L06V.Text = "PV6"
        Me.L06V.UseVisualStyleBackColor = False
        '
        'Label16
        '
        Me.Label16.AutoSize = True
        Me.Label16.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label16.ImeMode = System.Windows.Forms.ImeMode.NoControl
        Me.Label16.Location = New System.Drawing.Point(48, 254)
        Me.Label16.Name = "Label16"
        Me.Label16.Size = New System.Drawing.Size(21, 15)
        Me.Label16.TabIndex = 61
        Me.Label16.Text = "L6"
        '
        'L06A
        '
        Me.L06A.BackColor = System.Drawing.Color.Green
        Me.L06A.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.L06A.ImeMode = System.Windows.Forms.ImeMode.NoControl
        Me.L06A.Location = New System.Drawing.Point(75, 248)
        Me.L06A.Name = "L06A"
        Me.L06A.Size = New System.Drawing.Size(39, 27)
        Me.L06A.TabIndex = 60
        Me.L06A.Text = "PA6"
        Me.L06A.UseVisualStyleBackColor = False
        '
        'L05E
        '
        Me.L05E.BackColor = System.Drawing.Color.Green
        Me.L05E.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.L05E.ImeMode = System.Windows.Forms.ImeMode.NoControl
        Me.L05E.Location = New System.Drawing.Point(165, 215)
        Me.L05E.Name = "L05E"
        Me.L05E.Size = New System.Drawing.Size(39, 27)
        Me.L05E.TabIndex = 59
        Me.L05E.Text = "PE5"
        Me.L05E.UseVisualStyleBackColor = False
        '
        'L05V
        '
        Me.L05V.BackColor = System.Drawing.Color.Green
        Me.L05V.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.L05V.ImeMode = System.Windows.Forms.ImeMode.NoControl
        Me.L05V.Location = New System.Drawing.Point(120, 215)
        Me.L05V.Name = "L05V"
        Me.L05V.Size = New System.Drawing.Size(39, 27)
        Me.L05V.TabIndex = 58
        Me.L05V.Text = "PV5"
        Me.L05V.UseVisualStyleBackColor = False
        '
        'Label10
        '
        Me.Label10.AutoSize = True
        Me.Label10.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label10.ImeMode = System.Windows.Forms.ImeMode.NoControl
        Me.Label10.Location = New System.Drawing.Point(48, 221)
        Me.Label10.Name = "Label10"
        Me.Label10.Size = New System.Drawing.Size(21, 15)
        Me.Label10.TabIndex = 57
        Me.Label10.Text = "L5"
        '
        'L05A
        '
        Me.L05A.BackColor = System.Drawing.Color.Green
        Me.L05A.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.L05A.ImeMode = System.Windows.Forms.ImeMode.NoControl
        Me.L05A.Location = New System.Drawing.Point(75, 215)
        Me.L05A.Name = "L05A"
        Me.L05A.Size = New System.Drawing.Size(39, 27)
        Me.L05A.TabIndex = 56
        Me.L05A.Text = "PA5"
        Me.L05A.UseVisualStyleBackColor = False
        '
        'L04E
        '
        Me.L04E.BackColor = System.Drawing.Color.Green
        Me.L04E.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.L04E.ImeMode = System.Windows.Forms.ImeMode.NoControl
        Me.L04E.Location = New System.Drawing.Point(165, 182)
        Me.L04E.Name = "L04E"
        Me.L04E.Size = New System.Drawing.Size(39, 27)
        Me.L04E.TabIndex = 55
        Me.L04E.Text = "PE4"
        Me.L04E.UseVisualStyleBackColor = False
        '
        'L04V
        '
        Me.L04V.BackColor = System.Drawing.Color.Green
        Me.L04V.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.L04V.ImeMode = System.Windows.Forms.ImeMode.NoControl
        Me.L04V.Location = New System.Drawing.Point(120, 182)
        Me.L04V.Name = "L04V"
        Me.L04V.Size = New System.Drawing.Size(39, 27)
        Me.L04V.TabIndex = 54
        Me.L04V.Text = "PV4"
        Me.L04V.UseVisualStyleBackColor = False
        '
        'Label9
        '
        Me.Label9.AutoSize = True
        Me.Label9.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label9.ImeMode = System.Windows.Forms.ImeMode.NoControl
        Me.Label9.Location = New System.Drawing.Point(48, 188)
        Me.Label9.Name = "Label9"
        Me.Label9.Size = New System.Drawing.Size(21, 15)
        Me.Label9.TabIndex = 53
        Me.Label9.Text = "L4"
        '
        'L04A
        '
        Me.L04A.BackColor = System.Drawing.Color.Green
        Me.L04A.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.L04A.ImeMode = System.Windows.Forms.ImeMode.NoControl
        Me.L04A.Location = New System.Drawing.Point(75, 182)
        Me.L04A.Name = "L04A"
        Me.L04A.Size = New System.Drawing.Size(39, 27)
        Me.L04A.TabIndex = 52
        Me.L04A.Text = "PA4"
        Me.L04A.UseVisualStyleBackColor = False
        '
        'L03E
        '
        Me.L03E.BackColor = System.Drawing.Color.Green
        Me.L03E.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.L03E.ImeMode = System.Windows.Forms.ImeMode.NoControl
        Me.L03E.Location = New System.Drawing.Point(165, 149)
        Me.L03E.Name = "L03E"
        Me.L03E.Size = New System.Drawing.Size(39, 27)
        Me.L03E.TabIndex = 51
        Me.L03E.Text = "PE3"
        Me.L03E.UseVisualStyleBackColor = False
        '
        'L03V
        '
        Me.L03V.BackColor = System.Drawing.Color.Green
        Me.L03V.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.L03V.ImeMode = System.Windows.Forms.ImeMode.NoControl
        Me.L03V.Location = New System.Drawing.Point(120, 149)
        Me.L03V.Name = "L03V"
        Me.L03V.Size = New System.Drawing.Size(39, 27)
        Me.L03V.TabIndex = 50
        Me.L03V.Text = "PV3"
        Me.L03V.UseVisualStyleBackColor = False
        '
        'Label8
        '
        Me.Label8.AutoSize = True
        Me.Label8.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label8.ImeMode = System.Windows.Forms.ImeMode.NoControl
        Me.Label8.Location = New System.Drawing.Point(48, 155)
        Me.Label8.Name = "Label8"
        Me.Label8.Size = New System.Drawing.Size(21, 15)
        Me.Label8.TabIndex = 49
        Me.Label8.Text = "L3"
        '
        'L03A
        '
        Me.L03A.BackColor = System.Drawing.Color.Green
        Me.L03A.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.L03A.ImeMode = System.Windows.Forms.ImeMode.NoControl
        Me.L03A.Location = New System.Drawing.Point(75, 149)
        Me.L03A.Name = "L03A"
        Me.L03A.Size = New System.Drawing.Size(39, 27)
        Me.L03A.TabIndex = 48
        Me.L03A.Text = "PA3"
        Me.L03A.UseVisualStyleBackColor = False
        '
        'L02E
        '
        Me.L02E.BackColor = System.Drawing.Color.Green
        Me.L02E.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.L02E.ImeMode = System.Windows.Forms.ImeMode.NoControl
        Me.L02E.Location = New System.Drawing.Point(165, 116)
        Me.L02E.Name = "L02E"
        Me.L02E.Size = New System.Drawing.Size(39, 27)
        Me.L02E.TabIndex = 47
        Me.L02E.Text = "PE2"
        Me.L02E.UseVisualStyleBackColor = False
        '
        'L02V
        '
        Me.L02V.BackColor = System.Drawing.Color.Green
        Me.L02V.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.L02V.ImeMode = System.Windows.Forms.ImeMode.NoControl
        Me.L02V.Location = New System.Drawing.Point(120, 116)
        Me.L02V.Name = "L02V"
        Me.L02V.Size = New System.Drawing.Size(39, 27)
        Me.L02V.TabIndex = 46
        Me.L02V.Text = "PV2"
        Me.L02V.UseVisualStyleBackColor = False
        '
        'Label7
        '
        Me.Label7.AutoSize = True
        Me.Label7.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label7.ImeMode = System.Windows.Forms.ImeMode.NoControl
        Me.Label7.Location = New System.Drawing.Point(48, 122)
        Me.Label7.Name = "Label7"
        Me.Label7.Size = New System.Drawing.Size(21, 15)
        Me.Label7.TabIndex = 45
        Me.Label7.Text = "L2"
        '
        'L02A
        '
        Me.L02A.BackColor = System.Drawing.Color.Green
        Me.L02A.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.L02A.ImeMode = System.Windows.Forms.ImeMode.NoControl
        Me.L02A.Location = New System.Drawing.Point(75, 116)
        Me.L02A.Name = "L02A"
        Me.L02A.Size = New System.Drawing.Size(39, 27)
        Me.L02A.TabIndex = 44
        Me.L02A.Text = "PA2"
        Me.L02A.UseVisualStyleBackColor = False
        '
        'L01E
        '
        Me.L01E.BackColor = System.Drawing.Color.Green
        Me.L01E.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.L01E.ImeMode = System.Windows.Forms.ImeMode.NoControl
        Me.L01E.Location = New System.Drawing.Point(165, 83)
        Me.L01E.Name = "L01E"
        Me.L01E.Size = New System.Drawing.Size(39, 27)
        Me.L01E.TabIndex = 43
        Me.L01E.Text = "PE1"
        Me.L01E.UseVisualStyleBackColor = False
        '
        'L01V
        '
        Me.L01V.BackColor = System.Drawing.Color.Green
        Me.L01V.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.L01V.ImeMode = System.Windows.Forms.ImeMode.NoControl
        Me.L01V.Location = New System.Drawing.Point(120, 83)
        Me.L01V.Name = "L01V"
        Me.L01V.Size = New System.Drawing.Size(39, 27)
        Me.L01V.TabIndex = 42
        Me.L01V.Text = "PV1"
        Me.L01V.UseVisualStyleBackColor = False
        '
        'Line1
        '
        Me.Line1.AutoSize = True
        Me.Line1.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Line1.ImeMode = System.Windows.Forms.ImeMode.NoControl
        Me.Line1.Location = New System.Drawing.Point(48, 89)
        Me.Line1.Name = "Line1"
        Me.Line1.Size = New System.Drawing.Size(21, 15)
        Me.Line1.TabIndex = 41
        Me.Line1.Text = "L1"
        '
        'L01A
        '
        Me.L01A.BackColor = System.Drawing.Color.Green
        Me.L01A.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.L01A.ImeMode = System.Windows.Forms.ImeMode.NoControl
        Me.L01A.Location = New System.Drawing.Point(75, 83)
        Me.L01A.Name = "L01A"
        Me.L01A.Size = New System.Drawing.Size(39, 27)
        Me.L01A.TabIndex = 40
        Me.L01A.Text = "PA1"
        Me.L01A.UseVisualStyleBackColor = False
        '
        'bntLineaPM
        '
        Me.bntLineaPM.BackColor = System.Drawing.Color.DodgerBlue
        Me.bntLineaPM.Location = New System.Drawing.Point(181, 324)
        Me.bntLineaPM.Name = "bntLineaPM"
        Me.bntLineaPM.Size = New System.Drawing.Size(98, 33)
        Me.bntLineaPM.TabIndex = 5
        Me.bntLineaPM.Text = "LINEA EN PM"
        Me.bntLineaPM.UseVisualStyleBackColor = False
        '
        'btnHabilita
        '
        Me.btnHabilita.BackColor = System.Drawing.Color.Lime
        Me.btnHabilita.Location = New System.Drawing.Point(323, 281)
        Me.btnHabilita.Name = "btnHabilita"
        Me.btnHabilita.Size = New System.Drawing.Size(98, 33)
        Me.btnHabilita.TabIndex = 5
        Me.btnHabilita.Text = "Habilitar"
        Me.btnHabilita.UseVisualStyleBackColor = False
        '
        'btnLineDis
        '
        Me.btnLineDis.BackColor = System.Drawing.Color.Red
        Me.btnLineDis.Location = New System.Drawing.Point(323, 324)
        Me.btnLineDis.Name = "btnLineDis"
        Me.btnLineDis.Size = New System.Drawing.Size(98, 33)
        Me.btnLineDis.TabIndex = 5
        Me.btnLineDis.Text = "Deshabilitar"
        Me.btnLineDis.UseVisualStyleBackColor = False
        '
        'txtLineDis
        '
        Me.txtLineDis.Location = New System.Drawing.Point(165, 284)
        Me.txtLineDis.Name = "txtLineDis"
        Me.txtLineDis.ReadOnly = True
        Me.txtLineDis.Size = New System.Drawing.Size(141, 20)
        Me.txtLineDis.TabIndex = 4
        '
        'Label6
        '
        Me.Label6.AutoSize = True
        Me.Label6.Location = New System.Drawing.Point(116, 291)
        Me.Label6.Name = "Label6"
        Me.Label6.Size = New System.Drawing.Size(33, 13)
        Me.Label6.TabIndex = 3
        Me.Label6.Text = "Linea"
        '
        'tabReporte
        '
        Me.tabReporte.Controls.Add(Me.btnEnvReport)
        Me.tabReporte.Location = New System.Drawing.Point(4, 22)
        Me.tabReporte.Name = "tabReporte"
        Me.tabReporte.Padding = New System.Windows.Forms.Padding(3)
        Me.tabReporte.Size = New System.Drawing.Size(484, 411)
        Me.tabReporte.TabIndex = 3
        Me.tabReporte.Text = "Reporte"
        Me.tabReporte.UseVisualStyleBackColor = True
        '
        'btnEnvReport
        '
        Me.btnEnvReport.Location = New System.Drawing.Point(145, 168)
        Me.btnEnvReport.Name = "btnEnvReport"
        Me.btnEnvReport.Size = New System.Drawing.Size(169, 27)
        Me.btnEnvReport.TabIndex = 0
        Me.btnEnvReport.Text = "Enviar reporte en eMail"
        Me.btnEnvReport.UseVisualStyleBackColor = True
        '
        'txtPrivilegios
        '
        Me.txtPrivilegios.AutoSize = True
        Me.txtPrivilegios.Location = New System.Drawing.Point(462, 11)
        Me.txtPrivilegios.Name = "txtPrivilegios"
        Me.txtPrivilegios.Size = New System.Drawing.Size(0, 13)
        Me.txtPrivilegios.TabIndex = 1
        Me.txtPrivilegios.Visible = False
        '
        'txtNumEm
        '
        Me.txtNumEm.AutoSize = True
        Me.txtNumEm.Location = New System.Drawing.Point(309, 9)
        Me.txtNumEm.Name = "txtNumEm"
        Me.txtNumEm.Size = New System.Drawing.Size(0, 13)
        Me.txtNumEm.TabIndex = 2
        '
        'txtNom
        '
        Me.txtNom.AutoSize = True
        Me.txtNom.Location = New System.Drawing.Point(359, 9)
        Me.txtNom.Name = "txtNom"
        Me.txtNom.Size = New System.Drawing.Size(0, 13)
        Me.txtNom.TabIndex = 3
        '
        'L13A
        '
        Me.L13A.BackColor = System.Drawing.Color.Green
        Me.L13A.Font = New System.Drawing.Font("Microsoft Sans Serif", 6.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.L13A.ImeMode = System.Windows.Forms.ImeMode.NoControl
        Me.L13A.Location = New System.Drawing.Point(269, 247)
        Me.L13A.Name = "L13A"
        Me.L13A.Size = New System.Drawing.Size(39, 27)
        Me.L13A.TabIndex = 76
        Me.L13A.Text = "PA13"
        Me.L13A.UseVisualStyleBackColor = False
        '
        'Label19
        '
        Me.Label19.AutoSize = True
        Me.Label19.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label19.ImeMode = System.Windows.Forms.ImeMode.NoControl
        Me.Label19.Location = New System.Drawing.Point(242, 255)
        Me.Label19.Name = "Label19"
        Me.Label19.Size = New System.Drawing.Size(28, 15)
        Me.Label19.TabIndex = 77
        Me.Label19.Text = "L13"
        '
        'L13V
        '
        Me.L13V.BackColor = System.Drawing.Color.Green
        Me.L13V.Font = New System.Drawing.Font("Microsoft Sans Serif", 6.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.L13V.ImeMode = System.Windows.Forms.ImeMode.NoControl
        Me.L13V.Location = New System.Drawing.Point(314, 247)
        Me.L13V.Name = "L13V"
        Me.L13V.Size = New System.Drawing.Size(39, 27)
        Me.L13V.TabIndex = 78
        Me.L13V.Text = "PV13"
        Me.L13V.UseVisualStyleBackColor = False
        '
        'L13E
        '
        Me.L13E.BackColor = System.Drawing.Color.Green
        Me.L13E.Font = New System.Drawing.Font("Microsoft Sans Serif", 6.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.L13E.ImeMode = System.Windows.Forms.ImeMode.NoControl
        Me.L13E.Location = New System.Drawing.Point(359, 247)
        Me.L13E.Name = "L13E"
        Me.L13E.Size = New System.Drawing.Size(39, 27)
        Me.L13E.TabIndex = 79
        Me.L13E.Text = "PE13"
        Me.L13E.UseVisualStyleBackColor = False
        '
        'Ajustes
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.ClientSize = New System.Drawing.Size(516, 460)
        Me.Controls.Add(Me.txtNom)
        Me.Controls.Add(Me.txtNumEm)
        Me.Controls.Add(Me.txtPrivilegios)
        Me.Controls.Add(Me.tabAjustes)
        Me.Name = "Ajustes"
        Me.Text = "Ajustes"
        Me.tabAjustes.ResumeLayout(False)
        Me.tabTecnicos.ResumeLayout(False)
        Me.tabTecnicos.PerformLayout()
        Me.Permisos.ResumeLayout(False)
        Me.Permisos.PerformLayout()
        Me.GroupBox1.ResumeLayout(False)
        Me.GroupBox1.PerformLayout()
        Me.tabTooling.ResumeLayout(False)
        Me.tabTooling.PerformLayout()
        Me.tabDeshabilitar.ResumeLayout(False)
        Me.tabDeshabilitar.PerformLayout()
        Me.tabReporte.ResumeLayout(False)
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub
    Friend WithEvents tabAjustes As System.Windows.Forms.TabControl
    Friend WithEvents tabTecnicos As System.Windows.Forms.TabPage
    Friend WithEvents tabTooling As System.Windows.Forms.TabPage
    Friend WithEvents btnRegistrar As System.Windows.Forms.Button
    Friend WithEvents btnCancelar As System.Windows.Forms.Button
    Friend WithEvents lblAlta As System.Windows.Forms.Label
    Friend WithEvents txtNumero As System.Windows.Forms.TextBox
    Friend WithEvents Empleado As System.Windows.Forms.Label
    Friend WithEvents txtNombre As System.Windows.Forms.TextBox
    Friend WithEvents Nombre As System.Windows.Forms.Label
    Friend WithEvents btnAlta As System.Windows.Forms.Button
    Friend WithEvents txtID As System.Windows.Forms.TextBox
    Friend WithEvents cmbDesc As System.Windows.Forms.ComboBox
    Friend WithEvents txtTipoT As System.Windows.Forms.TextBox
    Friend WithEvents Label5 As System.Windows.Forms.Label
    Friend WithEvents Label4 As System.Windows.Forms.Label
    Friend WithEvents Label3 As System.Windows.Forms.Label
    Friend WithEvents Label2 As System.Windows.Forms.Label
    Friend WithEvents Label1 As System.Windows.Forms.Label
    Friend WithEvents tabDeshabilitar As System.Windows.Forms.TabPage
    Friend WithEvents btnLineDis As System.Windows.Forms.Button
    Friend WithEvents txtLineDis As System.Windows.Forms.TextBox
    Friend WithEvents Label6 As System.Windows.Forms.Label
    Friend WithEvents tabReporte As System.Windows.Forms.TabPage
    Friend WithEvents btnEnvReport As System.Windows.Forms.Button
    Friend WithEvents L01E As System.Windows.Forms.Button
    Friend WithEvents L01V As System.Windows.Forms.Button
    Friend WithEvents Line1 As System.Windows.Forms.Label
    Friend WithEvents L01A As System.Windows.Forms.Button
    Friend WithEvents L02E As System.Windows.Forms.Button
    Friend WithEvents L02V As System.Windows.Forms.Button
    Friend WithEvents Label7 As System.Windows.Forms.Label
    Friend WithEvents L02A As System.Windows.Forms.Button
    Friend WithEvents L10E As System.Windows.Forms.Button
    Friend WithEvents L10V As System.Windows.Forms.Button
    Friend WithEvents Label11 As System.Windows.Forms.Label
    Friend WithEvents L10A As System.Windows.Forms.Button
    Friend WithEvents L09E As System.Windows.Forms.Button
    Friend WithEvents L09V As System.Windows.Forms.Button
    Friend WithEvents Label12 As System.Windows.Forms.Label
    Friend WithEvents L09A As System.Windows.Forms.Button
    Friend WithEvents L08E As System.Windows.Forms.Button
    Friend WithEvents L08V As System.Windows.Forms.Button
    Friend WithEvents Label13 As System.Windows.Forms.Label
    Friend WithEvents L08A As System.Windows.Forms.Button
    Friend WithEvents L07E As System.Windows.Forms.Button
    Friend WithEvents L07V As System.Windows.Forms.Button
    Friend WithEvents Label14 As System.Windows.Forms.Label
    Friend WithEvents L07A As System.Windows.Forms.Button
    Friend WithEvents L06E As System.Windows.Forms.Button
    Friend WithEvents L06V As System.Windows.Forms.Button
    Friend WithEvents Label16 As System.Windows.Forms.Label
    Friend WithEvents L06A As System.Windows.Forms.Button
    Friend WithEvents L05E As System.Windows.Forms.Button
    Friend WithEvents L05V As System.Windows.Forms.Button
    Friend WithEvents Label10 As System.Windows.Forms.Label
    Friend WithEvents L05A As System.Windows.Forms.Button
    Friend WithEvents L04E As System.Windows.Forms.Button
    Friend WithEvents L04V As System.Windows.Forms.Button
    Friend WithEvents Label9 As System.Windows.Forms.Label
    Friend WithEvents L04A As System.Windows.Forms.Button
    Friend WithEvents L03E As System.Windows.Forms.Button
    Friend WithEvents L03V As System.Windows.Forms.Button
    Friend WithEvents Label8 As System.Windows.Forms.Label
    Friend WithEvents L03A As System.Windows.Forms.Button
    Friend WithEvents Label15 As System.Windows.Forms.Label
    Friend WithEvents txtPrivilegios As System.Windows.Forms.Label
    Friend WithEvents txtNumEm As System.Windows.Forms.Label
    Friend WithEvents txtNom As System.Windows.Forms.Label
    Friend WithEvents btnCerrar As System.Windows.Forms.Button
    Friend WithEvents txtEmail As System.Windows.Forms.TextBox
    Friend WithEvents txtApellido As System.Windows.Forms.TextBox
    Friend WithEvents Label18 As System.Windows.Forms.Label
    Friend WithEvents txtVida As System.Windows.Forms.TextBox
    Friend WithEvents Label20 As System.Windows.Forms.Label
    Friend WithEvents GroupBox1 As System.Windows.Forms.GroupBox
    Friend WithEvents Permisos As System.Windows.Forms.GroupBox
    Friend WithEvents rbEmailSi As System.Windows.Forms.RadioButton
    Friend WithEvents rbEmailNo As System.Windows.Forms.RadioButton
    Friend WithEvents rbAdministrador As System.Windows.Forms.RadioButton
    Friend WithEvents rbTecnico As System.Windows.Forms.RadioButton
    Friend WithEvents lblEmail As System.Windows.Forms.Label
    Friend WithEvents btnCreateFiles As System.Windows.Forms.Button
    Friend WithEvents bntLineaPM As Button
    Friend WithEvents btnHabilita As Button
    Friend WithEvents L11E As Button
    Friend WithEvents L11V As Button
    Friend WithEvents Label17 As Label
    Friend WithEvents L11A As Button
    Friend WithEvents L13E As Button
    Friend WithEvents L13V As Button
    Friend WithEvents Label19 As Label
    Friend WithEvents L13A As Button
End Class
