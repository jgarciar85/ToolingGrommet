Option Strict Off
Option Explicit On
Imports System.Globalization
Imports System.Data.OleDb
Imports System.IO
Imports Microsoft.VisualBasic.Devices
Imports System.Collections
Imports System.Web
Imports System.Net.Mail
Imports CDO.CdoConfiguration
Imports CDO
Friend Class Form1
    Inherits System.Windows.Forms.Form
    Dim FileWriter As StreamWriter
    Dim FileReader As StreamReader
    Dim Screen, ShowInfo As Integer
    Dim InicioTurno, FinTurno As String
    Dim TiempoTranscurrido As Integer
    Dim dblTPA1, dblTPE1, dblTPV1, dblTPA2, dblTPE2, dblTPV2, dblTPA3, dblTPE3, dblTPV3, dblTPA4, dblTPE4, dblTPV4 As Double
    Dim dblTPA5, dblTPE5, dblTPV5, dblTPA6, dblTPE6, dblTPV6, dblTPA7, dblTPE7, dblTPV7, dblTPA8, dblTPE8, dblTPV8 As Double
    Dim dblTPA9, dblTPE9, dblTPV9, dblTPA10, dblTPE10, dblTPV10 As Double
    Dim StrUsage As String
    Dim UsageTPA1, UsageTPE1, UsageTPV1, UsageTPA2, UsageTPE2, UsageTPV2, UsageTPA3, UsageTPE3, UsageTPV3, UsageTPA4, UsageTPE4, UsageTPV4 As Double
    Dim UsageTPA5, UsageTPE5, UsageTPV5, UsageTPA6, UsageTPE6, UsageTPV6, UsageTPA7, UsageTPE7, UsageTPV7, UsageTPA8, UsageTPE8, UsageTPV8 As Double
    Dim UsageTPA9, UsageTPE9, UsageTPV9, UsageTPA10, UsageTPE10, UsageTPV10 As Double
    Dim TVida As TimeSpan

    Dim Ttotal As Double = 0
    Dim strEstadoTimer As String

    Dim intTPA1, intTPE1, intTPV1, intTPA2, intTPE2, intTPV2, intTPA3, intTPE3, intTPV3, intTPA4, intTPE4, intTPV4, intTPA5, intTPE5, intTPV5 As Integer
    Dim intTPA6, intTPE6, intTPV6, intTPA7, intTPE7, intTPV7, intTPA8, intTPE8, intTPV8, intTPA9, intTPE9, intTPV9, intTPA10, intTPE10, intTPV10 As Integer

    Private myConString As String
    Private con As OleDbConnection = New OleDbConnection
    Private Dadapter As OleDbDataAdapter
    Private DSet As DataSet
    Private DSet2 As DataSet
    Private ConCMD As OleDb.OleDbCommand
    Dim g_IntSaveGrid As Integer
    Dim save As Double = 1
    Dim flagsave As Integer = 0
    Dim FILE_NAME_Logger As String = "C:\APP\TOOLING\Data\Logger.txt"
    Dim objWrtLOG As New System.IO.StreamWriter(FILE_NAME_Logger, True)

    Dim sDBtoFile As String = "C:\APP\TOOLING\Data\Running.txt"
    Dim StrFecha, StrHora, StrLinea, StrToolingID, StrEstado, StrVida, StrHr, StrUsoFile As String
    Dim StrUso As Double
    Dim StrDummy As String

    Dim TextLine As String = vbNullString
    Dim TestString As String = vbNullString
    Dim strDummyLine As String = vbNullString

    Private Sub TimerMain_Tick(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles TimerMain.Tick
        If System.IO.File.Exists("C:\APP\TOOLING\Data\HandHeld1.con") = False Then
            Dim FILE_NAME_PROCESS As String = "C:\APP\TOOLING\Data\Process.con"
            If System.IO.File.Exists(FILE_NAME_PROCESS) = False Then
                System.IO.File.Create(FILE_NAME_PROCESS).Dispose()
            End If
            Try
DeNew1:
                TimerMain.Enabled = 0
                TimerMain2.Enabled = 0
                TmrDbToFile.Enabled = False
                ' Procesa primero el ToolRepair por si reparaste algun Tooling
ToolRepair1:
                If System.IO.File.Exists("C:\APP\TOOLING\Data\ToolRepair1.ok") = True Then
                    'System.Threading.Thread.Sleep(1000)
                    TimerMain.Enabled = 0
                    TimerMain2.Enabled = 0

                    UpdateTableFromHH("C:\APP\TOOLING\Data\ToolRepair1.ok")
                    If System.IO.File.Exists("C:\APP\TOOLING\Data\ToolRepair1.ok") = True Then
                        System.IO.File.Delete("C:\APP\TOOLING\Data\ToolRepair1.ok")
                    End If

                End If

                'Procesa el archivo MyDebug si instalaste algun tooling
MyDebug1:
                If System.IO.File.Exists("C:\APP\TOOLING\Data\Mydebug1.dat") = True Then
                    ' System.Threading.Thread.Sleep(1000)
                    TimerMain.Enabled = 0
                    TimerMain2.Enabled = 0
                    UpdateTableFromFile("C:\APP\TOOLING\Data\Mydebug1.dat")

                    If System.IO.File.Exists("C:\APP\TOOLING\Data\Mydebug1.dat") = True Then
                        System.IO.File.Delete("C:\APP\TOOLING\Data\Mydebug1.dat")
                    End If
                End If

                ''''''GoTo MyDebug
                'Crea el archivo de Tooling Bueno
ToolOK1:
                If System.IO.File.Exists("C:\APP\TOOLING\Data\ToolOK.TXT") = True Then
                    'System.Threading.Thread.Sleep(1000)
                    System.IO.File.Delete("C:\APP\TOOLING\Data\ToolOK.TXT")
                    TimerMain.Enabled = 0
                    TimerMain2.Enabled = 0

                    CreateGoodTooling()
                Else
                    CreateGoodTooling()
                    TimerMain.Enabled = 0
                    TimerMain2.Enabled = 0

                End If

                '''''''''  GoTo ToolOK  
                ' Crea el archivo de Tooling Malo
ToolBAD1:
                If System.IO.File.Exists("C:\APP\TOOLING\Data\ToolBAD.txt") = True Then
                    ' System.Threading.Thread.Sleep(1000)
                    TimerMain.Enabled = 0
                    TimerMain2.Enabled = 0
                    System.IO.File.Delete("C:\APP\TOOLING\Data\ToolBAD.txt")
                    CreateBadTooling()
                Else
                    'Create ToolBAD.txt if deleted by error
                    CreateBadTooling()

                    TimerMain.Enabled = 1
                    TimerMain2.Enabled = 1
                End If
                '''''''''''''   GoTo ToolBAD
                UpdateGrid()
                TimerMain.Enabled = 1
                TimerMain2.Enabled = 1
                
                TmrDbToFile.Enabled = True
                ' errores  
            Catch oe As Exception
                'MsgBox(oe.Message, MsgBoxStyle.Critical)
                GoTo DeNew1
            End Try
            GetTimers()
            DBtoFile()
            DBtoFileRead()
            If System.IO.File.Exists("C:\APP\TOOLING\Data\Process.con") = True Then
                System.IO.File.Delete("C:\APP\TOOLING\Data\Process.con")
            End If
            If ShowInfo = 1 Then
                If Screen = 0 Then
                    Label19.Hide()
                    Me.TabHistorial.Show()
                    Me.TabHistorial.SelectTab(0)
                    Screen = 1 '1
                ElseIf Screen = 1 Then
                    Label19.Hide()
                    Me.TabHistorial.SelectTab(1)
                    Me.TabHistorial.Show()
                    Screen = 3 '3
                ElseIf Screen = 2 Then
                    Label19.Hide()
                    Me.TabHistorial.SelectTab(1)
                    Me.TabHistorial.Show()
                    Screen = 3
                ElseIf Screen = 3 Then
                    Label19.Show()
                    Me.TabHistorial.Hide()
                    Screen = 0 '0
                   
                End If
            End If
            TimerMain.Enabled = 0
            TimerMain2.Enabled = 2

        End If

       


    End Sub

    Public Function UpdateTableFromFile(ByVal StrFileNameTbl As String) As Double

        'Procesa la info del MyDebug si instalaste algun Tooling
        Dim DownTimeCnnStr As String = "Provider=Microsoft.Jet.OLEDB.4.0;Data Source=C:\APP\TOOLING\Data\PINPACK.mdb;Persist Security Info=False;"
        Dim conn1 As New System.Data.OleDb.OleDbConnection(DownTimeCnnStr)
        Dim query As String '= "Select TMUERTO FROM REPORTES WHERE DEPTO='TESTING' AND (AREA ='Palomar' or AREA ='Palomar 33xx' ) and HORA_REPORTE >= #" + InicioTurno + "# AND HORA_TERMINO <= #" + FinTurno + " #"
        Dim queryupd As String

        Dim SPath As String = "c:\APP\TOOLING\DATA\"
        Dim sContent As String = vbNullString
        Dim sdir As String = "c:\Nueva carpeta"
        Dim strDummysDate, strDummysHr, strDummyLine, strDummyPrensa, strDummyArea, strDummyTurno, strDummyTool, strDummyPPAnt, strDummyPPNew, strDummGreenPlate, strDummyQtyLabD, strDummyLaine, strDummyTec, strDummyState, strDummyId, strDummyNumEmp As String
        strDummyId = ""
        SPath = StrFileNameTbl
        Try

            With My.Computer.FileSystem
                ' verifica si existe el path  
                If .FileExists(SPath) Then
                    ' lee todo el contenido  
                    Dim objReader As New System.IO.StreamReader(SPath)
                    Do While objReader.Peek() <> -1


                        TextLine = TextLine & objReader.ReadLine()

                        TestString = TextLine

                        Dim TestArray() As String = Split(TestString)

                        Dim LastNonEmpty As Integer = 0
                        Dim pm As String
                        For i As Integer = 0 To 1
                            If TestArray(i) <> "" Then
                                LastNonEmpty += 1
                                strDummysDate = TestArray(i)
                                strDummysHr = TestArray(i + 1)
                                pm = TestArray(i + 2)
                                strDummyTurno = TestArray(i + 3)
                                strDummyLine = TestArray(i + 4)
                                strDummyPrensa = TestArray(i + 5)
                                strDummyArea = TestArray(i + 6)
                                strDummyTool = TestArray(i + 7)
                                strDummyPPAnt = TestArray(i + 8)
                                strDummyPPNew = TestArray(i + 9)
                                strDummGreenPlate = TestArray(i + 10)
                                strDummyQtyLabD = TestArray(i + 11)
                                strDummyLaine = TestArray(i + 12)
                                strDummyNumEmp = TestArray(i + 13)
                                strDummyTec = TestArray(i + 14)
                                strDummyState = TestArray(i + 15)
                                StrUsage = TestArray(i + 16)   'Usage
                                StrUsage = StrUsage.Trim()
                                strDummysHr = strDummysHr + " " + pm
                                i = i + 1
                                ' TestArray(LastNonEmpty) = TestArray(i)
                            End If
                        Next
                        ReDim Preserve TestArray(LastNonEmpty)

                        '----------Modificacion para sacar el tiempo de uso del tooling que es reemplazado------------------------------------------

                        'Logica que hace la diferencia en segundos desde la fecha/hora que se capturo el Tooling
                        'hasta la fecha hora que lo esta bajando a la base
                        Dim FileTime, FileTimeEncontrado As DateTime 'FileTime es el que viene de MyDebug y FileEncontrado el que esta instalado
                        Dim SecDiff As Double 'Alacena la diferencia de MyDebug y cuando conectas ala HH
                        Dim StrHr, StrHrEncontrado As String

                        StrHr = strDummysDate + " " + strDummysHr
                        FileTime = Convert.ToDateTime(StrHr)
                        SecDiff = DateDiff(DateInterval.Second, FileTime, DateTime.Now)

                        'hay que hacer una busqueda de la linea que traiga el ultimo TOOLINGID instalado

                        conn1.Open()

                        query = "Select * FROM INFOLINES WHERE INFOLINES.LINEA='" + strDummyLine + "' ORDER BY FECHA DESC, HORA DESC"
                        Dim cmd13 As New System.Data.OleDb.OleDbCommand(query, conn1)
                        Dim reader13 As OleDbDataReader = cmd13.ExecuteReader

                        Dim Encontrado0, Encontrado1, Encontrado15, Encontrado6 As String
                        Dim Encontrado16 As Double

                        'identifica el reporte mas reciente para esa linea
                        reader13.Read()
                        Encontrado0 = reader13.GetValue(0) 'trae la fecha
                        Encontrado1 = reader13.GetValue(1) 'trae la hora
                        Encontrado16 = reader13.GetValue(17) 'trae la vida
                        Encontrado15 = reader13.GetString(16) 'trae el status
                        Encontrado6 = reader13.GetString(6) 'trae el ToolingID que se esta quitando

                        conn1.Close()

                        ' Ese TOOLINgID que haga una resta del tiempo que se instalo este nuevo y el tiempo del encontrado

                        StrHrEncontrado = Encontrado0 ' + " " + Encontrado1
                        FileTimeEncontrado = Convert.ToDateTime(StrHrEncontrado)

                        Dim ToolTotaltime As Double

                        ToolTotaltime = DateDiff(DateInterval.Second, FileTimeEncontrado, FileTime)

                        'Logica que calcula la eficiencia de quien esta instalando el tooling:
                        'Calcula cuantos minutos lo cambio antes o despues

                        Dim CalcEficiencia As Double

                        CalcEficiencia = ToolTotaltime - Convert.ToDouble(Encontrado16)


                        'en el insert de abajo que suba el resultado de la resta y update al tooling ID viejo
                        Dim strUsingU As String = "U"

                        conn1.Open()
                        query = "INSERT INTO INFOLINES (FECHA,HORA,TURNO,LINEA,PRENSA,AREA, TOOLINGID,PPACKANT,PPACKNUEVO, GREENPLATE, QTYLABIOSDOBLADOS, QTYPINESDOBLADOS, QTYPINESQUEBRADOS, LAINA,EMPLEADO, INSTALO, ESTADO, VIDA, QUITO, DURATOTAL, EFICIENCIA) VALUES ('" & FileTime & "','" & strDummysHr & "', '" & strDummyTurno & "','" & strDummyLine & "','" & strDummyPrensa & "','" & strDummyArea & "','" & strDummyTool & "','" & strDummyPPAnt & "','" & strDummyPPNew & "','" & strDummGreenPlate & "','" & strDummyQtyLabD & "','" & strUsingU & "','" & strUsingU & "','" & strDummyLaine & "','" & strDummyNumEmp & "','" & strDummyTec & "','" & strDummyState & "','" & StrUsage & "','" & "EnUso" & "','" & "0" & "','" & "0" & "' )"
                        queryupd = "UPDATE INFOLINES SET ESTADO = 'R', QUITO = '" & strDummyTec & "', DURATOTAL = '" & ToolTotaltime & "', EFICIENCIA = '" & CalcEficiencia & "' WHERE FECHA = #" & Encontrado0 & "# AND HORA = #" & Encontrado1 & "#"

                        If Encontrado15 = "D" Then
                            queryupd = "UPDATE INFOLINES SET QUITO = '" & strDummyTec & "', DURATOTAL = '" & "0" & "', EFICIENCIA = '" & "0" & "' WHERE FECHA = #" & Encontrado0 & "# AND HORA = #" & Encontrado1 & "#"
                        End If

                        Dim cmd1 As New System.Data.OleDb.OleDbCommand(query, conn1)
                        cmd1.ExecuteNonQuery()

                        'crea el LOG de lo que estas instalando
                        If TestString <> vbNullString Then
                            Using objWrtLOG As New System.IO.StreamWriter(FILE_NAME_Logger, True)
                                objWrtLOG.WriteLine(DateAndTime.Now + " Mydebug.DAT: " + TestString)
                                objWrtLOG.Close()
                            End Using
                        End If


                        Dim cmd10 As New System.Data.OleDb.OleDbCommand(queryupd, conn1)
                        cmd10.ExecuteNonQuery()


                        conn1.Close()
                        TextLine = ""

                        '---------------------------------------------------------------------------------------------------------------------



                        conn1.Open()

                        query = "Select RUNNING.ESTADO FROM RUNNING WHERE RUNNING.LINEA='" + strDummyLine + "'"
                        Dim cmd3 As New System.Data.OleDb.OleDbCommand(query, conn1)
                        Dim reader3 As OleDbDataReader = cmd3.ExecuteReader
                        Dim strEstado As String

                        strEstado = "X"
                        While reader3.Read()
                            strEstado = reader3.GetString(0)

                        End While

                        conn1.Close()

                        If strEstado = "X" Then
                            conn1.Open()
                            query = "INSERT INTO RUNNING (FECHA,HORA,TURNO,LINEA,PRENSA,AREA,TOOLINGID,PPACKANT,PPACKNUEVO, GREENPLATE,QTYLABIOSDOBLADOS, LAINA,EMPLEADO ,INSTALO, ESTADO, VIDA) VALUES ('" & strDummysDate & "','" & strDummysHr & "', '" & strDummyTurno & "','" & strDummyLine & "','" & strDummyPrensa & "','" & strDummyArea & "','" & strDummyTool & "','" & strDummyPPAnt & "','" & strDummyPPNew & "','" & strDummGreenPlate & "','" & strDummyQtyLabD & "','" & strDummyLaine & "','" & strDummyNumEmp & "','" & strDummyTec & "','" & strDummyState & "','" & StrUsage & "' )"
                            Dim cmd5 As New System.Data.OleDb.OleDbCommand(query, conn1)
                            cmd5.ExecuteNonQuery()

                            conn1.Close()

                        Else

                            'Graba en la tabla Running la informacion del Tooling que estas instalando
                            If strEstado = "G" Or strEstado = "Y" Or strEstado = "R" Or strEstado = "D" Or strEstado = "U" Then
                                conn1.Open()
                                query = "UPDATE  RUNNING SET FECHA = '" & strDummysDate & "',HORA = '" & strDummysHr & "',TURNO = '" & strDummyTurno & "',PRENSA='" & strDummyPrensa & "',AREA='" & strDummyArea & "',TOOLINGID='" & strDummyTool & "',PPACKANT='" & strDummyPPAnt & "',PPACKNUEVO='" & strDummyPPNew & "', GREENPLATE= '" & strDummGreenPlate & "',QTYLABIOSDOBLADOS='" & strDummyQtyLabD & "', LAINA='" & strDummyLaine & "',EMPLEADO='" & strDummyNumEmp & "',INSTALO='" & strDummyTec & "',ESTADO='" & strDummyState & "',VIDA='" & StrUsage & "'  WHERE RUNNING.LINEA='" + strDummyLine + "'"

                                Dim cmd6 As New System.Data.OleDb.OleDbCommand(query, conn1)
                                cmd6.ExecuteNonQuery()

                                conn1.Close()
                            End If


                            ' Graba en TOOLINES con "U" el que estas poniendo y manda a "R" el que quitaste
                            g_IntSaveGrid = 1
                            Dim accessU, accessR As String
                            accessR = "UPDATE TOOLLINES SET STATUS = 'R' where TOOLINGID='" & Encontrado6 & "'"
                            accessU = "UPDATE TOOLLINES SET STATUS = 'U' where TOOLINGID='" & strDummyTool & "'"

                            con.Open()
                            If Encontrado15 <> "D" Then
                                Dim cmd As New OleDbCommand(accessR, con)
                                cmd.ExecuteNonQuery()
                            End If

                            Dim cmdU As New OleDbCommand(accessU, con)
                            cmdU.ExecuteNonQuery()

                            con.Close()



                            g_IntSaveGrid = 0


                        End If

                        'Esta linea no hace nada, no recuerdo por que esta aqui
                        strDummyLine = strDummyLine + strDummyState + StrUsage

                    Loop

                    objReader.Close()
                Else
                    MsgBox("ruta inv�lida", MsgBoxStyle.Critical, "error")
                End If
            End With

            ' errores  
        Catch ex As Exception

            MsgBox(ex.Message.ToString, MsgBoxStyle.Critical)
            intTPA1 = 0
            intTPE1 = 0
            intTPV1 = 0
        End Try


LastLine:
    End Function

    Public Function UpdateTableFromHH(ByVal StrFileNameTbl As String) As Double 'returna el numero de minutos de downtime
        ' Procesa el archivo de ToolRepair si reparaste algun tooling
        Dim DownTimeCnnStr As String = "Provider=Microsoft.Jet.OLEDB.4.0;Data Source=C:\APP\TOOLING\Data\PINPACK.mdb;Persist Security Info=False;" 'Jet OLEDB:Database" ' Password=INGENIERIA"        
        Dim conn1 As New System.Data.OleDb.OleDbConnection(DownTimeCnnStr)
        Dim query As String
        Dim SPath As String = "c:\APP\TOOLING\DATA\ToolOK.txt"

        Dim strDummysDate, strDummysHr, strDummyLine, strDummyPrensa, strDummyArea, strDummyTurno, strDummyTool, strDummyPPAnt, strDummyPPNew, strDummGreenPlate, strDummyQtyPinD, strDummyQtyPinQ, strDummyLaine, strDummyTec, strDummyState, strDummyId, strDummyEmpRep, strDummyFechaRep As String
        strDummyId = ""
        Try
            With My.Computer.FileSystem
                ' verifica si existe el path  
                If .FileExists(StrFileNameTbl) Then
                    g_IntSaveGrid = 1

                    ' lee todo el contenido del archivo ToolRepair  
                    Dim objReader As New System.IO.StreamReader(StrFileNameTbl)
                    Do While objReader.Peek() <> -1
                        TextLine = TextLine & objReader.ReadLine()
                        TestString = TextLine
                        Dim TestArray() As String = Split(TestString, ",")
                        Dim LastNonEmpty As Integer = 0
                        For i As Integer = 0 To 1
                            If TestArray(i) <> "" Then
                                LastNonEmpty += 1
                                strDummysDate = TestArray(i)
                                strDummysHr = TestArray(i + 1)
                                strDummyLine = TestArray(i + 2)
                                strDummyPrensa = TestArray(i + 3)
                                If StrFileNameTbl = "C:\APP\TOOLING\Data\ToolRepair1.ok" Or StrFileNameTbl = "C:\APP\TOOLING\Data\ToolRepair2.ok" Then
                                    strDummyQtyPinD = TestArray(i + 5)
                                    strDummyQtyPinQ = TestArray(i + 6)
                                    strDummyEmpRep = TestArray(i + 7)
                                    strDummyFechaRep = TestArray(i + 8)
                                    strDummyFechaRep = Convert.ToDateTime(strDummyFechaRep)
                                End If
                                i = i + 1
                            End If
                            Dim Encontrado0, Encontrado1 As String
                            Dim access1 As String = "UPDATE TOOLLINES SET STATUS = 'G' where TOOLINGID='" & strDummyLine & "'" 'Entran ToolBAD y ToolOK los deja en G
                            Dim access2 As String = "UPDATE TOOLLINES SET STATUS = '" & strDummysHr & "' where TOOLINGID='" & strDummyLine & "'" 'Entran ToolBAD y ToolOK los deja en R
                            Dim cmd1 As New OleDbCommand(access1, con)
                            Dim cmd2 As New OleDbCommand(access2, con)
                            If StrFileNameTbl = "C:\APP\TOOLING\Data\ToolOK.TXT"  Then
                                con.Open()
                                cmd1.ExecuteNonQuery()
                                access1 = ""
                                TextLine = ""
                                con.Close()
                            ElseIf StrFileNameTbl = "C:\APP\TOOLING\Data\ToolBAD.txt" Then
                                con.Open()
                                cmd2.ExecuteNonQuery()
                                access2 = ""
                                TextLine = ""
                                con.Close()
                            ElseIf StrFileNameTbl = "C:\APP\TOOLING\Data\ToolRepair1.ok" Or StrFileNameTbl = "C:\APP\TOOLING\Data\ToolRepair2.ok" Then

                                '------------IDENTIFICA ULTIMO TOOLINGID INSTALADO ---
                                'Encuentra el ToolingID que se reparo con la ultima fecha del historial de toolings
                                con.Open()
                                query = "Select * FROM INFOLINES WHERE INFOLINES.TOOLINGID='" + strDummyLine + "' ORDER BY FECHA DESC, HORA DESC"
                                Dim cmd13 As New System.Data.OleDb.OleDbCommand(query, con)
                                Dim reader13 As OleDbDataReader = cmd13.ExecuteReader

                                'identifica el reporte mas reciente para ese toolingid
                                reader13.Read()
                                Encontrado0 = reader13.GetValue(0) 'trae la fecha
                                Encontrado1 = reader13.GetValue(1) 'trae la hora

                                'Por si en e futuro quieren hacer algo si hay muchos pines danados
                                If Convert.ToInt16(strDummyQtyPinD) > 5 Or Convert.ToInt16(strDummyQtyPinQ) > 5 Then
                                    ' PinesBad()
                                End If

                                'Para la tabla del historial le agrega la info de la reparacion
                                Dim access3 As String = "UPDATE INFOLINES SET ESTADO = 'G', QTYPINESDOBLADOS = '" & strDummyQtyPinD & "', REPARO = '" & strDummyEmpRep & "', FECHAREP = #" & strDummyFechaRep & "#, QTYPINESQUEBRADOS = '" & strDummyQtyPinQ & "' WHERE FECHA = #" & Encontrado0 & "# AND HORA = #" & Encontrado1 & "#"
                                Dim cmd3 As New OleDbCommand(access3, con)

                                'Crea el Log de la reparacion
                                If TestString <> vbNullString Then
                                    Using objWrtLOG As New System.IO.StreamWriter(FILE_NAME_Logger, True)
                                        objWrtLOG.WriteLine(DateAndTime.Now + " ToolRepair.ok: " + TestString)
                                        objWrtLOG.Close()
                                    End Using
                                End If
                                '-------------TERMINA DE IDENTIFICAR -----------
                                '-------------Inicia Si alguien se brinco un cambio ------------------

                                Dim queryByPass As String = "Select TOOLINGID FROM RUNNING WHERE TOOLINGID = '" + strDummyLine + "'"
                                Dim cmdByPass As New System.Data.OleDb.OleDbCommand(queryByPass, con)
                                Dim readerByPass As OleDbDataReader = cmdByPass.ExecuteReader

                                If readerByPass.HasRows Then
                                    queryByPass = "UPDATE  RUNNING SET ESTADO='" & "D" & "'  WHERE RUNNING.TOOLINGID='" + strDummyLine + "'"
                                    Dim UpdByPassCmd As New OleDbCommand(queryByPass, con)
                                    UpdByPassCmd.ExecuteNonQuery()
                                End If
                                readerByPass.Close()
                                '-------------Fin Si alguien se brinco un cambio ------------------

                                cmd1.ExecuteNonQuery()
                                cmd3.ExecuteNonQuery()
                                access2 = ""
                                TextLine = ""
                                con.Close()
                            End If




                        Next
                        ReDim Preserve TestArray(LastNonEmpty)

                    Loop


                    objReader.Close()
                    g_IntSaveGrid = 0


                Else
                    MsgBox("ruta inv�lida", MsgBoxStyle.Critical, "error")
                End If
            End With

            ' errores  
        Catch ex As Exception
            con.Close()
            MsgBox(ex.Message.ToString, MsgBoxStyle.Critical)
            intTPA1 = 0
            intTPE1 = 0
            intTPV1 = 0
        End Try

LastLine:
    End Function
    Public Sub PinesBad()

        MsgBox("se enviara un email")


    End Sub
    'OK
    Public Function ShowInfoLines(ByVal StrLine As String) As Double
        'En el click del boton de la prensa saca la info de la tabla para mostrarla en los detalles de la pantalla principal

        Dim DownTimeCnnStr As String = "Provider=Microsoft.Jet.OLEDB.4.0;Data Source=C:\APP\TOOLING\Data\PINPACK.mdb;Persist Security Info=False;"
        Dim conn1 As New System.Data.OleDb.OleDbConnection(DownTimeCnnStr)
        Dim query As String = "Select TMUERTO FROM REPORTES WHERE DEPTO='TESTING' AND (AREA ='Palomar' or AREA ='Palomar 33xx' ) and HORA_REPORTE >= #" + InicioTurno + "# AND HORA_TERMINO <= #" + FinTurno + " #"
        Dim Fecha As Date
        Dim Hora As Date
        Dim SPath As String = "c:\APP\TOOLING\DATA\"
        Dim sContent As String = vbNullString
        Dim sdir As String = "c:\Nueva carpeta"
        Dim strDummyPrensa, strDummyArea, strDummyTurno, strDummyTool, strDummyPPAnt, strDummyPPNew, strDummGreenPlate, strDummyQtyLabD, strDummyLaine, strDummyTec, strDummyState, strNumEmp As String

        Dim dbprovider As String = "Provider=Microsoft.ACE.OLEDB.12.0;Data Source=C:\Users\Taher\Documents\Visual Studio 2010\Projects\WindowsApplication1\WindowsApplication1\Database1.accdb;Persist Security Info=False;"
        Try
            conn1.Open()

            query = "Select * FROM RUNNING WHERE RUNNING.LINEA='" + StrLine + "'"
            Dim cmd3 As New System.Data.OleDb.OleDbCommand(query, conn1)
            Dim reader3 As OleDbDataReader = cmd3.ExecuteReader
            While reader3.Read()
                Fecha = reader3.GetDateTime(0)
                Hora = reader3.GetDateTime(1)
                strDummyTurno = reader3.GetString(2)
                strDummyLine = reader3.GetString(3)
                strDummyPrensa = reader3.GetString(4)
                strDummyArea = reader3.GetString(5)
                strDummyTool = reader3.GetString(6)
                strDummyPPAnt = reader3.GetString(7)
                strDummyPPNew = reader3.GetString(8)
                strDummGreenPlate = reader3.GetString(9)
                strDummyQtyLabD = reader3.GetString(10)
                strDummyLaine = reader3.GetString(11)
                strNumEmp = reader3.GetString(12)
                strDummyTec = reader3.GetString(13)
                strDummyState = reader3.GetString(14)

                EdtLine.Text = strDummyLine
                EdtPrensa.Text = strDummyPrensa
                EdtLado.Text = strDummyLine
                EdtHora.Text = Hora
                EdtFecha.Text = Fecha
                EdtTurno.Text = strDummyTurno
                EdtTooling.Text = strDummyTool
                EdtPPackAnt.Text = strDummyPPAnt
                EdtGreenPlate.Text = strDummGreenPlate
                EdtLaina.Text = strDummyLaine
                EdtTecnico.Text = strDummyTec
                EdNumEmpleado.Text = strNumEmp
                Label5.Text = strDummyState
            End While

            conn1.Close()

        Catch ex As Exception
            MsgBox(ex.Message.ToString, MsgBoxStyle.Critical)
            intTPA1 = 0
            intTPE1 = 0
            intTPV1 = 0
        End Try

LastLine:
    End Function

    Private Sub Form1_Load(ByVal eventSender As System.Object, ByVal eventArgs As System.EventArgs) Handles MyBase.Load
        'Main LOAD
        Dim FullGridAdapter As String = "Provider=Microsoft.Jet.OLEDB.4.0;Data Source=C:\APP\TOOLING\Data\PINPACK.mdb;Persist Security Info=False;" 'Jet OLEDB:Database" ' Password=INGENIERIA"        
        Dim conn1Grid As New System.Data.OleDb.OleDbConnection(FullGridAdapter)
        Dim DataSet1 As New DataSet()
        FullGridAdapter = "Provider=Microsoft.Jet.OLEDB.4.0;Data Source=C:\APP\TOOLING\Data\PINPACK.mdb;Persist Security Info=False;"
        con.ConnectionString = FullGridAdapter
        con.Open()
        Dadapter = New OleDbDataAdapter("Select [TIPO DE TOOLING], TOOLINGID, DESCRIPCION, STATUS, VIDA FROM TOOLLINES", con)
        DSet = New DataSet
        Dadapter.Fill(DSet, "TOOLLINES")
        If System.IO.File.Exists("C:\APP\TOOLING\Data\Running.txt") = True Then
            System.IO.File.Delete("C:\APP\TOOLING\Data\Running.txt")
        End If
        'Llena el Grid de Tooling
        GridTooling.DataSource = DSet.Tables("TOOLLINES").DefaultView
        con.Close()
        GetTimers() 'Vacia en variables el valor de los segundos de cada prensa, solo para el display en la pantala principal
        DBtoFile()  'Crea un archivo txt con la info de lo que se esta corriendo
        DBtoFileRead() ' Lee el archivo de texto para actualizar las demas tablas
        TimerMain.Enabled = 1
        TimerMain2.Enabled = 1
        UpdateGrid() 'Actualiza el Grid por si hubo algun cambio
        'Escribe en el Log
        objWrtLOG.WriteLine(DateAndTime.Now + " Inicaliza Aplicacion APPDIPPER")
        objWrtLOG.Close()
        DBtoFile()
    End Sub
    'OK esta solo jala para la peestana Ajustes, hay que probarla
    Public Function ReadTableStatus() As Double
        Dim DownTimeCnnStr As String = "Provider=Microsoft.Jet.OLEDB.4.0;Data Source=C:\APP\TOOLING\Data\PINPACK.mdb;Persist Security Info=False;"
        Dim conn1 As New System.Data.OleDb.OleDbConnection(DownTimeCnnStr)
        Dim query As String
        Dim SPath As String = "c:\APP\TOOLING\DATA\"
        Dim strDummyState As String = vbNullString
        Dim strDummyUsage As String = vbNullString
        
        '--------------
        DBtoFile()

        DBtoFileRead()


        Dim testLAZ As Integer = 0
        If testLAZ = 1 Then
            Try
                conn1.Open()

                query = "Select RUNNING.ESTADO, RUNNING.LINEA, RUNNING.VIDA FROM RUNNING"
                Dim cmd3 As New System.Data.OleDb.OleDbCommand(query, conn1)
                Dim reader3 As OleDbDataReader = cmd3.ExecuteReader
                Dim strEstado As String

                strEstado = "X"
                While reader3.Read()
                    strDummyState = reader3.GetString(0)
                    strDummyLine = reader3.GetString(1)
                    strDummyUsage = reader3.GetString(2)
                    strDummyLine = strDummyLine + strDummyState + strDummyUsage
                    If strDummyLine.Contains("01") Then
                        UpdateTableStatusLine1(strDummyLine)
                    End If

                    If strDummyLine.Contains("02") Then
                        UpdateTableStatusLine2(strDummyLine)
                    End If

                    If strDummyLine.Contains("03") Then
                        UpdateTableStatusLine3(strDummyLine)
                    End If

                    If strDummyLine.Contains("04") Then
                        UpdateTableStatusLine4(strDummyLine)
                    End If

                    If strDummyLine.Contains("05") Then
                        UpdateTableStatusLine5(strDummyLine)
                    End If

                    If strDummyLine.Contains("06") Then
                        UpdateTableStatusLine6(strDummyLine)
                    End If

                    If strDummyLine.Contains("07") Then
                        UpdateTableStatusLine7(strDummyLine)
                    End If

                    If strDummyLine.Contains("08") Then
                        UpdateTableStatusLine8(strDummyLine)
                    End If

                    If strDummyLine.Contains("09") Then
                        UpdateTableStatusLine9(strDummyLine)
                    End If

                    If strDummyLine.Contains("10") Then
                        UpdateTableStatusLine10(strDummyLine)
                    End If

                End While

                conn1.Close()
                ' errores  
            Catch ex As Exception
                MsgBox(ex.Message.ToString, MsgBoxStyle.Critical)
            End Try
        End If
LastLine:
    End Function

    'Lo usa la pestana Ajustes cuando deshabilitas una Linea
    Public Function UpdateTableStatusColor(ByVal StrFileNameTbl As String) As Double
        Dim DownTimeCnnStr As String = "Provider=Microsoft.Jet.OLEDB.4.0;Data Source=C:\APP\TOOLING\Data\PINPACK.mdb;Persist Security Info=False;"
        Dim conn1 As New System.Data.OleDb.OleDbConnection(DownTimeCnnStr)
        Dim query As String
        Dim SPath As String = "c:\APP\TOOLING\DATA\"
        Dim sContent As String = vbNullString
        Dim strDummyLine, strDummyState, StrTool, StrIDD As String

        strDummyLine = StrFileNameTbl.Remove(3, 1)
        strDummyState = StrFileNameTbl.Remove(0, 3)

        SPath = StrFileNameTbl
        StrIDD = ""
        StrTool = ""
        Try


            conn1.Open()
            query = "UPDATE  RUNNING SET ESTADO = '" & strDummyState & "' WHERE RUNNING.LINEA='" + strDummyLine + "'"
            Dim cmd1 As New System.Data.OleDb.OleDbCommand(query, conn1)
            cmd1.ExecuteNonQuery()
            conn1.Close()

            conn1.Open()

            query = "Select RUNNING.TOOLINGID FROM RUNNING WHERE RUNNING.LINEA='" + strDummyLine + "'"
            Dim cmd3 As New System.Data.OleDb.OleDbCommand(query, conn1)
            Dim reader3 As OleDbDataReader = cmd3.ExecuteReader
            Dim strEstado As String


            While reader3.Read()
                StrTool = reader3.GetString(0)
                ' StrIDD = reader3.GetString(1)
            End While
            conn1.Close()

            If StrTool <> "" And strDummyState = "R" Then
                '------------IDENTIFICA ULTIMO TOOLINGID INSTALADO ---
                'Encuentra el ToolingID que se reparo con la ultima fecha
                conn1.Open()
                query = "Select * FROM INFOLINES WHERE INFOLINES.TOOLINGID='" + StrTool + "' ORDER BY FECHA DESC, HORA DESC"
                Dim cmd13 As New System.Data.OleDb.OleDbCommand(query, conn1)
                Dim reader13 As OleDbDataReader = cmd13.ExecuteReader
                Dim Encontrado0, Encontrado1 As String

                'identifica el reporte mas reciente para ese toolingid
                reader13.Read()
                Encontrado0 = reader13.GetValue(0) 'trae la fecha
                Encontrado1 = reader13.GetValue(1) 'trae la hora


                Dim access3 As String = "UPDATE INFOLINES SET ESTADO = '" & strDummyState & "', QUITO = 'PorReparar' WHERE FECHA = #" & Encontrado0 & "# AND HORA = #" & Encontrado1 & "#"
                Dim cmd4 As New OleDbCommand(access3, conn1)
                cmd4.ExecuteNonQuery()
                access3 = ""
                conn1.Close()
                '-------------TERMINA DE IDENTIFICAR -----------
            End If

            'Manda el Tooling a R cuando deshabilitas la linea
            If StrFileNameTbl.Contains("R") Then

                Dim access As String
                access = "UPDATE TOOLLINES SET STATUS = 'R' where TOOLINGID='" & StrTool & "'"
                con.Open()
                Dim cmd As New OleDbCommand(access, con)
                cmd.ExecuteNonQuery()
                con.Close()
            End If

            strEstado = "X"
            strDummyLine = SPath
            If strDummyLine.Contains("01") Then
                UpdateTableStatusLine1(StrFileNameTbl)
            End If

            If strDummyLine.Contains("02") Then
                UpdateTableStatusLine2(StrFileNameTbl)
            End If

            If strDummyLine.Contains("03") Then
                UpdateTableStatusLine3(StrFileNameTbl)
            End If

            If strDummyLine.Contains("04") Then
                UpdateTableStatusLine4(StrFileNameTbl)
            End If

            If strDummyLine.Contains("05") Then
                UpdateTableStatusLine5(StrFileNameTbl)
            End If

            If strDummyLine.Contains("06") Then
                UpdateTableStatusLine6(StrFileNameTbl)
            End If

            If strDummyLine.Contains("07") Then
                UpdateTableStatusLine7(StrFileNameTbl)
            End If

            If strDummyLine.Contains("08") Then
                UpdateTableStatusLine8(StrFileNameTbl)
            End If

            If strDummyLine.Contains("09") Then
                UpdateTableStatusLine9(StrFileNameTbl)
            End If

            If strDummyLine.Contains("10") Then
                UpdateTableStatusLine10(StrFileNameTbl)
            End If
            ' errores  
        Catch ex As Exception
            MsgBox(ex.Message.ToString, MsgBoxStyle.Critical)
        End Try

        UpdateGrid()

LastLine:
    End Function

    Public Function UpdateTableStatusLine1(ByVal StrFileNameTbl As String) As Double  'Actualiza los colores de los botones
        Dim strDummyLine, strDummyState, strDummyUsage As String

        Dim charLenght As Integer
        charLenght = StrFileNameTbl.Length

        'Separa el String
        strDummyLine = StrFileNameTbl.Remove(3, charLenght - 3)
        strDummyState = Mid(StrFileNameTbl, 4, 1)
        strDummyUsage = StrFileNameTbl.Remove(0, 4)

        Try
            If StrFileNameTbl.Contains("01") Then
                If StrFileNameTbl.Contains("01A") Then
                    UsageTPA1 = Convert.ToDouble(strDummyUsage)
                    If strDummyState = "U" Or strDummyState = "G" Then
                        LPA1.BackColor = Color.Green
                        Ajustes.L01A.BackColor = Color.Green
                    End If
                    If strDummyState = "Y" Then
                        LPA1.BackColor = Color.Yellow
                        Ajustes.L01A.BackColor = Color.Yellow
                    End If
                    If strDummyState = "R" Then
                        LPA1.BackColor = Color.Red
                        Ajustes.L01A.BackColor = Color.Red
                        PA1T.ForeColor = Color.White
                    End If
                    If strDummyState = "D" Then
                        LPA1.BackColor = Color.Blue
                        Ajustes.L01A.BackColor = Color.Blue
                    End If
                End If
                If StrFileNameTbl.Contains("01E") Then
                    UsageTPE1 = Convert.ToDouble(strDummyUsage)
                    If strDummyState = "U" Or strDummyState = "G" Then
                        LPE1.BackColor = Color.Green
                        Ajustes.L01E.BackColor = Color.Green
                    End If
                    If strDummyState = "Y" Then
                        LPE1.BackColor = Color.Yellow
                        Ajustes.L01E.BackColor = Color.Yellow
                    End If
                    If strDummyState = "R" Then
                        LPE1.BackColor = Color.Red
                        Ajustes.L01E.BackColor = Color.Red
                        PE1T.ForeColor = Color.White
                    End If
                    If strDummyState = "D" Then
                        LPE1.BackColor = Color.Blue
                        Ajustes.L01E.BackColor = Color.Blue
                    End If
                End If

                If StrFileNameTbl.Contains("01V") Then
                    UsageTPV1 = Convert.ToDouble(strDummyUsage)
                    If strDummyState = "U" Or strDummyState = "G" Then
                        LPV1.BackColor = Color.Green
                        Ajustes.L01V.BackColor = Color.Green
                    End If
                    If strDummyState = "Y" Then
                        LPV1.BackColor = Color.Yellow
                        Ajustes.L01V.BackColor = Color.Yellow
                    End If
                    If strDummyState = "R" Then
                        LPV1.BackColor = Color.Red
                        Ajustes.L01V.BackColor = Color.Red
                        PV1T.ForeColor = Color.White
                    End If
                    If strDummyState = "D" Then
                        LPV1.BackColor = Color.Blue
                        Ajustes.L01V.BackColor = Color.Blue
                    End If
                End If
            End If
            ' errores  
        Catch ex As Exception
            MsgBox(ex.Message.ToString, MsgBoxStyle.Critical)
        End Try

LastLine:
    End Function
    Public Function UpdateTableStatusLine2(ByVal StrFileNameTbl As String) As Double  'Actualiza los colores de los botones
        Dim strDummyLine, strDummyState, strDummyUsage As String

        Dim charLenght As Integer
        charLenght = StrFileNameTbl.Length


        strDummyLine = StrFileNameTbl.Remove(3, charLenght - 3)
        strDummyState = Mid(StrFileNameTbl, 4, 1)
        strDummyUsage = StrFileNameTbl.Remove(0, 4)

        Try
            If StrFileNameTbl.Contains("02") Then
                If StrFileNameTbl.Contains("02A") Then
                    UsageTPA2 = Convert.ToDouble(strDummyUsage)
                    If strDummyState = "U" Or strDummyState = "G" Then
                        LPA2.BackColor = Color.Green
                        Ajustes.L02A.BackColor = Color.Green
                    End If
                    If strDummyState = "Y" Then
                        LPA2.BackColor = Color.Yellow
                        Ajustes.L02A.BackColor = Color.Yellow
                    End If
                    If strDummyState = "R" Then
                        LPA2.BackColor = Color.Red
                        Ajustes.L02A.BackColor = Color.Red
                        PA2T.ForeColor = Color.White
                    End If
                    If strDummyState = "D" Then
                        LPA2.BackColor = Color.Blue
                        Ajustes.L02A.BackColor = Color.Blue
                    End If
                End If
                If StrFileNameTbl.Contains("02E") Then
                    UsageTPE2 = Convert.ToDouble(strDummyUsage)
                    If strDummyState = "U" Or strDummyState = "G" Then
                        LPE2.BackColor = Color.Green
                        Ajustes.L02E.BackColor = Color.Green
                    End If
                    If strDummyState = "Y" Then
                        LPE2.BackColor = Color.Yellow
                        Ajustes.L02E.BackColor = Color.Yellow
                    End If
                    If strDummyState = "R" Then
                        LPE2.BackColor = Color.Red
                        Ajustes.L02E.BackColor = Color.Red
                        PE2T.ForeColor = Color.White
                    End If
                    If strDummyState = "D" Then
                        LPE2.BackColor = Color.Blue
                        Ajustes.L02E.BackColor = Color.Blue
                    End If
                End If

                If StrFileNameTbl.Contains("02V") Then
                    UsageTPV2 = Convert.ToDouble(strDummyUsage)
                    If strDummyState = "U" Or strDummyState = "G" Then
                        LPV2.BackColor = Color.Green
                        Ajustes.L02V.BackColor = Color.Green
                    End If
                    If strDummyState = "Y" Then
                        LPV2.BackColor = Color.Yellow
                        Ajustes.L02V.BackColor = Color.Yellow
                    End If
                    If strDummyState = "R" Then
                        LPV2.BackColor = Color.Red
                        Ajustes.L02V.BackColor = Color.Red
                        PV2T.ForeColor = Color.White
                    End If
                    If strDummyState = "D" Then
                        LPV2.BackColor = Color.Blue
                        Ajustes.L02V.BackColor = Color.Blue
                    End If
                End If
            End If
            ' errores  
        Catch ex As Exception
            MsgBox(ex.Message.ToString, MsgBoxStyle.Critical)
        End Try

LastLine:
    End Function
    Public Function UpdateTableStatusLine3(ByVal StrFileNameTbl As String) As Double  'Actualiza los colores de los botones
        Dim strDummyLine, strDummyState, strDummyUsage As String

        Dim charLenght As Integer
        charLenght = StrFileNameTbl.Length


        strDummyLine = StrFileNameTbl.Remove(3, charLenght - 3)
        strDummyState = Mid(StrFileNameTbl, 4, 1)
        strDummyUsage = StrFileNameTbl.Remove(0, 4)

        Try
            If StrFileNameTbl.Contains("03") Then
                If StrFileNameTbl.Contains("03A") Then
                    UsageTPA3 = Convert.ToDouble(strDummyUsage)
                    If strDummyState = "U" Or strDummyState = "G" Then
                        LPA3.BackColor = Color.Green
                        Ajustes.L03A.BackColor = Color.Green
                    End If
                    If strDummyState = "Y" Then
                        LPA3.BackColor = Color.Yellow
                        Ajustes.L03A.BackColor = Color.Yellow
                    End If
                    If strDummyState = "R" Then
                        LPA3.BackColor = Color.Red
                        Ajustes.L03A.BackColor = Color.Red
                        PA3T.ForeColor = Color.White
                    End If
                    If strDummyState = "D" Then
                        LPA3.BackColor = Color.Blue
                        Ajustes.L03A.BackColor = Color.Blue
                    End If
                End If
                If StrFileNameTbl.Contains("03E") Then
                    UsageTPE3 = Convert.ToDouble(strDummyUsage)
                    If strDummyState = "U" Or strDummyState = "G" Then
                        LPE3.BackColor = Color.Green
                        Ajustes.L03E.BackColor = Color.Green
                    End If
                    If strDummyState = "Y" Then
                        LPE3.BackColor = Color.Yellow
                        Ajustes.L03E.BackColor = Color.Yellow
                    End If
                    If strDummyState = "R" Then
                        LPE3.BackColor = Color.Red
                        Ajustes.L03E.BackColor = Color.Red
                        PE3T.ForeColor = Color.White
                    End If
                    If strDummyState = "D" Then
                        LPE3.BackColor = Color.Blue
                        Ajustes.L03E.BackColor = Color.Blue
                    End If
                End If

                If StrFileNameTbl.Contains("03V") Then
                    UsageTPV3 = Convert.ToDouble(strDummyUsage)
                    If strDummyState = "U" Or strDummyState = "G" Then
                        LPV3.BackColor = Color.Green
                        Ajustes.L03V.BackColor = Color.Green
                    End If
                    If strDummyState = "Y" Then
                        LPV3.BackColor = Color.Yellow
                        Ajustes.L03V.BackColor = Color.Yellow
                    End If
                    If strDummyState = "R" Then
                        LPV3.BackColor = Color.Red
                        Ajustes.L03V.BackColor = Color.Red
                        PV3T.ForeColor = Color.White
                    End If
                    If strDummyState = "D" Then
                        LPV3.BackColor = Color.Blue
                        Ajustes.L03V.BackColor = Color.Blue
                    End If
                End If
            End If
            ' errores  
        Catch ex As Exception
            MsgBox(ex.Message.ToString, MsgBoxStyle.Critical)
        End Try

LastLine:
    End Function
    Public Function UpdateTableStatusLine4(ByVal StrFileNameTbl As String) As Double  'Actualiza los colores de los botones
        Dim strDummyLine, strDummyState, strDummyUsage As String

        Dim charLenght As Integer
        charLenght = StrFileNameTbl.Length

        strDummyLine = StrFileNameTbl.Remove(3, charLenght - 3)
        strDummyState = Mid(StrFileNameTbl, 4, 1)
        strDummyUsage = StrFileNameTbl.Remove(0, 4)

        Try
            If StrFileNameTbl.Contains("04") Then
                If StrFileNameTbl.Contains("04A") Then
                    UsageTPA4 = Convert.ToDouble(strDummyUsage)
                    If strDummyState = "U" Or strDummyState = "G" Then
                        LPA4.BackColor = Color.Green
                        Ajustes.L04A.BackColor = Color.Green
                    End If
                    If strDummyState = "Y" Then
                        LPA4.BackColor = Color.Yellow
                        Ajustes.L04A.BackColor = Color.Yellow
                    End If
                    If strDummyState = "R" Then
                        LPA4.BackColor = Color.Red
                        Ajustes.L04A.BackColor = Color.Red
                        PA4T.ForeColor = Color.White
                    End If
                    If strDummyState = "D" Then
                        LPA4.BackColor = Color.Blue
                        Ajustes.L04A.BackColor = Color.Blue
                    End If
                End If
                If StrFileNameTbl.Contains("04E") Then
                    UsageTPE4 = Convert.ToDouble(strDummyUsage)
                    If strDummyState = "U" Or strDummyState = "G" Then
                        LPE4.BackColor = Color.Green
                        Ajustes.L04E.BackColor = Color.Green
                    End If
                    If strDummyState = "Y" Then
                        LPE4.BackColor = Color.Yellow
                        Ajustes.L04E.BackColor = Color.Yellow
                    End If
                    If strDummyState = "R" Then
                        LPE4.BackColor = Color.Red
                        Ajustes.L04E.BackColor = Color.Red
                        PE4T.ForeColor = Color.White
                    End If
                    If strDummyState = "D" Then
                        LPE4.BackColor = Color.Blue
                        Ajustes.L04E.BackColor = Color.Blue
                    End If
                End If

                If StrFileNameTbl.Contains("04V") Then
                    UsageTPV4 = Convert.ToDouble(strDummyUsage)
                    If strDummyState = "U" Or strDummyState = "G" Then
                        LPV4.BackColor = Color.Green
                        Ajustes.L04V.BackColor = Color.Green
                    End If
                    If strDummyState = "Y" Then
                        LPV4.BackColor = Color.Yellow
                        Ajustes.L04V.BackColor = Color.Yellow
                    End If
                    If strDummyState = "R" Then
                        LPV4.BackColor = Color.Red
                        Ajustes.L04V.BackColor = Color.Red
                        PV4T.ForeColor = Color.White
                    End If
                    If strDummyState = "D" Then
                        LPV4.BackColor = Color.Blue
                        Ajustes.L04V.BackColor = Color.Blue
                    End If
                End If
            End If
            ' errores  
        Catch ex As Exception
            MsgBox(ex.Message.ToString, MsgBoxStyle.Critical)
        End Try

LastLine:
    End Function
    Public Function UpdateTableStatusLine5(ByVal StrFileNameTbl As String) As Double  'Actualiza los colores de los botones
        Dim strDummyLine, strDummyState, strDummyUsage As String

        Dim charLenght As Integer
        charLenght = StrFileNameTbl.Length

        strDummyLine = StrFileNameTbl.Remove(3, charLenght - 3)
        strDummyState = Mid(StrFileNameTbl, 4, 1)
        strDummyUsage = StrFileNameTbl.Remove(0, 4)

        Try
            If StrFileNameTbl.Contains("05") Then
                If StrFileNameTbl.Contains("05A") Then
                    UsageTPA5 = Convert.ToDouble(strDummyUsage)
                    If strDummyState = "U" Or strDummyState = "G" Then
                        LPA5.BackColor = Color.Green
                        Ajustes.L05A.BackColor = Color.Green
                    End If
                    If strDummyState = "Y" Then
                        LPA5.BackColor = Color.Yellow
                        Ajustes.L05A.BackColor = Color.Yellow
                    End If
                    If strDummyState = "R" Then
                        LPA5.BackColor = Color.Red
                        Ajustes.L05A.BackColor = Color.Red
                        PA5T.ForeColor = Color.White
                    End If
                    If strDummyState = "D" Then
                        LPA5.BackColor = Color.Blue
                        Ajustes.L05A.BackColor = Color.Blue
                    End If
                End If
                If StrFileNameTbl.Contains("05E") Then
                    UsageTPE5 = Convert.ToDouble(strDummyUsage)
                    If strDummyState = "U" Or strDummyState = "G" Then
                        LPE5.BackColor = Color.Green
                        Ajustes.L05E.BackColor = Color.Green
                    End If
                    If strDummyState = "Y" Then
                        LPE5.BackColor = Color.Yellow
                        Ajustes.L05E.BackColor = Color.Yellow
                    End If
                    If strDummyState = "R" Then
                        LPE5.BackColor = Color.Red
                        Ajustes.L05E.BackColor = Color.Red
                        PE5T.ForeColor = Color.White
                    End If
                    If strDummyState = "D" Then
                        LPE5.BackColor = Color.Blue
                        Ajustes.L05E.BackColor = Color.Blue
                    End If
                End If

                If StrFileNameTbl.Contains("05V") Then
                    UsageTPV5 = Convert.ToDouble(strDummyUsage)
                    If strDummyState = "U" Or strDummyState = "G" Then
                        LPV5.BackColor = Color.Green
                        Ajustes.L05V.BackColor = Color.Green
                    End If
                    If strDummyState = "Y" Then
                        LPV5.BackColor = Color.Yellow
                        Ajustes.L05V.BackColor = Color.Yellow
                    End If
                    If strDummyState = "R" Then
                        LPV5.BackColor = Color.Red
                        Ajustes.L05V.BackColor = Color.Red
                        PV5T.ForeColor = Color.White
                    End If
                    If strDummyState = "D" Then
                        LPV5.BackColor = Color.Blue
                        Ajustes.L05V.BackColor = Color.Blue
                    End If
                End If
            End If
            ' errores  
        Catch ex As Exception
            MsgBox(ex.Message.ToString, MsgBoxStyle.Critical)
        End Try

LastLine:
    End Function
    Public Function UpdateTableStatusLine6(ByVal StrFileNameTbl As String) As Double  'Actualiza los colores de los botones
        Dim strDummyLine, strDummyState, strDummyUsage As String

        Dim charLenght As Integer
        charLenght = StrFileNameTbl.Length

        strDummyLine = StrFileNameTbl.Remove(3, charLenght - 3)
        strDummyState = Mid(StrFileNameTbl, 4, 1)
        strDummyUsage = StrFileNameTbl.Remove(0, 4)

        Try
            If StrFileNameTbl.Contains("06") Then
                If StrFileNameTbl.Contains("06A") Then
                    UsageTPA6 = Convert.ToDouble(strDummyUsage)
                    If strDummyState = "U" Or strDummyState = "G" Then
                        LPA6.BackColor = Color.Green
                        Ajustes.L06A.BackColor = Color.Green
                    End If
                    If strDummyState = "Y" Then
                        LPA6.BackColor = Color.Yellow
                        Ajustes.L06A.BackColor = Color.Yellow
                    End If
                    If strDummyState = "R" Then
                        LPA6.BackColor = Color.Red
                        Ajustes.L06A.BackColor = Color.Red
                        PA6T.ForeColor = Color.White
                    End If
                    If strDummyState = "D" Then
                        LPA6.BackColor = Color.Blue
                        Ajustes.L06A.BackColor = Color.Blue
                    End If
                End If
                If StrFileNameTbl.Contains("06E") Then
                    UsageTPE6 = Convert.ToDouble(strDummyUsage)
                    If strDummyState = "U" Or strDummyState = "G" Then
                        LPE6.BackColor = Color.Green
                        Ajustes.L06E.BackColor = Color.Green
                    End If
                    If strDummyState = "Y" Then
                        LPE6.BackColor = Color.Yellow
                        Ajustes.L06E.BackColor = Color.Yellow
                    End If
                    If strDummyState = "R" Then
                        LPE6.BackColor = Color.Red
                        Ajustes.L06E.BackColor = Color.Red
                        PE6T.ForeColor = Color.White
                    End If
                    If strDummyState = "D" Then
                        LPE6.BackColor = Color.Blue
                        Ajustes.L06E.BackColor = Color.Blue
                    End If
                End If

                If StrFileNameTbl.Contains("06V") Then
                    UsageTPV6 = Convert.ToDouble(strDummyUsage)
                    If strDummyState = "U" Or strDummyState = "G" Then
                        LPV6.BackColor = Color.Green
                        Ajustes.L06V.BackColor = Color.Green
                    End If
                    If strDummyState = "Y" Then
                        LPV6.BackColor = Color.Yellow
                        Ajustes.L06V.BackColor = Color.Yellow
                    End If
                    If strDummyState = "R" Then
                        LPV6.BackColor = Color.Red
                        Ajustes.L06V.BackColor = Color.Red
                        PV6T.ForeColor = Color.White
                    End If
                    If strDummyState = "D" Then
                        LPV6.BackColor = Color.Blue
                        Ajustes.L06V.BackColor = Color.Blue
                    End If
                End If
            End If
            ' errores  
        Catch ex As Exception
            MsgBox(ex.Message.ToString, MsgBoxStyle.Critical)
        End Try

LastLine:
    End Function
    Public Function UpdateTableStatusLine7(ByVal StrFileNameTbl As String) As Double  'Actualiza los colores de los botones
        Dim strDummyLine, strDummyState, strDummyUsage As String

        Dim charLenght As Integer
        charLenght = StrFileNameTbl.Length

        strDummyLine = StrFileNameTbl.Remove(3, charLenght - 3)
        strDummyState = Mid(StrFileNameTbl, 4, 1)
        strDummyUsage = StrFileNameTbl.Remove(0, 4)

        Try
            If StrFileNameTbl.Contains("07") Then
                If StrFileNameTbl.Contains("07A") Then
                    UsageTPA7 = Convert.ToDouble(strDummyUsage)
                    If strDummyState = "U" Or strDummyState = "G" Then
                        LPA7.BackColor = Color.Green
                        Ajustes.L07A.BackColor = Color.Green
                    End If
                    If strDummyState = "Y" Then
                        LPA7.BackColor = Color.Yellow
                        Ajustes.L07A.BackColor = Color.Yellow
                    End If
                    If strDummyState = "R" Then
                        LPA7.BackColor = Color.Red
                        Ajustes.L07A.BackColor = Color.Red
                        PA7T.ForeColor = Color.White
                    End If
                    If strDummyState = "D" Then
                        LPA7.BackColor = Color.Blue
                        Ajustes.L07A.BackColor = Color.Blue
                    End If
                End If
                If StrFileNameTbl.Contains("07E") Then
                    UsageTPE7 = Convert.ToDouble(strDummyUsage)
                    If strDummyState = "U" Or strDummyState = "G" Then
                        LPE7.BackColor = Color.Green
                        Ajustes.L07E.BackColor = Color.Green
                    End If
                    If strDummyState = "Y" Then
                        LPE7.BackColor = Color.Yellow
                        Ajustes.L07E.BackColor = Color.Yellow
                    End If
                    If strDummyState = "R" Then
                        LPE7.BackColor = Color.Red
                        Ajustes.L07E.BackColor = Color.Red
                        PE7T.ForeColor = Color.White
                    End If
                    If strDummyState = "D" Then
                        LPE7.BackColor = Color.Blue
                        Ajustes.L07E.BackColor = Color.Blue
                    End If
                End If

                If StrFileNameTbl.Contains("07V") Then
                    UsageTPV7 = Convert.ToDouble(strDummyUsage)
                    If strDummyState = "U" Or strDummyState = "G" Then
                        LPV7.BackColor = Color.Green
                        Ajustes.L07V.BackColor = Color.Green
                    End If
                    If strDummyState = "Y" Then
                        LPV7.BackColor = Color.Yellow
                        Ajustes.L07V.BackColor = Color.Yellow
                    End If
                    If strDummyState = "R" Then
                        LPV7.BackColor = Color.Red
                        Ajustes.L07V.BackColor = Color.Red
                        PV7T.ForeColor = Color.White
                    End If
                    If strDummyState = "D" Then
                        LPV7.BackColor = Color.Blue
                        Ajustes.L07V.BackColor = Color.Blue
                    End If
                End If
            End If
            ' errores  
        Catch ex As Exception
            MsgBox(ex.Message.ToString, MsgBoxStyle.Critical)
        End Try

LastLine:
    End Function

    Public Function UpdateTableStatusLine8(ByVal StrFileNameTbl As String) As Double  'Actualiza los colores de los botones
        Dim strDummyLine, strDummyState, strDummyUsage As String

        Dim charLenght As Integer
        charLenght = StrFileNameTbl.Length

        strDummyLine = StrFileNameTbl.Remove(3, charLenght - 3)
        strDummyState = Mid(StrFileNameTbl, 4, 1)
        strDummyUsage = StrFileNameTbl.Remove(0, 4)

        Try
            If StrFileNameTbl.Contains("08") Then
                If StrFileNameTbl.Contains("08A") Then
                    UsageTPA8 = Convert.ToDouble(strDummyUsage)
                    If strDummyState = "U" Or strDummyState = "G" Then
                        LPA8.BackColor = Color.Green
                        Ajustes.L08A.BackColor = Color.Green
                    End If
                    If strDummyState = "Y" Then
                        LPA8.BackColor = Color.Yellow
                        Ajustes.L08A.BackColor = Color.Yellow
                    End If
                    If strDummyState = "R" Then
                        LPA8.BackColor = Color.Red
                        Ajustes.L08A.BackColor = Color.Red
                        PA8T.ForeColor = Color.White
                    End If
                    If strDummyState = "D" Then
                        LPA8.BackColor = Color.Blue
                        Ajustes.L08A.BackColor = Color.Blue
                    End If
                End If
                If StrFileNameTbl.Contains("08E") Then
                    UsageTPE8 = Convert.ToDouble(strDummyUsage)
                    If strDummyState = "U" Or strDummyState = "G" Then
                        LPE8.BackColor = Color.Green
                        Ajustes.L08E.BackColor = Color.Green
                    End If
                    If strDummyState = "Y" Then
                        LPE8.BackColor = Color.Yellow
                        Ajustes.L08E.BackColor = Color.Yellow
                    End If
                    If strDummyState = "R" Then
                        LPE8.BackColor = Color.Red
                        Ajustes.L08E.BackColor = Color.Red
                        PE8T.ForeColor = Color.White
                    End If
                    If strDummyState = "D" Then
                        LPE8.BackColor = Color.Blue
                        Ajustes.L08E.BackColor = Color.Blue
                    End If
                End If

                If StrFileNameTbl.Contains("08V") Then
                    UsageTPV8 = Convert.ToDouble(strDummyUsage)
                    If strDummyState = "U" Or strDummyState = "G" Then
                        LPV8.BackColor = Color.Green
                        Ajustes.L08V.BackColor = Color.Green
                    End If
                    If strDummyState = "Y" Then
                        LPV8.BackColor = Color.Yellow
                        Ajustes.L08V.BackColor = Color.Yellow
                    End If
                    If strDummyState = "R" Then
                        LPV8.BackColor = Color.Red
                        Ajustes.L08V.BackColor = Color.Red
                        PV8T.ForeColor = Color.White
                    End If
                    If strDummyState = "D" Then
                        LPV8.BackColor = Color.Blue
                        Ajustes.L08V.BackColor = Color.Blue
                    End If
                End If
            End If
            ' errores  
        Catch ex As Exception
            MsgBox(ex.Message.ToString, MsgBoxStyle.Critical)
        End Try

LastLine:
    End Function
    Public Function UpdateTableStatusLine9(ByVal StrFileNameTbl As String) As Double  'Actualiza los colores de los botones
        Dim strDummyLine, strDummyState, strDummyUsage As String

        Dim charLenght As Integer
        charLenght = StrFileNameTbl.Length

        strDummyLine = StrFileNameTbl.Remove(3, charLenght - 3)
        strDummyState = Mid(StrFileNameTbl, 4, 1)
        strDummyUsage = StrFileNameTbl.Remove(0, 4)

        Try
            If StrFileNameTbl.Contains("09") Then
                If StrFileNameTbl.Contains("09A") Then
                    UsageTPA9 = Convert.ToDouble(strDummyUsage)
                    If strDummyState = "U" Or strDummyState = "G" Then
                        LPA9.BackColor = Color.Green
                        Ajustes.L09A.BackColor = Color.Green
                    End If
                    If strDummyState = "Y" Then
                        LPA9.BackColor = Color.Yellow
                        Ajustes.L09A.BackColor = Color.Yellow
                    End If
                    If strDummyState = "R" Then
                        LPA9.BackColor = Color.Red
                        Ajustes.L09A.BackColor = Color.Red
                        PA9T.ForeColor = Color.White
                    End If
                    If strDummyState = "D" Then
                        LPA9.BackColor = Color.Blue
                        Ajustes.L09A.BackColor = Color.Blue
                    End If
                End If
                If StrFileNameTbl.Contains("09E") Then
                    UsageTPE9 = Convert.ToDouble(strDummyUsage)
                    If strDummyState = "U" Or strDummyState = "G" Then
                        LPE9.BackColor = Color.Green
                        Ajustes.L09E.BackColor = Color.Green
                    End If
                    If strDummyState = "Y" Then
                        LPE9.BackColor = Color.Yellow
                        Ajustes.L09E.BackColor = Color.Yellow
                    End If
                    If strDummyState = "R" Then
                        LPE9.BackColor = Color.Red
                        Ajustes.L09E.BackColor = Color.Red
                        PE9T.ForeColor = Color.White
                    End If
                    If strDummyState = "D" Then
                        LPE9.BackColor = Color.Blue
                        Ajustes.L09E.BackColor = Color.Blue
                    End If
                End If

                If StrFileNameTbl.Contains("09V") Then
                    UsageTPV9 = Convert.ToDouble(strDummyUsage)
                    If strDummyState = "U" Or strDummyState = "G" Then
                        LPV9.BackColor = Color.Green
                        Ajustes.L09V.BackColor = Color.Green
                    End If
                    If strDummyState = "Y" Then
                        LPV9.BackColor = Color.Yellow
                        Ajustes.L09V.BackColor = Color.Yellow
                    End If
                    If strDummyState = "R" Then
                        LPV9.BackColor = Color.Red
                        Ajustes.L09V.BackColor = Color.Red
                        PV9T.ForeColor = Color.White
                    End If
                    If strDummyState = "D" Then
                        LPV9.BackColor = Color.Blue
                        Ajustes.L09V.BackColor = Color.Blue
                    End If
                End If
            End If
            ' errores  
        Catch ex As Exception
            MsgBox(ex.Message.ToString, MsgBoxStyle.Critical)
        End Try

LastLine:
    End Function

    Public Function UpdateTableStatusLine10(ByVal StrFileNameTbl As String) As Double  'Actualiza los colores de los botones
        Dim strDummyLine, strDummyState, strDummyUsage As String

        Dim charLenght As Integer
        charLenght = StrFileNameTbl.Length

        strDummyLine = StrFileNameTbl.Remove(3, charLenght - 3)
        strDummyState = Mid(StrFileNameTbl, 4, 1)
        strDummyUsage = StrFileNameTbl.Remove(0, 4)

        Try
            If StrFileNameTbl.Contains("10") Then
                If StrFileNameTbl.Contains("10A") Then
                    UsageTPA10 = Convert.ToDouble(strDummyUsage)
                    If strDummyState = "U" Or strDummyState = "G" Then
                        LPA10.BackColor = Color.Green
                        Ajustes.L10A.BackColor = Color.Green
                    End If
                    If strDummyState = "Y" Then
                        LPA10.BackColor = Color.Yellow
                        Ajustes.L10A.BackColor = Color.Yellow
                    End If
                    If strDummyState = "R" Then
                        LPA10.BackColor = Color.Red
                        Ajustes.L10A.BackColor = Color.Red
                        PA10T.ForeColor = Color.White
                    End If
                    If strDummyState = "D" Then
                        LPA10.BackColor = Color.Blue
                        Ajustes.L10A.BackColor = Color.Blue
                    End If
                End If
                If StrFileNameTbl.Contains("10E") Then
                    UsageTPE10 = Convert.ToDouble(strDummyUsage)
                    If strDummyState = "U" Or strDummyState = "G" Then
                        LPE10.BackColor = Color.Green
                        Ajustes.L10E.BackColor = Color.Green
                    End If
                    If strDummyState = "Y" Then
                        LPE10.BackColor = Color.Yellow
                        Ajustes.L10E.BackColor = Color.Yellow
                    End If
                    If strDummyState = "R" Then
                        LPE10.BackColor = Color.Red
                        Ajustes.L10E.BackColor = Color.Red
                        PE10T.ForeColor = Color.White
                    End If
                    If strDummyState = "D" Then
                        LPE10.BackColor = Color.Blue
                        Ajustes.L10E.BackColor = Color.Blue
                    End If
                End If

                If StrFileNameTbl.Contains("10V") Then
                    UsageTPV10 = Convert.ToDouble(strDummyUsage)
                    If strDummyState = "U" Or strDummyState = "G" Then
                        LPV10.BackColor = Color.Green
                        Ajustes.L10V.BackColor = Color.Green
                    End If
                    If strDummyState = "Y" Then
                        LPV10.BackColor = Color.Yellow
                        Ajustes.L10V.BackColor = Color.Yellow
                    End If
                    If strDummyState = "R" Then
                        LPV10.BackColor = Color.Red
                        Ajustes.L10V.BackColor = Color.Red
                        PV10T.ForeColor = Color.White
                    End If
                    If strDummyState = "D" Then
                        LPV10.BackColor = Color.Blue
                        Ajustes.L10V.BackColor = Color.Blue
                    End If
                End If
            End If
            ' errores  
        Catch ex As Exception
            MsgBox(ex.Message.ToString, MsgBoxStyle.Critical)
        End Try

LastLine:
    End Function

    Public Function CreateBadTooling() As Integer
        'crea el archivo TXT los Tooling malos en la tabla 

        Dim DownTimeCnnStr As String = "Provider=Microsoft.Jet.OLEDB.4.0;Data Source=C:\APP\TOOLING\Data\PINPACK.mdb;Persist Security Info=False;"
        Dim conn1 As New System.Data.OleDb.OleDbConnection(DownTimeCnnStr)
        Dim SPath As String = "c:\APP\TOOLING\DATA\"
        Dim sContent As String = vbNullString
        Dim dt As New DataTable
        Dim DataSet1 As New DataSet()
        Dim StrTIpTool1 As String
        Dim StrId1 As String
        Dim StrDesc1 As String
        Dim StrTool1 As String
        Dim StrDummy As String
        Dim StUsage As String

        'declara el ToolBad.txt
        Dim FILE_NAME_ToolBAD As String = "C:\APP\TOOLING\Data\ToolBAD.txt"

        'Declara la bandera que usara el Cominuca
        '  Dim FILE_NAME_ToolBADflag As String = "C:\APP\TOOLING\Data\ToolBADflag.txt"

        System.IO.File.Delete(FILE_NAME_ToolBAD)
        Try

            Dim access As String
            access = "Select * FROM TOOLLINES WHERE TOOLLINES.STATUS= 'R' or TOOLLINES.STATUS= 'U'"

            conn1.Open()
            Dim cmd2 As New System.Data.OleDb.OleDbCommand(access, conn1)
            Dim reader2 As OleDbDataReader = cmd2.ExecuteReader


            If System.IO.File.Exists(FILE_NAME_ToolBAD) = False Then
                System.IO.File.Create(FILE_NAME_ToolBAD).Dispose()
            End If
            Dim objWrtToolBAD As New System.IO.StreamWriter(FILE_NAME_ToolBAD, True)

            'Lee toda la tabla con los R y U crea el archivo de texto
            While reader2.Read()
                StrTIpTool1 = reader2.GetString(2)
                StrId1 = reader2.GetString(3)
                StrDesc1 = reader2.GetString(4)
                StrTool1 = reader2.GetString(5)
                StUsage = reader2.GetString(6)
                StrDummy = StrTIpTool1 + "," + StrTool1 + "," + StrId1 + "," + StrDesc1 + "," + StUsage
                objWrtToolBAD.WriteLine(StrDummy) 'create status R to ToolBAD.TXT
            End While
            objWrtToolBAD.Close()

            conn1.Close()

        Catch ex As Exception
            MsgBox(ex.Message.ToString, MsgBoxStyle.Critical)
            intTPA1 = 0
            intTPE1 = 0
            intTPV1 = 0
        End Try

        'Este flag es solo para el cominuca
        ' Dim objWrtToolBADflag As New System.IO.StreamWriter(FILE_NAME_ToolBADflag, True)
        ' objWrtToolBADflag.WriteLine("Created ToolBad.txt")
        ' objWrtToolBADflag.Close()


    End Function

    Public Function CreateGoodTooling() As Integer
        'crea el archivo TXT los Tooling buenos en la tabla 

        Dim DownTimeCnnStr As String = "Provider=Microsoft.Jet.OLEDB.4.0;Data Source=C:\APP\TOOLING\Data\PINPACK.mdb;Persist Security Info=False;" 'Jet OLEDB:Database" ' Password=INGENIERIA"        
        Dim conn1 As New System.Data.OleDb.OleDbConnection(DownTimeCnnStr)
        Dim SPath As String = "c:\APP\TOOLING\DATA\"
        Dim sContent As String = vbNullString
        Dim dt As New DataTable
        Dim DataSet1 As New DataSet()
        Dim StrTIpTool1 As String
        Dim StrId1 As String
        Dim StrDesc1 As String
        Dim StrTool1 As String
        Dim StrDummy As String
        Dim StUsage As String

        
        'Declara el archivo de texto de los buenos
        Dim FILE_NAME_ToolOK As String = "C:\APP\TOOLING\Data\ToolOK.TXT"

        'Declara la bandera que usara el Comunica
        '      Dim FILE_NAME_ToolOKflag As String = "C:\APP\TOOLING\Data\ToolOKflag.txt"
        System.IO.File.Delete(FILE_NAME_ToolOK)
        Try

            Dim access As String
            access = "Select * FROM TOOLLINES WHERE TOOLLINES.STATUS= 'G'"

            conn1.Open()
            Dim cmd2 As New System.Data.OleDb.OleDbCommand(access, conn1)
            Dim reader2 As OleDbDataReader = cmd2.ExecuteReader


            If System.IO.File.Exists(FILE_NAME_ToolOK) = False Then
                System.IO.File.Create(FILE_NAME_ToolOK).Dispose()
            End If
            Dim objWrtToolOK As New System.IO.StreamWriter(FILE_NAME_ToolOK, True)

            'Lee toda la tabla con los G y crea el archivo de texto
            While reader2.Read()
                StrTIpTool1 = reader2.GetString(2)
                StrId1 = reader2.GetString(3)
                StrDesc1 = reader2.GetString(4)
                StrTool1 = reader2.GetString(5)
                StUsage = reader2.GetString(6)
                StrDummy = StrTIpTool1 + "," + StrTool1 + "," + StrId1 + "," + StrDesc1 + "," + StUsage
                objWrtToolOK.WriteLine(StrDummy) 'Writes status G from table to ToolOK.txt
            End While
            objWrtToolOK.Close()

            conn1.Close()

        Catch ex As Exception
            MsgBox(ex.Message.ToString, MsgBoxStyle.Critical)
            intTPA1 = 0
            intTPE1 = 0
            intTPV1 = 0
        End Try

        'Este flag es solo para el cominuca
        'Dim objWrtToolOKflag As New System.IO.StreamWriter(FILE_NAME_ToolOKflag, True)
        'objWrtToolOKflag.WriteLine("Created ToolOK.txt")
        'objWrtToolOKflag.Close()

    End Function

    Public Function CreateBadTooling2() As Integer
        'crea el archivo TXT los Tooling malos en la tabla 

        Dim DownTimeCnnStr As String = "Provider=Microsoft.Jet.OLEDB.4.0;Data Source=C:\APP\TOOLING\Data\PINPACK.mdb;Persist Security Info=False;"
        Dim conn1 As New System.Data.OleDb.OleDbConnection(DownTimeCnnStr)
        Dim SPath As String = "c:\APP\TOOLING\DATA\"
        Dim sContent As String = vbNullString
        Dim dt As New DataTable
        Dim DataSet1 As New DataSet()
        Dim StrTIpTool1 As String
        Dim StrId1 As String
        Dim StrDesc1 As String
        Dim StrTool1 As String
        Dim StrDummy As String
        Dim StUsage As String

        'declara el ToolBad.txt
        Dim FILE_NAME_ToolBAD As String = "C:\APP\TOOLING\Data\ToolBAD.txt"

        'Declara la bandera que usara el Cominuca
        '  Dim FILE_NAME_ToolBADflag As String = "C:\APP\TOOLING\Data\ToolBADflag.txt"

        System.IO.File.Delete(FILE_NAME_ToolBAD)
        Try

            Dim access As String
            access = "Select * FROM TOOLLINES WHERE TOOLLINES.STATUS= 'R' or TOOLLINES.STATUS= 'U'"

            conn1.Open()
            Dim cmd2 As New System.Data.OleDb.OleDbCommand(access, conn1)
            Dim reader2 As OleDbDataReader = cmd2.ExecuteReader


            If System.IO.File.Exists(FILE_NAME_ToolBAD) = False Then
                System.IO.File.Create(FILE_NAME_ToolBAD).Dispose()
            End If
            Dim objWrtToolBAD2 As New System.IO.StreamWriter(FILE_NAME_ToolBAD, True)

            'Lee toda la tabla con los R y U crea el archivo de texto
            While reader2.Read()
                StrTIpTool1 = reader2.GetString(2)
                StrId1 = reader2.GetString(3)
                StrDesc1 = reader2.GetString(4)
                StrTool1 = reader2.GetString(5)
                StUsage = reader2.GetString(6)
                StrDummy = StrTIpTool1 + "," + StrTool1 + "," + StrId1 + "," + StrDesc1 + "," + StUsage
                objWrtToolBAD2.WriteLine(StrDummy) 'create status R to ToolBAD.TXT
            End While
            objWrtToolBAD2.Close()

            conn1.Close()

        Catch ex As Exception
            MsgBox(ex.Message.ToString, MsgBoxStyle.Critical)
            intTPA1 = 0
            intTPE1 = 0
            intTPV1 = 0
        End Try

        'Este flag es solo para el cominuca
        ' Dim objWrtToolBADflag As New System.IO.StreamWriter(FILE_NAME_ToolBADflag, True)
        ' objWrtToolBADflag.WriteLine("Created ToolBad.txt")
        ' objWrtToolBADflag.Close()


    End Function


    Public Function CreateGoodTooling2() As Integer
        'crea el archivo TXT los Tooling buenos en la tabla 

        Dim DownTimeCnnStr As String = "Provider=Microsoft.Jet.OLEDB.4.0;Data Source=C:\APP\TOOLING\Data\PINPACK.mdb;Persist Security Info=False;" 'Jet OLEDB:Database" ' Password=INGENIERIA"        
        Dim conn1 As New System.Data.OleDb.OleDbConnection(DownTimeCnnStr)
        Dim SPath As String = "c:\APP\TOOLING\DATA\"
        Dim sContent As String = vbNullString
        Dim dt As New DataTable
        Dim DataSet1 As New DataSet()
        Dim StrTIpTool1 As String
        Dim StrId1 As String
        Dim StrDesc1 As String
        Dim StrTool1 As String
        Dim StrDummy As String
        Dim StUsage As String

        'Declara el archivo de texto de los buenos
        Dim FILE_NAME_ToolOK2 As String = "C:\APP\TOOLING\Data\ToolOK.TXT"

        'Declara la bandera que usara el Comunica
        '      Dim FILE_NAME_ToolOKflag As String = "C:\APP\TOOLING\Data\ToolOKflag.txt"

        Try

            Dim access As String
            access = "Select * FROM TOOLLINES WHERE TOOLLINES.STATUS= 'G'"

            conn1.Open()
            Dim cmd2 As New System.Data.OleDb.OleDbCommand(access, conn1)
            Dim reader2 As OleDbDataReader = cmd2.ExecuteReader


            If System.IO.File.Exists(FILE_NAME_ToolOK2) = False Then
                System.IO.File.Create(FILE_NAME_ToolOK2).Dispose()
            End If
            Dim objWrtToolOK2 As New System.IO.StreamWriter(FILE_NAME_ToolOK2, True)

            'Lee toda la tabla con los G y crea el archivo de texto
            While reader2.Read()
                StrTIpTool1 = reader2.GetString(2)
                StrId1 = reader2.GetString(3)
                StrDesc1 = reader2.GetString(4)
                StrTool1 = reader2.GetString(5)
                StUsage = reader2.GetString(6)
                StrDummy = StrTIpTool1 + "," + StrTool1 + "," + StrId1 + "," + StrDesc1 + "," + StUsage
                objWrtToolOK2.WriteLine(StrDummy) 'Writes status G from table to ToolOK.txt
            End While
            objWrtToolOK2.Close()

            conn1.Close()

        Catch ex As Exception
            MsgBox(ex.Message.ToString, MsgBoxStyle.Critical)
            intTPA1 = 0
            intTPE1 = 0
            intTPV1 = 0
        End Try

        'Este flag es solo para el cominuca
        'Dim objWrtToolOKflag As New System.IO.StreamWriter(FILE_NAME_ToolOKflag, True)
        'objWrtToolOKflag.WriteLine("Created ToolOK.txt")
        'objWrtToolOKflag.Close()

    End Function
    Public Function ShowGrid() As Double
        'Este no recuerdo de donde viene C me hce que no esta en uso

        Dim DownTimeCnnStr As String = "Provider=Microsoft.Jet.OLEDB.4.0;Data Source=C:\APP\TOOLING\Data\PINPACK.mdb;Persist Security Info=False;" 'Jet OLEDB:Database" ' Password=INGENIERIA"        
        Dim conn1 As New System.Data.OleDb.OleDbConnection(DownTimeCnnStr)
        Dim query As String = "Select TMUERTO FROM REPORTES WHERE DEPTO='TESTING' AND (AREA ='Palomar' or AREA ='Palomar 33xx' ) and HORA_REPORTE >= #" + InicioTurno + "# AND HORA_TERMINO <= #" + FinTurno + " #"

        Dim SPath As String = "c:\APP\TOOLING\DATA\"
        Dim sContent As String = vbNullString
        Dim sdir As String = "c:\Nueva carpeta"

        Dim dt As New DataTable


        Dim DataSet1 As New DataSet()

        Try

            
            query = "Select * FROM TOOLLINES" 
            Dim OleDBConn1 As System.Data.OleDb.OleDbConnection = New System.Data.OleDb.OleDbConnection(DownTimeCnnStr)
            Dim OleDbDataAdapter1 As System.Data.OleDb.OleDbDataAdapter = New System.Data.OleDb.OleDbDataAdapter(query, OleDBConn1)
            OleDBConn1.Open()

            OleDbDataAdapter1.Fill(DataSet1, "TOOLLINES")
            GridTooling.DataSource = DataSet1.Tables("TOOLLINES")
            OleDBConn1.Close()
            


        Catch ex As Exception
            MsgBox(ex.Message.ToString, MsgBoxStyle.Critical)
            intTPA1 = 0
            intTPE1 = 0
            intTPV1 = 0
        End Try

LastLine:
    End Function

    Private Sub LPA1_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles LPA1.Click 'Trae la info de lo que esta instalado en cada prensa
        ShowInfoLines("01A") 'jala la info de la tabla

        Ttotal = dblTPA1 'Del tiempo que trae solo para display en formato xx:xx:xx no tiene efecto en la tabla 
        TVida = TimeSpan.FromSeconds(UsageTPA1)
        EdtVida.Text = TVida.Hours.ToString.PadLeft(2, "0"c) & ":" & TVida.Minutes.ToString.PadLeft(2, "0c") & ":" & TVida.Seconds.ToString.PadLeft(2, "0c")


    End Sub

    Private Sub LPV1_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles LPV1.Click
        ShowInfoLines("01V")
        Ttotal = dblTPV1
        TVida = TimeSpan.FromSeconds(UsageTPV1)
        EdtVida.Text = TVida.Hours.ToString.PadLeft(2, "0"c) & ":" & TVida.Minutes.ToString.PadLeft(2, "0c") & ":" & TVida.Seconds.ToString.PadLeft(2, "0c")


    End Sub

    Private Sub LPE1_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles LPE1.Click
        ShowInfoLines("01E")
        Ttotal = dblTPE1
        TVida = TimeSpan.FromSeconds(UsageTPE1)
        EdtVida.Text = TVida.Hours.ToString.PadLeft(2, "0"c) & ":" & TVida.Minutes.ToString.PadLeft(2, "0c") & ":" & TVida.Seconds.ToString.PadLeft(2, "0c")


    End Sub

    Private Sub LPA2_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles LPA2.Click
        ShowInfoLines("02A")
        Ttotal = dblTPA2
        TVida = TimeSpan.FromSeconds(UsageTPA2)
        EdtVida.Text = TVida.Hours.ToString.PadLeft(2, "0"c) & ":" & TVida.Minutes.ToString.PadLeft(2, "0c") & ":" & TVida.Seconds.ToString.PadLeft(2, "0c")



    End Sub

    Private Sub LPV2_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles LPV2.Click
        ShowInfoLines("02V")
        Ttotal = dblTPV2
        TVida = TimeSpan.FromSeconds(UsageTPV2)
        EdtVida.Text = TVida.Hours.ToString.PadLeft(2, "0"c) & ":" & TVida.Minutes.ToString.PadLeft(2, "0c") & ":" & TVida.Seconds.ToString.PadLeft(2, "0c")



    End Sub

    Private Sub LPE2_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles LPE2.Click
        ShowInfoLines("02E")
        Ttotal = dblTPE2
        TVida = TimeSpan.FromSeconds(UsageTPE2)
        EdtVida.Text = TVida.Hours.ToString.PadLeft(2, "0"c) & ":" & TVida.Minutes.ToString.PadLeft(2, "0c") & ":" & TVida.Seconds.ToString.PadLeft(2, "0c")



    End Sub

    Private Sub LPA3_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles LPA3.Click
        ShowInfoLines("03A")
        Ttotal = dblTPA3
        TVida = TimeSpan.FromSeconds(UsageTPA3)
        EdtVida.Text = TVida.Hours.ToString.PadLeft(2, "0"c) & ":" & TVida.Minutes.ToString.PadLeft(2, "0c") & ":" & TVida.Seconds.ToString.PadLeft(2, "0c")



    End Sub

    Private Sub LPV3_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles LPV3.Click
        ShowInfoLines("03V")
        Ttotal = dblTPV3
        TVida = TimeSpan.FromSeconds(UsageTPV3)
        EdtVida.Text = TVida.Hours.ToString.PadLeft(2, "0"c) & ":" & TVida.Minutes.ToString.PadLeft(2, "0c") & ":" & TVida.Seconds.ToString.PadLeft(2, "0c")


    End Sub

    Private Sub LPE3_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles LPE3.Click
        ShowInfoLines("03E")
        Ttotal = dblTPE3
        TVida = TimeSpan.FromSeconds(UsageTPE3)
        EdtVida.Text = TVida.Hours.ToString.PadLeft(2, "0"c) & ":" & TVida.Minutes.ToString.PadLeft(2, "0c") & ":" & TVida.Seconds.ToString.PadLeft(2, "0c")



    End Sub

    Private Sub LPA4_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles LPA4.Click
        ShowInfoLines("04A")
        Ttotal = dblTPA4
        TVida = TimeSpan.FromSeconds(UsageTPA4)
        EdtVida.Text = TVida.Hours.ToString.PadLeft(2, "0"c) & ":" & TVida.Minutes.ToString.PadLeft(2, "0c") & ":" & TVida.Seconds.ToString.PadLeft(2, "0c")



    End Sub

    Private Sub LPV4_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles LPV4.Click
        ShowInfoLines("04V")
        Ttotal = dblTPV4
        TVida = TimeSpan.FromSeconds(UsageTPV4)
        EdtVida.Text = TVida.Hours.ToString.PadLeft(2, "0"c) & ":" & TVida.Minutes.ToString.PadLeft(2, "0c") & ":" & TVida.Seconds.ToString.PadLeft(2, "0c")


    End Sub

    Private Sub LPE4_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles LPE4.Click
        ShowInfoLines("04E")
        Ttotal = dblTPE4
        TVida = TimeSpan.FromSeconds(UsageTPE4)
        EdtVida.Text = TVida.Hours.ToString.PadLeft(2, "0"c) & ":" & TVida.Minutes.ToString.PadLeft(2, "0c") & ":" & TVida.Seconds.ToString.PadLeft(2, "0c")


    End Sub

    Private Sub LPA5_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles LPA5.Click
        ShowInfoLines("05A")
        Ttotal = dblTPA5
        TVida = TimeSpan.FromSeconds(UsageTPA5)
        EdtVida.Text = TVida.Hours.ToString.PadLeft(2, "0"c) & ":" & TVida.Minutes.ToString.PadLeft(2, "0c") & ":" & TVida.Seconds.ToString.PadLeft(2, "0c")


    End Sub

    Private Sub LPV5_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles LPV5.Click
        ShowInfoLines("05V")
        Ttotal = dblTPV5
        TVida = TimeSpan.FromSeconds(UsageTPV5)
        EdtVida.Text = TVida.Hours.ToString.PadLeft(2, "0"c) & ":" & TVida.Minutes.ToString.PadLeft(2, "0c") & ":" & TVida.Seconds.ToString.PadLeft(2, "0c")


    End Sub

    Private Sub LPE5_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles LPE5.Click
        ShowInfoLines("05E")
        Ttotal = dblTPE5
        TVida = TimeSpan.FromSeconds(UsageTPE5)
        EdtVida.Text = TVida.Hours.ToString.PadLeft(2, "0"c) & ":" & TVida.Minutes.ToString.PadLeft(2, "0c") & ":" & TVida.Seconds.ToString.PadLeft(2, "0c")


    End Sub

    Private Sub LPA6_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles LPA6.Click
        ShowInfoLines("06A")
        Ttotal = dblTPA6
        TVida = TimeSpan.FromSeconds(UsageTPA6)
        EdtVida.Text = TVida.Hours.ToString.PadLeft(2, "0"c) & ":" & TVida.Minutes.ToString.PadLeft(2, "0c") & ":" & TVida.Seconds.ToString.PadLeft(2, "0c")


    End Sub

    Private Sub LPV6_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles LPV6.Click
        ShowInfoLines("06V")
        Ttotal = dblTPV6
        TVida = TimeSpan.FromSeconds(UsageTPV6)
        EdtVida.Text = TVida.Hours.ToString.PadLeft(2, "0"c) & ":" & TVida.Minutes.ToString.PadLeft(2, "0c") & ":" & TVida.Seconds.ToString.PadLeft(2, "0c")


    End Sub

    Private Sub LPE6_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles LPE6.Click
        ShowInfoLines("06E")
        Ttotal = dblTPE6
        TVida = TimeSpan.FromSeconds(UsageTPE6)
        EdtVida.Text = TVida.Hours.ToString.PadLeft(2, "0"c) & ":" & TVida.Minutes.ToString.PadLeft(2, "0c") & ":" & TVida.Seconds.ToString.PadLeft(2, "0c")


    End Sub

    Private Sub LPA7_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles LPA7.Click
        ShowInfoLines("07A")
        Ttotal = dblTPA7
        TVida = TimeSpan.FromSeconds(UsageTPA7)
        EdtVida.Text = TVida.Hours.ToString.PadLeft(2, "0"c) & ":" & TVida.Minutes.ToString.PadLeft(2, "0c") & ":" & TVida.Seconds.ToString.PadLeft(2, "0c")


    End Sub

    Private Sub LPV7_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles LPV7.Click
        ShowInfoLines("07V")
        Ttotal = dblTPV7
        TVida = TimeSpan.FromSeconds(UsageTPV7)
        EdtVida.Text = TVida.Hours.ToString.PadLeft(2, "0"c) & ":" & TVida.Minutes.ToString.PadLeft(2, "0c") & ":" & TVida.Seconds.ToString.PadLeft(2, "0c")


    End Sub

    Private Sub LPE7_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles LPE7.Click
        ShowInfoLines("07E")
        Ttotal = dblTPE7
        TVida = TimeSpan.FromSeconds(UsageTPE7)
        EdtVida.Text = TVida.Hours.ToString.PadLeft(2, "0"c) & ":" & TVida.Minutes.ToString.PadLeft(2, "0c") & ":" & TVida.Seconds.ToString.PadLeft(2, "0c")


    End Sub

    Private Sub LPA8_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles LPA8.Click
        ShowInfoLines("08A")
        Ttotal = dblTPA8
        TVida = TimeSpan.FromSeconds(UsageTPA8)
        EdtVida.Text = TVida.Hours.ToString.PadLeft(2, "0"c) & ":" & TVida.Minutes.ToString.PadLeft(2, "0c") & ":" & TVida.Seconds.ToString.PadLeft(2, "0c")


    End Sub

    Private Sub LPV8_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles LPV8.Click
        ShowInfoLines("08V")
        Ttotal = dblTPV8
        TVida = TimeSpan.FromSeconds(UsageTPV8)
        EdtVida.Text = TVida.Hours.ToString.PadLeft(2, "0"c) & ":" & TVida.Minutes.ToString.PadLeft(2, "0c") & ":" & TVida.Seconds.ToString.PadLeft(2, "0c")


    End Sub

    Private Sub LPE8_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles LPE8.Click
        ShowInfoLines("08E")
        Ttotal = dblTPE8
        TVida = TimeSpan.FromSeconds(UsageTPE8)
        EdtVida.Text = TVida.Hours.ToString.PadLeft(2, "0"c) & ":" & TVida.Minutes.ToString.PadLeft(2, "0c") & ":" & TVida.Seconds.ToString.PadLeft(2, "0c")


    End Sub
    Private Sub LPA9_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles LPA9.Click
        ShowInfoLines("09A")
        Ttotal = dblTPA9
        TVida = TimeSpan.FromSeconds(UsageTPA9)
        EdtVida.Text = TVida.Hours.ToString.PadLeft(2, "0"c) & ":" & TVida.Minutes.ToString.PadLeft(2, "0c") & ":" & TVida.Seconds.ToString.PadLeft(2, "0c")


    End Sub

    Private Sub LPV9_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles LPV9.Click
        ShowInfoLines("09V")
        Ttotal = dblTPV9
        TVida = TimeSpan.FromSeconds(UsageTPV9)
        EdtVida.Text = TVida.Hours.ToString.PadLeft(2, "0"c) & ":" & TVida.Minutes.ToString.PadLeft(2, "0c") & ":" & TVida.Seconds.ToString.PadLeft(2, "0c")


    End Sub

    Private Sub LPE9_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles LPE9.Click
        ShowInfoLines("09E")
        Ttotal = dblTPE9
        TVida = TimeSpan.FromSeconds(UsageTPE9)
        EdtVida.Text = TVida.Hours.ToString.PadLeft(2, "0"c) & ":" & TVida.Minutes.ToString.PadLeft(2, "0c") & ":" & TVida.Seconds.ToString.PadLeft(2, "0c")


    End Sub

    Private Sub LPA10_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles LPA10.Click
        ShowInfoLines("10A")
        Ttotal = dblTPA10
        TVida = TimeSpan.FromSeconds(UsageTPA10)
        EdtVida.Text = TVida.Hours.ToString.PadLeft(2, "0"c) & ":" & TVida.Minutes.ToString.PadLeft(2, "0c") & ":" & TVida.Seconds.ToString.PadLeft(2, "0c")


    End Sub

    Private Sub LPV10_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles LPV10.Click
        ShowInfoLines("10V")
        Ttotal = dblTPV10
        TVida = TimeSpan.FromSeconds(UsageTPV10)
        EdtVida.Text = TVida.Hours.ToString.PadLeft(2, "0"c) & ":" & TVida.Minutes.ToString.PadLeft(2, "0c") & ":" & TVida.Seconds.ToString.PadLeft(2, "0c")


    End Sub

    Private Sub LPE10_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles LPE10.Click
        ShowInfoLines("10E")
        Ttotal = dblTPE10
        TVida = TimeSpan.FromSeconds(UsageTPE10)
        EdtVida.Text = TVida.Hours.ToString.PadLeft(2, "0"c) & ":" & TVida.Minutes.ToString.PadLeft(2, "0c") & ":" & TVida.Seconds.ToString.PadLeft(2, "0c")


    End Sub

    Private Sub Timer4_Tick(ByVal sender As Object, ByVal e As System.EventArgs) Handles Timer4.Tick
        'Actualiza cada segundo la etiqueta de Hora y Dia
        'Muestra el tiempo total del Tooling en cada linea
        If Label5.Text = "D" Then
            EdtTiempoTotal.Text = "DISABLED"
        Else
            Ttotal = Ttotal + 1
            Dim Time As TimeSpan = TimeSpan.FromSeconds(Ttotal)
            EdtTiempoTotal.Text = Time.Hours.ToString.PadLeft(2, "0"c) & ":" & Time.Minutes.ToString.PadLeft(2, "0c") & ":" & Time.Seconds.ToString.PadLeft(2, "0c")
            Label3.Text = ""
        End If

        '-------------------Inicia Botones con tiempo de Tooling solo como Display -------------------------------
        Dim TimePA1T As TimeSpan = TimeSpan.FromSeconds(dblTPA1)
        PA1T.Text = TimePA1T.Hours.ToString.PadLeft(2, "0"c) & ":" & TimePA1T.Minutes.ToString.PadLeft(2, "0c") & ":" & TimePA1T.Seconds.ToString.PadLeft(2, "0c")
        PA1T.BackColor = LPA1.BackColor
        dblTPA1 = dblTPA1 + 1

        Dim TimePV1T As TimeSpan = TimeSpan.FromSeconds(dblTPV1)
        PV1T.Text = TimePV1T.Hours.ToString.PadLeft(2, "0"c) & ":" & TimePV1T.Minutes.ToString.PadLeft(2, "0c") & ":" & TimePV1T.Seconds.ToString.PadLeft(2, "0c")
        PV1T.BackColor = LPV1.BackColor
        dblTPV1 = dblTPV1 + 1

        Dim TimePE1T As TimeSpan = TimeSpan.FromSeconds(dblTPE1)
        PE1T.Text = TimePE1T.Hours.ToString.PadLeft(2, "0"c) & ":" & TimePE1T.Minutes.ToString.PadLeft(2, "0c") & ":" & TimePE1T.Seconds.ToString.PadLeft(2, "0c")
        PE1T.BackColor = LPE1.BackColor
        dblTPE1 = dblTPE1 + 1

        Dim TimePA2T As TimeSpan = TimeSpan.FromSeconds(dblTPA2)
        PA2T.Text = TimePA2T.Hours.ToString.PadLeft(2, "0"c) & ":" & TimePA2T.Minutes.ToString.PadLeft(2, "0c") & ":" & TimePA2T.Seconds.ToString.PadLeft(2, "0c")
        PA2T.BackColor = LPA2.BackColor
        dblTPA2 = dblTPA2 + 1

        Dim TimePV2T As TimeSpan = TimeSpan.FromSeconds(dblTPV2)
        PV2T.Text = TimePV2T.Hours.ToString.PadLeft(2, "0"c) & ":" & TimePV2T.Minutes.ToString.PadLeft(2, "0c") & ":" & TimePV2T.Seconds.ToString.PadLeft(2, "0c")
        PV2T.BackColor = LPV2.BackColor
        dblTPV2 = dblTPV2 + 1

        Dim TimePE2T As TimeSpan = TimeSpan.FromSeconds(dblTPE2)
        PE2T.Text = TimePE2T.Hours.ToString.PadLeft(2, "0"c) & ":" & TimePE2T.Minutes.ToString.PadLeft(2, "0c") & ":" & TimePE2T.Seconds.ToString.PadLeft(2, "0c")
        PE2T.BackColor = LPE2.BackColor
        dblTPE2 = dblTPE2 + 1

        Dim TimePA3T As TimeSpan = TimeSpan.FromSeconds(dblTPA3)
        PA3T.Text = TimePA3T.Hours.ToString.PadLeft(2, "0"c) & ":" & TimePA3T.Minutes.ToString.PadLeft(2, "0c") & ":" & TimePA3T.Seconds.ToString.PadLeft(2, "0c")
        PA3T.BackColor = LPA3.BackColor
        dblTPA3 = dblTPA3 + 1

        Dim TimePV3T As TimeSpan = TimeSpan.FromSeconds(dblTPV3)
        PV3T.Text = TimePV3T.Hours.ToString.PadLeft(2, "0"c) & ":" & TimePV3T.Minutes.ToString.PadLeft(2, "0c") & ":" & TimePV3T.Seconds.ToString.PadLeft(2, "0c")
        PV3T.BackColor = LPV3.BackColor
        dblTPV3 = dblTPV3 + 1

        Dim TimePE3T As TimeSpan = TimeSpan.FromSeconds(dblTPE3)
        PE3T.Text = TimePE3T.Hours.ToString.PadLeft(2, "0"c) & ":" & TimePE3T.Minutes.ToString.PadLeft(2, "0c") & ":" & TimePE3T.Seconds.ToString.PadLeft(2, "0c")
        PE3T.BackColor = LPE3.BackColor
        dblTPE3 = dblTPE3 + 1

        Dim TimePA4T As TimeSpan = TimeSpan.FromSeconds(dblTPA4)
        PA4T.Text = TimePA4T.Hours.ToString.PadLeft(2, "0"c) & ":" & TimePA4T.Minutes.ToString.PadLeft(2, "0c") & ":" & TimePA4T.Seconds.ToString.PadLeft(2, "0c")
        PA4T.BackColor = LPA4.BackColor
        dblTPA4 = dblTPA4 + 1

        Dim TimePV4T As TimeSpan = TimeSpan.FromSeconds(dblTPV4)
        PV4T.Text = TimePV4T.Hours.ToString.PadLeft(2, "0"c) & ":" & TimePV4T.Minutes.ToString.PadLeft(2, "0c") & ":" & TimePV4T.Seconds.ToString.PadLeft(2, "0c")
        PV4T.BackColor = LPV4.BackColor
        dblTPV4 = dblTPV4 + 1

        Dim TimePE4T As TimeSpan = TimeSpan.FromSeconds(dblTPE4)
        PE4T.Text = TimePE4T.Hours.ToString.PadLeft(2, "0"c) & ":" & TimePE4T.Minutes.ToString.PadLeft(2, "0c") & ":" & TimePE4T.Seconds.ToString.PadLeft(2, "0c")
        PE4T.BackColor = LPE4.BackColor
        dblTPE4 = dblTPE4 + 1

        Dim TimePA5T As TimeSpan = TimeSpan.FromSeconds(dblTPA5)
        PA5T.Text = TimePA5T.Hours.ToString.PadLeft(2, "0"c) & ":" & TimePA5T.Minutes.ToString.PadLeft(2, "0c") & ":" & TimePA5T.Seconds.ToString.PadLeft(2, "0c")
        PA5T.BackColor = LPA5.BackColor
        dblTPA5 = dblTPA5 + 1

        Dim TimePV5T As TimeSpan = TimeSpan.FromSeconds(dblTPV5)
        PV5T.Text = TimePV5T.Hours.ToString.PadLeft(2, "0"c) & ":" & TimePV5T.Minutes.ToString.PadLeft(2, "0c") & ":" & TimePV5T.Seconds.ToString.PadLeft(2, "0c")
        PV5T.BackColor = LPV5.BackColor
        dblTPV5 = dblTPV5 + 1

        Dim TimePE5T As TimeSpan = TimeSpan.FromSeconds(dblTPE5)
        PE5T.Text = TimePE5T.Hours.ToString.PadLeft(2, "0"c) & ":" & TimePE5T.Minutes.ToString.PadLeft(2, "0c") & ":" & TimePE5T.Seconds.ToString.PadLeft(2, "0c")
        PE5T.BackColor = LPE5.BackColor
        dblTPE5 = dblTPE5 + 1

        Dim TimePA6T As TimeSpan = TimeSpan.FromSeconds(dblTPA6)
        PA6T.Text = TimePA6T.Hours.ToString.PadLeft(2, "0"c) & ":" & TimePA6T.Minutes.ToString.PadLeft(2, "0c") & ":" & TimePA6T.Seconds.ToString.PadLeft(2, "0c")
        PA6T.BackColor = LPA6.BackColor
        dblTPA6 = dblTPA6 + 1

        Dim TimePV6T As TimeSpan = TimeSpan.FromSeconds(dblTPV6)
        PV6T.Text = TimePV6T.Hours.ToString.PadLeft(2, "0"c) & ":" & TimePV6T.Minutes.ToString.PadLeft(2, "0c") & ":" & TimePV6T.Seconds.ToString.PadLeft(2, "0c")
        PV6T.BackColor = LPV6.BackColor
        dblTPV6 = dblTPV6 + 1

        Dim TimePE6T As TimeSpan = TimeSpan.FromSeconds(dblTPE6)
        PE6T.Text = TimePE6T.Hours.ToString.PadLeft(2, "0"c) & ":" & TimePE6T.Minutes.ToString.PadLeft(2, "0c") & ":" & TimePE6T.Seconds.ToString.PadLeft(2, "0c")
        PE6T.BackColor = LPE6.BackColor
        dblTPE6 = dblTPE6 + 1

        Dim TimePA7T As TimeSpan = TimeSpan.FromSeconds(dblTPA7)
        PA7T.Text = TimePA7T.Hours.ToString.PadLeft(2, "0"c) & ":" & TimePA7T.Minutes.ToString.PadLeft(2, "0c") & ":" & TimePA7T.Seconds.ToString.PadLeft(2, "0c")
        PA7T.BackColor = LPA7.BackColor
        dblTPA7 = dblTPA7 + 1

        Dim TimePV7T As TimeSpan = TimeSpan.FromSeconds(dblTPV7)
        PV7T.Text = TimePV7T.Hours.ToString.PadLeft(2, "0"c) & ":" & TimePV7T.Minutes.ToString.PadLeft(2, "0c") & ":" & TimePV7T.Seconds.ToString.PadLeft(2, "0c")
        PV7T.BackColor = LPV7.BackColor
        dblTPV7 = dblTPV7 + 1

        Dim TimePE7T As TimeSpan = TimeSpan.FromSeconds(dblTPE7)
        PE7T.Text = TimePE7T.Hours.ToString.PadLeft(2, "0"c) & ":" & TimePE7T.Minutes.ToString.PadLeft(2, "0c") & ":" & TimePE7T.Seconds.ToString.PadLeft(2, "0c")
        PE7T.BackColor = LPE7.BackColor
        dblTPE7 = dblTPE7 + 1

        Dim TimePA8T As TimeSpan = TimeSpan.FromSeconds(dblTPA8)
        PA8T.Text = TimePA8T.Hours.ToString.PadLeft(2, "0"c) & ":" & TimePA8T.Minutes.ToString.PadLeft(2, "0c") & ":" & TimePA8T.Seconds.ToString.PadLeft(2, "0c")
        PA8T.BackColor = LPA8.BackColor
        dblTPA8 = dblTPA8 + 1

        Dim TimePV8T As TimeSpan = TimeSpan.FromSeconds(dblTPV8)
        PV8T.Text = TimePV8T.Hours.ToString.PadLeft(2, "0"c) & ":" & TimePV8T.Minutes.ToString.PadLeft(2, "0c") & ":" & TimePV8T.Seconds.ToString.PadLeft(2, "0c")
        PV8T.BackColor = LPV8.BackColor
        dblTPV8 = dblTPV8 + 1

        Dim TimePE8T As TimeSpan = TimeSpan.FromSeconds(dblTPE8)
        PE8T.Text = TimePE8T.Hours.ToString.PadLeft(2, "0"c) & ":" & TimePE8T.Minutes.ToString.PadLeft(2, "0c") & ":" & TimePE8T.Seconds.ToString.PadLeft(2, "0c")
        PE8T.BackColor = LPE8.BackColor
        dblTPE8 = dblTPE8 + 1

        Dim TimePA9T As TimeSpan = TimeSpan.FromSeconds(dblTPA9)
        PA9T.Text = TimePA9T.Hours.ToString.PadLeft(2, "0"c) & ":" & TimePA9T.Minutes.ToString.PadLeft(2, "0c") & ":" & TimePA9T.Seconds.ToString.PadLeft(2, "0c")
        PA9T.BackColor = LPA9.BackColor
        dblTPA9 = dblTPA9 + 1

        Dim TimePV9T As TimeSpan = TimeSpan.FromSeconds(dblTPV9)
        PV9T.Text = TimePV9T.Hours.ToString.PadLeft(2, "0"c) & ":" & TimePV9T.Minutes.ToString.PadLeft(2, "0c") & ":" & TimePV9T.Seconds.ToString.PadLeft(2, "0c")
        PV9T.BackColor = LPV9.BackColor
        dblTPV9 = dblTPV9 + 1

        Dim TimePE9T As TimeSpan = TimeSpan.FromSeconds(dblTPE9)
        PE9T.Text = TimePE9T.Hours.ToString.PadLeft(2, "0"c) & ":" & TimePE9T.Minutes.ToString.PadLeft(2, "0c") & ":" & TimePE9T.Seconds.ToString.PadLeft(2, "0c")
        PE9T.BackColor = LPE9.BackColor
        dblTPE9 = dblTPE9 + 1

        Dim TimePA10T As TimeSpan = TimeSpan.FromSeconds(dblTPA10)
        PA10T.Text = TimePA10T.Hours.ToString.PadLeft(2, "0"c) & ":" & TimePA10T.Minutes.ToString.PadLeft(2, "0c") & ":" & TimePA10T.Seconds.ToString.PadLeft(2, "0c")
        PA10T.BackColor = LPA10.BackColor
        dblTPA10 = dblTPA10 + 1

        Dim TimePV10T As TimeSpan = TimeSpan.FromSeconds(dblTPV10)
        PV10T.Text = TimePV10T.Hours.ToString.PadLeft(2, "0"c) & ":" & TimePV10T.Minutes.ToString.PadLeft(2, "0c") & ":" & TimePV10T.Seconds.ToString.PadLeft(2, "0c")
        PV10T.BackColor = LPV10.BackColor
        dblTPV10 = dblTPV10 + 1

        Dim TimePE10T As TimeSpan = TimeSpan.FromSeconds(dblTPE10)
        PE10T.Text = TimePE10T.Hours.ToString.PadLeft(2, "0"c) & ":" & TimePE10T.Minutes.ToString.PadLeft(2, "0c") & ":" & TimePE10T.Seconds.ToString.PadLeft(2, "0c")
        PE10T.BackColor = LPE10.BackColor
        dblTPE10 = dblTPE10 + 1

        '-------------------Finaliza Botones con tiempo de Tooling solo como Display -------------------------------

        'Muestra la fecha y hora en la pantalla princpal arriba lado izquierdo
        Dim ci As New CultureInfo("en-us")
        FECHA.Text = Now.ToString("M/dd/yyyy", ci)
        HORA.Text = Now.ToString("H:mm:ss", ci)

        'Si son las 6:00 envia el reporte por email
        Dim TimeMailer As DateTime = TimeOfDay
        If TimeMailer = "#06:00:00 AM#" Or TimeMailer = "#06:00:00 PM#" Then
            Mailer()
        End If
    End Sub

    Private Function GetTimers() As Integer
        'Logica que hace la diferencia en segundos desde la fecha/hora que se capturo el Tooling
        'hasta la fecha hora que lo esta bajando a la base
        '-----------------------------------------------------------------------------

        Dim DownTimeCnnStr As String = "Provider=Microsoft.Jet.OLEDB.4.0;Data Source=C:\APP\TOOLING\Data\PINPACK.mdb;Persist Security Info=False;" 'Jet OLEDB:Database" ' Password=INGENIERIA"        
        Dim conn1 As New System.Data.OleDb.OleDbConnection(DownTimeCnnStr)


        '--------get timers ------
        Dim FileTime As DateTime
        Dim SecDiff As Double
        Dim StrHr As String
        Dim strDummyFecha, strDummyHora As Date
        Dim strDummyVida As Double
        Dim strDummyState As String

        Try
            conn1.Open()

            Dim query As String = "Select FECHA, HORA, LINEA, VIDA, ESTADO FROM RUNNING"

            Dim cmd3 As New System.Data.OleDb.OleDbCommand(query, conn1)
            Dim reader3 As OleDbDataReader = cmd3.ExecuteReader

            While reader3.Read()
                strDummyFecha = reader3.GetDateTime(0)
                strDummyHora = reader3.GetDateTime(1)
                strDummyLine = reader3.GetString(2)
                strDummyVida = reader3.GetValue(3)
                strDummyState = reader3.GetString(4)
                StrHr = strDummyFecha + " " + strDummyHora  'Junta la fecha y la hora

                FileTime = Convert.ToDateTime(StrHr)
                SecDiff = DateDiff(DateInterval.Second, FileTime, DateTime.Now)

                'Vacia la diferencia en segundos para el display unicamente
                If strDummyLine.Contains("01") Then
                    If strDummyLine.Contains("V") Then
                        dblTPV1 = SecDiff
                    End If

                    If strDummyLine.Contains("E") Then
                        dblTPE1 = SecDiff
                    End If
                    If strDummyLine.Contains("A") Then
                        dblTPA1 = SecDiff
                    End If
                End If

                If strDummyLine.Contains("02") Then
                    If strDummyLine.Contains("V") Then
                        dblTPV2 = SecDiff
                    End If
                    If strDummyLine.Contains("E") Then
                        dblTPE2 = SecDiff
                    End If
                    If strDummyLine.Contains("A") Then
                        dblTPA2 = SecDiff
                    End If
                End If

                If strDummyLine.Contains("03") Then
                    If strDummyLine.Contains("V") Then
                        dblTPV3 = SecDiff
                    End If
                    If strDummyLine.Contains("E") Then
                        dblTPE3 = SecDiff
                    End If
                    If strDummyLine.Contains("A") Then
                        dblTPA3 = SecDiff
                    End If
                End If

                If strDummyLine.Contains("04") Then
                    If strDummyLine.Contains("V") Then
                        dblTPV4 = SecDiff
                    End If
                    If strDummyLine.Contains("E") Then
                        dblTPE4 = SecDiff
                    End If
                    If strDummyLine.Contains("A") Then
                        dblTPA4 = SecDiff
                    End If
                End If

                If strDummyLine.Contains("05") Then
                    If strDummyLine.Contains("V") Then
                        dblTPV5 = SecDiff
                    End If
                    If strDummyLine.Contains("E") Then
                        dblTPE5 = SecDiff
                    End If
                    If strDummyLine.Contains("A") Then
                        dblTPA5 = SecDiff
                    End If
                End If

                If strDummyLine.Contains("06") Then
                    If strDummyLine.Contains("V") Then
                        dblTPV6 = SecDiff
                    End If
                    If strDummyLine.Contains("E") Then
                        dblTPE6 = SecDiff
                    End If
                    If strDummyLine.Contains("A") Then
                        dblTPA6 = SecDiff
                    End If
                End If

                If strDummyLine.Contains("07") Then
                    If strDummyLine.Contains("V") Then
                        dblTPV7 = SecDiff
                    End If
                    If strDummyLine.Contains("E") Then
                        dblTPE7 = SecDiff
                    End If
                    If strDummyLine.Contains("A") Then
                        dblTPA7 = SecDiff
                    End If
                End If

                If strDummyLine.Contains("08") Then
                    If strDummyLine.Contains("V") Then
                        dblTPV8 = SecDiff
                    End If
                    If strDummyLine.Contains("E") Then
                        dblTPE8 = SecDiff
                    End If
                    If strDummyLine.Contains("A") Then
                        dblTPA8 = SecDiff
                    End If
                End If

                If strDummyLine.Contains("09") Then
                    If strDummyLine.Contains("V") Then
                        dblTPV9 = SecDiff
                    End If
                    If strDummyLine.Contains("E") Then
                        dblTPE9 = SecDiff
                    End If
                    If strDummyLine.Contains("A") Then
                        dblTPA9 = SecDiff
                    End If
                End If

                If strDummyLine.Contains("10") Then
                    If strDummyLine.Contains("V") Then
                        dblTPV10 = SecDiff
                    End If
                    If strDummyLine.Contains("E") Then
                        dblTPE10 = SecDiff
                    End If
                    If strDummyLine.Contains("A") Then
                        dblTPA10 = SecDiff
                    End If
                End If

            End While

            conn1.Close()


        Catch ex As Exception
            MsgBox(ex.Message.ToString, MsgBoxStyle.Critical)
        End Try

    End Function
    Public Sub UpdateGrid()
        'Actualiza el Grid de la pestana

        Dim FullGridAdapter2 As String = "Provider=Microsoft.Jet.OLEDB.4.0;Data Source=C:\APP\TOOLING\Data\PINPACK.mdb;Persist Security Info=False;" 'Jet OLEDB:Database" ' Password=INGENIERIA"        
        Dim conn1Grid As New System.Data.OleDb.OleDbConnection(FullGridAdapter2)
        Dim DataSet1 As New DataSet()

        FullGridAdapter2 = "Provider=Microsoft.Jet.OLEDB.4.0;Data Source=C:\APP\TOOLING\Data\PINPACK.mdb;Persist Security Info=False;"
        con.ConnectionString = FullGridAdapter2
        con.Open()
        Dadapter = New OleDbDataAdapter("Select [TIPO DE TOOLING], TOOLINGID, DESCRIPCION, STATUS, VIDA FROM TOOLLINES", con)
        DSet = New DataSet
        Dadapter.Fill(DSet, "TOOLLINES")
        GridTooling.DataSource = DSet.Tables("TOOLLINES").DefaultView
        con.Close()

        'Actualiza el Grid de la pestana

    End Sub

    Public Sub Mailer()
        'Envia el correo a las 6:00

        Dim con As New OleDbConnection("Provider=Microsoft.Jet.OLEDB.4.0;Data Source=C:\APP\TOOLING\Data\PINPACK.mdb;Persist Security Info=False;")
        Dim emailflag As Integer = 0
        Dim LineXX As String
        Dim C_ToolID, V_ToolID, E_ToolID, C_HoraCamb, V_HoraCamb, E_HoraCamb, C_PDob, V_PDob, E_PDob, C_PQueb, V_PQueb, E_PQueb As String


        con.Open()
        Dim queryEmail As String = "select EMAIL from ADMIN where RECIBEEMAIL = '1'"
        Dim cmdEmail As New System.Data.OleDb.OleDbCommand(queryEmail, con)
        Dim EmailReader As OleDbDataReader = cmdEmail.ExecuteReader

        Dim EmailAdd As String

        While EmailReader.Read()
            EmailAdd = EmailAdd + "," + EmailReader.GetString(0)
        End While
        con.Close()

        Dim Time As String = DateAdd("h", -12, Now)
        Dim Days As String = DateAdd("d", -1, Now).ToShortDateString

        Dim TecQuery As String = "SELECT distinct(INSTALO) from INFOLINES where FECHA >= " & "#" & Time & "#"
        con.Open()
        Dim TecCmd As New System.Data.OleDb.OleDbCommand(TecQuery, con)
        Dim TecReader As OleDbDataReader = TecCmd.ExecuteReader

        Dim TecToday(5) As String
        Dim T As Integer = 0

        While TecReader.Read()
            T = T + 1
            TecToday(T) = TecReader.GetString(0)

        End While
        con.Close()

        Dim oMsg As CDO.Message = New CDO.Message()
        oMsg.From = "Reporte Tooling <Reporte@ToolingKemet.com>"
        oMsg.To = EmailAdd
        oMsg.Subject = "Reporte de Tooling Diario"

        Dim sHtml As String = "<HTML>" & _
         "<HEAD>" & _
         "<TITLE>Reporte Diario de uso de Tooling</TITLE>" & _
         "</HEAD>" & _
         "<H1 style='font-family:verdana'>Reporte Diario de uso de Tooling:</H1>" & _
         "<BODY><P>"

        For e As Integer = 1 To T
            sHtml = sHtml + "<table border=2>" & _
                        "<tr><th colspan=3>Nombre del Tecnico: " & TecToday(e) & "       Fecha: " & Date.Now.ToShortDateString & "</th></tr>" & _
                        "<tr>"

            For i As Integer = 1 To 10
                If i < 10 Then
                    LineXX = "0" + Convert.ToString(i)
                End If
                LineXX = LineXX + "%"
                con.Open()
                Dim query As String = "select FECHA, LINEA, PRENSA, TOOLINGID, GREENPLATE, QTYLABIOSDOBLADOS, LAINA, EMPLEADO, INSTALO, ESTADO, VIDA, QUITO, DURATOTAL, REPARO, FECHAREP, QTYPINESDOBLADOS, QTYPINESQUEBRADOS from INFOLINES where FECHA >= " & "#" & Time & "# and LINEA like '" & LineXX & "' and INSTALO = '" & TecToday(e) & "' ORDER BY FECHA ASC"
                Dim cmd3 As New System.Data.OleDb.OleDbCommand(query, con)
                Dim reader3 As OleDbDataReader = cmd3.ExecuteReader

                Dim StrFecha, StrLinea, StrPrensa, StrToolingid, StrGreenP, StrLabD, StrPinD, StrPinQ, StrLaina, StrEmpleado, StrINSTALO, StrEstado, StrVida, StrQuita, StrDuratotal, StrEficiencia, StrRep, StrFechaRep As String

                Dim HeaderFlag As Integer

                If reader3.HasRows Then
                    emailflag = 1
                    HeaderFlag = 0
                    sHtml = sHtml & "<th>" & _
                               "<table border=2>" & _
                               "<thead>" & _
                               "<tr>" & _
                               "<th colspan=3>Linea #" & i & "</th>" & _
                               "<th colspan=2>Pines</th>" & _
                               "</tr>" & _
                               "</thead>" & _
                               "<tr>" & _
                               "<th></th>" & _
                               "<th>Tooling ID</th>" & _
                               "<th>Hora Inst.</th>" & _
                               "<th>Dob.</th>" & _
                               "<th>Queb.</th>" & _
                               "</tr>" & _
                               "<tbody>"

                End If
                'Se abre la coneccion y se crea el query para la tabla de Tooling Report

                While reader3.Read()
                    If HeaderFlag = 1 Then
                        sHtml = sHtml & "</tbody></table></th>" & _
                                "<th>" & _
                               "<table border=2>" & _
                               "<thead>" & _
                               "<tr>" & _
                               "<th colspan=3>Linea #" & i & "</th>" & _
                               "<th colspan=2>Pines</th>" & _
                               "</tr>" & _
                               "</thead>" & _
                               "<tr>" & _
                               "<th></th>" & _
                               "<th>Tooling ID</th>" & _
                               "<th>Hora Inst.</th>" & _
                               "<th>Dob.</th>" & _
                               "<th>Queb.</th>" & _
                               "</tr>" & _
                               "<tbody>"
                        HeaderFlag = 0
                    End If

                    StrFecha = Convert.ToString(reader3.GetDateTime(0).ToShortTimeString)
                    StrLinea = Convert.ToString(reader3.GetValue(1))
                    StrPrensa = Convert.ToString(reader3.GetValue(2))
                    StrToolingid = Convert.ToString(reader3.GetValue(3))
                    StrPinD = Convert.ToString(reader3.GetValue(15))
                    StrPinQ = Convert.ToString(reader3.GetValue(16))

                    If StrPrensa = "CARGADO" Then
                        C_ToolID = StrToolingid
                        C_HoraCamb = StrFecha
                        C_PDob = StrPinD
                        C_PQueb = StrPinQ
                        sHtml = sHtml & "<tr><td>C</td>" & _
                               "<td>" & C_ToolID & "</td>" & _
                               "<td>" & C_HoraCamb & "</td>" & _
                               "<td>" & C_PDob & "</td>" & _
                               "<td>" & C_PQueb & "</td>" & _
                               "</tr>"
                    ElseIf StrPrensa = "VOLTEO" Then
                        V_ToolID = StrToolingid
                        V_HoraCamb = StrFecha
                        V_PDob = StrPinD
                        V_PQueb = StrPinQ
                        sHtml = sHtml & "<tr><td>V</td>" & _
                               "<td>" & V_ToolID & "</td>" & _
                               "<td>" & V_HoraCamb & "</td>" & _
                               "<td>" & V_PDob & "</td>" & _
                               "<td>" & V_PQueb & "</td>" & _
                               "</tr>"

                    ElseIf StrPrensa = "EXPULSION" Then
                        E_ToolID = StrToolingid
                        E_HoraCamb = StrFecha
                        E_PDob = StrPinD
                        E_PQueb = StrPinQ
                        sHtml = sHtml & "<tr><td>E</td>" & _
                               "<td>" & E_ToolID & "</td>" & _
                               "<td>" & E_HoraCamb & "</td>" & _
                               "<td>" & E_PDob & "</td>" & _
                               "<td>" & E_PQueb & "</td>" & _
                               "</tr>"
                        HeaderFlag = 1
                    End If
                End While
                If reader3.HasRows Then
                    sHtml = sHtml & "</tbody>" & _
                               "</table>" & _
                               "</tr>"
                End If

                con.Close()

                 If i = 10 Then
                    sHtml = sHtml & "</tr>" & _
                                     "<tr>"
                End If
            Next

            'Cierra la tabla del pinpackero
            sHtml = sHtml & "</tr>" & _
            "</table>"
        Next
        sHtml = sHtml & "<P style='font-family:verdana'> Reporte Generado Automaticamente con el detalle de las ultimas 12 horas. </P>" & _
                        "<P style='font-family:verdana'> Control de Tooling. </P>" & _
                        "</BODY>" & _
                        "</HTML>"

        'Envio del email con la informacion del CDO 
        oMsg.HTMLBody = sHtml

        If emailflag = 1 Then
            Dim iConfg As CDO.Configuration = New CDO.Configuration()

            Dim oFields As ADODB.Fields
            oFields = iConfg.Fields  'Comentariar cuando se hacen pruebas

            Dim oField As ADODB.Field
            oField = oFields("http://schemas.microsoft.com/cdo/configuration/sendusing")
            oField.Value = 2
            oField = oFields("http://schemas.microsoft.com/cdo/configuration/smtpserver")
            oField.Value = "SMTPGW.KEMET.COM"
            oFields.Update()
            oMsg.Configuration = iConfg
            oMsg.Send()
            iConfg = Nothing
            oFields = Nothing
            oField = Nothing
            emailflag = 0
        End If
        oMsg = Nothing
        sHtml = Nothing
        con.Close()
    End Sub

    Private Sub AjustesToolStripMenuItem_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles AjustesToolStripMenuItem.Click
        'Manda pedir el Login en el Menu
        Login.Show()
    End Sub



    Private Sub GridTooling_DoubleClick(ByVal sender As Object, ByVal e As System.EventArgs) Handles GridTooling.DoubleClick
        'Muestra el historial del ToolingID desde el Tab TOOLING

        Dim DownTimeCnnStr As String = "Provider=Microsoft.Jet.OLEDB.4.0;Data Source=C:\APP\TOOLING\Data\PINPACK.mdb;Persist Security Info=False;" 'Jet OLEDB:Database" ' Password=INGENIERIA"        
        Dim conn1 As New System.Data.OleDb.OleDbConnection(DownTimeCnnStr)

        HistorialTooling.Show()
        Dim HistTooling, HistLinequery, HistLineFound As String
        Dim HistFlag As Integer = 0
        HistTooling = GridTooling.CurrentRow.Cells(1).Value.ToString
        HistLinequery = "SELECT LINEA FROM RUNNING WHERE TOOLINGID = '" + HistTooling + "'"

        conn1.Open()
        Dim cmdHistLine As New System.Data.OleDb.OleDbCommand(HistLinequery, conn1)
        Dim HistLinereader As OleDbDataReader = cmdHistLine.ExecuteReader

        If HistLinereader.HasRows Then
            HistLinereader.Read()
            HistLineFound = "Tooling: " + HistTooling + " esta capturado o usandose en la linea: " + HistLinereader.GetValue(0)
            HistFlag = 1
        Else
            HistLineFound = "Este Tooling: " + HistTooling + " no esta instalado en este momento."
            HistorialTooling.GridHistTool.Visible = False
            HistorialTooling.btnHistorial.Visible = True
            HistorialTooling.btnHistorial.Text = "Ver Historial: " + HistTooling

        End If
        conn1.Close()

        If HistFlag = 1 Then
            HistorialTooling.btnHistorial.Visible = False
            HistorialTooling.GridHistTool.Visible = True
            Dim DsetHist As New DataSet()
            DsetHist.Clear()

            conn1.Open()
            Dadapter = New OleDbDataAdapter("SELECT FECHA, TURNO, LINEA, PRENSA, TOOLINGID, QTYLABIOSDOBLADOS, LAINA, EMPLEADO, INSTALO, VIDA, QUITO, DURATOTAL, REPARO, FECHAREP, QTYPINESDOBLADOS, QTYPINESQUEBRADOS FROM INFOLINES WHERE TOOLINGID='" + HistTooling + "' ORDER BY FECHA DESC", conn1)
            Dadapter.Fill(DsetHist, "TOOLHIST")
            HistorialTooling.GridHistTool.DataSource = DsetHist.Tables("TOOLHIST").DefaultView
            conn1.Close()

        End If
        HistorialTooling.lblToolH.Text = HistTooling
        HistorialTooling.lbltoolingHist.Text = HistLineFound

    End Sub



    Public Sub DBtoFile()
        'Baja la info de la tabla Running a un archivo de texto cada minuto para mantener actualizada la info

        Dim objWrtDBtoFile As New System.IO.StreamWriter(sDBtoFile, False)

        Dim DownTimeCnnStr As String = "Provider=Microsoft.Jet.OLEDB.4.0;Data Source=C:\APP\TOOLING\Data\PINPACK.mdb;Persist Security Info=False;" 'Jet OLEDB:Database" ' Password=INGENIERIA"        
        Dim conn1 As New System.Data.OleDb.OleDbConnection(DownTimeCnnStr)

        Dim FileTime As DateTime
        Dim sContent As String = vbNullString
        Dim dt As New DataTable
        Dim DataSet1 As New DataSet()

        Try

            Dim access As String
            access = "Select FECHA, HORA, LINEA, TOOLINGID, ESTADO, VIDA FROM RUNNING ORDER BY LINEA ASC"

            conn1.Open()
            Dim cmd2 As New System.Data.OleDb.OleDbCommand(access, conn1)
            Dim reader2 As OleDbDataReader = cmd2.ExecuteReader

            While reader2.Read()
                StrFecha = reader2.GetValue(0)
                StrHora = reader2.GetValue(1)
                StrLinea = reader2.GetString(2)
                StrToolingID = reader2.GetString(3)
                StrEstado = reader2.GetString(4)
                StrVida = reader2.GetString(5)

                StrHr = StrFecha + " " + StrHora
                FileTime = Convert.ToDateTime(StrHr)
                StrUso = DateDiff(DateInterval.Second, FileTime, DateTime.Now)

                If StrUso > StrVida And StrEstado <> "D" Then

                    StrEstado = "R"

                    Dim UpdToolLines As String = "UPDATE TOOLLINES SET STATUS = 'R' where TOOLINGID='" & StrToolingID & "'"
                    Dim cmdTL As New OleDbCommand(UpdToolLines, conn1)
                    cmdTL.ExecuteNonQuery()

                    Dim UpdRunning As String = "UPDATE RUNNING SET ESTADO= '" & StrEstado & "' where RUNNING.LINEA= '" & StrLinea & "'"
                    Dim cmd As New OleDbCommand(UpdRunning, conn1)
                    cmd.ExecuteNonQuery()
                End If

                StrDummy = StrFecha + "," + StrHora + "," + StrLinea + "," + StrToolingID + "," + StrEstado + "," + StrVida + "," + Convert.ToString(StrUso)
                objWrtDBtoFile.WriteLine(StrDummy)
            End While
            objWrtDBtoFile.Close()

            conn1.Close()

        Catch ex As Exception
            MsgBox(ex.Message.ToString, MsgBoxStyle.Critical)

        End Try

        If System.IO.File.Exists(sDBtoFile) = True Then
            'No activar JR
            'System.IO.File.Delete(sDBtoFile)

        End If
        TmrDbToFile.Enabled = True
    End Sub

    Private Sub TmrDbToFile_Tick(ByVal sender As Object, ByVal e As System.EventArgs) Handles TmrDbToFile.Tick
        'Timer que corre una vez por minutopara crear los archivos y actualizar el display
        DBtoFile()
        DBtoFileRead()
        UpdateGrid()
    End Sub

    Protected Overrides Sub Finalize()
        MyBase.Finalize()
    End Sub
    Public Sub DBtoFileRead()
        'Lee el archivo Running.txt y ajustar los colores de las lineas
        If System.IO.File.Exists(sDBtoFile) Then
            ' lee todo el contenido  
            Dim objReadRunning As New System.IO.StreamReader(sDBtoFile)
            Do While objReadRunning.Peek() <> -1
                TextLine = TextLine & objReadRunning.ReadLine() & vbNewLine
                TestString = TextLine
                Dim ArrayRunning() As String = Split(TestString, ",")
                Dim LastNonEmptyRunning As Integer = 0
                For i As Integer = 0 To 1
                    If ArrayRunning(i) <> "" Then
                        LastNonEmptyRunning += 1
                        StrFecha = ArrayRunning(i)
                        StrHora = ArrayRunning(i + 1)
                        strDummyLine = ArrayRunning(i + 2)
                        StrToolingID = ArrayRunning(i + 3)
                        StrEstado = ArrayRunning(i + 4)
                        StrVida = ArrayRunning(i + 5)
                        StrUsoFile = ArrayRunning(i + 6).Trim()
                        i = i + 1
                        Dim StrEstadoY As String = StrVida - 1200
                        If Convert.ToDouble(StrUsoFile) > Convert.ToDouble(StrEstadoY) And Convert.ToDouble(StrUsoFile) < Convert.ToDouble(StrVida) Then
                            StrEstado = "Y"
                        End If
                        strDummyLine = strDummyLine + StrEstado + StrVida
                        If strDummyLine.Contains("01") Then
                            UpdateTableStatusLine1(strDummyLine)
                        End If
                        If strDummyLine.Contains("02") Then
                            UpdateTableStatusLine2(strDummyLine)
                        End If
                        If strDummyLine.Contains("03") Then
                            UpdateTableStatusLine3(strDummyLine)
                        End If
                        If strDummyLine.Contains("04") Then
                            UpdateTableStatusLine4(strDummyLine)
                        End If
                        If strDummyLine.Contains("05") Then
                            UpdateTableStatusLine5(strDummyLine)
                        End If
                        If strDummyLine.Contains("06") Then
                            UpdateTableStatusLine6(strDummyLine)
                        End If
                        If strDummyLine.Contains("07") Then
                            UpdateTableStatusLine7(strDummyLine)
                        End If
                        If strDummyLine.Contains("08") Then
                            UpdateTableStatusLine8(strDummyLine)
                        End If
                        If strDummyLine.Contains("09") Then
                            UpdateTableStatusLine9(strDummyLine)
                        End If
                        If strDummyLine.Contains("10") Then
                            UpdateTableStatusLine10(strDummyLine)
                        End If
                    End If
                Next
                TextLine = ""
                ReDim Preserve ArrayRunning(LastNonEmptyRunning)
            Loop
            objReadRunning.Close()
        End If
    End Sub

    Private Sub Button1_Click(ByVal sender As System.Object, ByVal e As System.EventArgs)
        CreateBadTooling()
        CreateGoodTooling()
    End Sub

   
    Private Sub TimerMain2_Tick(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles TimerMain2.Tick
        If System.IO.File.Exists("C:\APP\TOOLING\Data\HandHeld2.con") = False Then
            Dim FILE_NAME_PROCESS As String = "C:\APP\TOOLING\Data\Process.con"
            If System.IO.File.Exists(FILE_NAME_PROCESS) = False Then
                System.IO.File.Create(FILE_NAME_PROCESS).Dispose()
            End If
            Try
DeNew2:
                TimerMain.Enabled = 0
                TimerMain2.Enabled = 0
                TmrDbToFile.Enabled = False
                ' Procesa primero el ToolRepair por si reparaste algun Tooling
ToolRepair2:
                If System.IO.File.Exists("C:\APP\TOOLING\Data\ToolRepair2.ok") = True Then
                    'System.Threading.Thread.Sleep(1000)
                    TimerMain.Enabled = 0
                    TimerMain2.Enabled = 0

                    UpdateTableFromHH("C:\APP\TOOLING\Data\ToolRepair2.ok")
                    If System.IO.File.Exists("C:\APP\TOOLING\Data\ToolRepair2.ok") = True Then
                        System.IO.File.Delete("C:\APP\TOOLING\Data\ToolRepair2.ok")
                    End If
                End If
                'Procesa el archivo MyDebug si instalaste algun tooling
MyDebug2:
                If System.IO.File.Exists("C:\APP\TOOLING\Data\Mydebug2.dat") = True Then
                    ' System.Threading.Thread.Sleep(1000)
                    TimerMain.Enabled = 0
                    TimerMain2.Enabled = 0
                    UpdateTableFromFile("C:\APP\TOOLING\Data\Mydebug2.dat")

                    If System.IO.File.Exists("C:\APP\TOOLING\Data\Mydebug2.dat") = True Then
                        System.IO.File.Delete("C:\APP\TOOLING\Data\Mydebug2.dat")
                    End If
                End If

                ''''''GoTo MyDebug
                'Crea el archivo de Tooling Bueno
ToolOK2:
                If System.IO.File.Exists("C:\APP\TOOLING\Data\ToolOK.TXT") = True Then
                    '  System.Threading.Thread.Sleep(1000)
                    TimerMain.Enabled = 0
                    TimerMain2.Enabled = 0
                    System.IO.File.Delete("C:\APP\TOOLING\Data\ToolOK.TXT")
                    CreateGoodTooling()
                Else
                    CreateGoodTooling()
                    TimerMain.Enabled = 0
                    TimerMain2.Enabled = 0

                End If

                '''''''''  GoTo ToolOK  
                ' Crea el archivo de Tooling Malo
ToolBAD2:
                If System.IO.File.Exists("C:\APP\TOOLING\Data\ToolBAD.txt") = True Then
                    '    System.Threading.Thread.Sleep(1000)
                    TimerMain.Enabled = 0
                    TimerMain2.Enabled = 0
                    System.IO.File.Delete("C:\APP\TOOLING\Data\ToolBAD.txt")
                    CreateBadTooling()

                Else

                    'Create ToolBAD.txt if deleted by error
                    CreateBadTooling()

                    TimerMain.Enabled = 1
                    TimerMain2.Enabled = 1
                End If

                '''''''''''''   GoTo ToolBAD
                UpdateGrid()

                TimerMain.Enabled = 1
                TimerMain2.Enabled = 1

                
                TmrDbToFile.Enabled = True


                ' errores  
            Catch oe As Exception
                'MsgBox(oe.Message, MsgBoxStyle.Critical)
                GoTo DeNew2
            End Try
            GetTimers()
            DBtoFile()
            DBtoFileRead()
            If System.IO.File.Exists("C:\APP\TOOLING\Data\Process.con") = True Then
                System.IO.File.Delete("C:\APP\TOOLING\Data\Process.con")
            End If
            If ShowInfo = 1 Then
                If Screen = 0 Then
                    Label19.Hide()
                    Me.TabHistorial.Show()
                    Me.TabHistorial.SelectTab(0)
                    Screen = 1 '1
                ElseIf Screen = 1 Then
                    Label19.Hide()
                    Me.TabHistorial.SelectTab(1)
                    Me.TabHistorial.Show()
                    Screen = 3 '3
                ElseIf Screen = 2 Then
                    Label19.Hide()
                    Me.TabHistorial.SelectTab(1)
                    Me.TabHistorial.Show()
                    Screen = 3
                ElseIf Screen = 3 Then
                    Label19.Show()
                    Me.TabHistorial.Hide()
                    Screen = 0 '0


                End If
            End If
            TimerMain.Enabled = 1
            TimerMain2.Enabled = 0
        End If


       
    End Sub

  
    Private Sub TmrGrid_Tick(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles TmrGrid.Tick

    End Sub
End Class