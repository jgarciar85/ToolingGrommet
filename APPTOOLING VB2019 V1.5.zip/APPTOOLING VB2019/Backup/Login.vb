﻿Public Class Login


    Private Sub OK_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles OK.Click
        If txtLogin.Text = "" Or txtPass.Text = "" Then
            MessageBox.Show("Escribe tu numero de empleado y contrasena.")
        Else
            Dim conn As New System.Data.OleDb.OleDbConnection()
            conn.ConnectionString = "Provider=Microsoft.Jet.OLEDB.4.0;Data Source=C:\APP\TOOLING\Data\PINPACK.mdb;Persist Security Info=False;"

            Try
                Dim query As String = "SELECT * FROM ADMIN WHERE ADMIN.ID='" & txtLogin.Text & "' AND ADMIN.PASSWORD='" & txtPass.Text & "'"
                Dim querycom As New System.Data.OleDb.OleDbCommand(query)

                querycom.Connection = conn
                conn.Open()

                Dim Privilegios, NumEmp, NomEmp As String

                Dim queryRead As System.Data.OleDb.OleDbDataReader = querycom.ExecuteReader()

                If queryRead.Read() Then
                    Privilegios = queryRead(6)
                    NumEmp = queryRead(0)
                    NomEmp = queryRead(2)
                    Ajustes.txtPrivilegios.Text = Privilegios
                    Ajustes.txtNumEm.Text = NumEmp
                    Ajustes.txtNom.Text = NomEmp
                    Ajustes.Show()

                Else
                    MessageBox.Show("Numero de empleado o contrasena equivocados.")
                    txtLogin.Text = ""
                    txtPass.Text = ""
                    txtLogin.Focus()

                End If


            Catch ex As Exception
                MessageBox.Show("Error al conectarse a la Base de Datos de Administradores. Vuelve a Intentarlo")

            End Try
            conn.Close()
            Me.Close()

        End If
    End Sub

    Private Sub Cancel_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Cancel.Click
        Me.Close()
    End Sub

 
    Private Sub txtLogin_KeyPress(ByVal sender As Object, ByVal e As System.Windows.Forms.KeyPressEventArgs) Handles txtLogin.KeyPress
        If Not IsNumeric(e.KeyChar) Then
            e.Handled = True
        End If
    End Sub

    Private Sub Label1_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Label1.Click
        If txtLogin.Text = "" Or txtPass.Text = "" Then
            MessageBox.Show("Escribe tu numero de empleado y contrasena actual.")
        Else
            Dim conn As New System.Data.OleDb.OleDbConnection()
            conn.ConnectionString = "Provider=Microsoft.Jet.OLEDB.4.0;Data Source=C:\APP\TOOLING\Data\PINPACK.mdb;Persist Security Info=False;"

            Try
                Dim query As String = "SELECT * FROM ADMIN WHERE ADMIN.ID='" & txtLogin.Text & "' AND ADMIN.PASSWORD='" & txtPass.Text & "'"
                Dim querycom As New System.Data.OleDb.OleDbCommand(query)

                querycom.Connection = conn
                conn.Open()



                Dim queryRead As System.Data.OleDb.OleDbDataReader = querycom.ExecuteReader()

                If queryRead.Read() Then
                    Password.PassNumEmp.Text = txtLogin.Text
                    Password.Show()

                Else
                    MessageBox.Show("Numero de empleado o contrasena equivocados.")
                    txtLogin.Text = ""
                    txtPass.Text = ""
                    txtLogin.Focus()

                End If


            Catch ex As Exception
                MessageBox.Show("Error al conectarse a la Base de Datos de Administradores. Vuelve a Intentarlo")

            End Try
            conn.Close()
            Me.Close()
        End If



    End Sub
End Class
