<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> Partial Class Form1
#Region "Windows Form Designer generated code "
	<System.Diagnostics.DebuggerNonUserCode()> Public Sub New()
		MyBase.New()
		'This call is required by the Windows Form Designer.
		InitializeComponent()
	End Sub
	'Form overrides dispose to clean up the component list.
	<System.Diagnostics.DebuggerNonUserCode()> Protected Overloads Overrides Sub Dispose(ByVal Disposing As Boolean)
		If Disposing Then
			If Not components Is Nothing Then
				components.Dispose()
			End If
		End If
		MyBase.Dispose(Disposing)
	End Sub
	'Required by the Windows Form Designer
	Private components As System.ComponentModel.IContainer
    'Public WithEvents MesOraMFC1 As AxMesMFC.AxMesOraMFC
    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.
    'Do not modify it using the code editor.
	<System.Diagnostics.DebuggerStepThrough()> Private Sub InitializeComponent()
        Me.components = New System.ComponentModel.Container
        Dim resources As System.ComponentModel.ComponentResourceManager = New System.ComponentModel.ComponentResourceManager(GetType(Form1))
        Me.Label18 = New System.Windows.Forms.Label
        Me.Label19 = New System.Windows.Forms.Label
        Me.Label20 = New System.Windows.Forms.Label
        Me.OEE_CURRENT = New System.Windows.Forms.Label
        Me.Panel1 = New System.Windows.Forms.Panel
        Me.QUALITY = New System.Windows.Forms.Label
        Me.Label23 = New System.Windows.Forms.Label
        Me.PERFORMANCE = New System.Windows.Forms.Label
        Me.Label22 = New System.Windows.Forms.Label
        Me.AVAILABILITY = New System.Windows.Forms.Label
        Me.Label21 = New System.Windows.Forms.Label
        Me.FECHA = New System.Windows.Forms.Label
        Me.HORA = New System.Windows.Forms.Label
        Me.Panel2 = New System.Windows.Forms.Panel
        Me.TimerMain = New System.Windows.Forms.Timer(Me.components)
        Me.TmrGrid = New System.Windows.Forms.Timer(Me.components)
        Me.Timer4 = New System.Windows.Forms.Timer(Me.components)
        Me.MenuStrip1 = New System.Windows.Forms.MenuStrip
        Me.MantenimientoToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem
        Me.AjustesToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem
        Me.AcercaDeToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem
        Me.InformacionHH = New System.Windows.Forms.TabPage
        Me.BtnEnvioHH = New System.Windows.Forms.Button
        Me.Tooling = New System.Windows.Forms.TabPage
        Me.TxtUpdTooling = New System.Windows.Forms.TextBox
        Me.BtnSave = New System.Windows.Forms.Button
        Me.GridTooling = New System.Windows.Forms.DataGridView
        Me.Lineas = New System.Windows.Forms.TabPage
        Me.Panel3 = New System.Windows.Forms.Panel
        Me.PE10T = New System.Windows.Forms.Label
        Me.PV10T = New System.Windows.Forms.Label
        Me.PA10T = New System.Windows.Forms.Label
        Me.PE9T = New System.Windows.Forms.Label
        Me.PV9T = New System.Windows.Forms.Label
        Me.PA9T = New System.Windows.Forms.Label
        Me.PE8T = New System.Windows.Forms.Label
        Me.PV8T = New System.Windows.Forms.Label
        Me.PA8T = New System.Windows.Forms.Label
        Me.PE7T = New System.Windows.Forms.Label
        Me.PV7T = New System.Windows.Forms.Label
        Me.PA7T = New System.Windows.Forms.Label
        Me.PE6T = New System.Windows.Forms.Label
        Me.PV6T = New System.Windows.Forms.Label
        Me.PA6T = New System.Windows.Forms.Label
        Me.PE5T = New System.Windows.Forms.Label
        Me.PV5T = New System.Windows.Forms.Label
        Me.PA5T = New System.Windows.Forms.Label
        Me.PE4T = New System.Windows.Forms.Label
        Me.PV4T = New System.Windows.Forms.Label
        Me.PA4T = New System.Windows.Forms.Label
        Me.PE3T = New System.Windows.Forms.Label
        Me.PV3T = New System.Windows.Forms.Label
        Me.PA3T = New System.Windows.Forms.Label
        Me.PE2T = New System.Windows.Forms.Label
        Me.PV2T = New System.Windows.Forms.Label
        Me.PA2T = New System.Windows.Forms.Label
        Me.PE1T = New System.Windows.Forms.Label
        Me.PV1T = New System.Windows.Forms.Label
        Me.PA1T = New System.Windows.Forms.Label
        Me.Label5 = New System.Windows.Forms.Label
        Me.Label4 = New System.Windows.Forms.Label
        Me.EdtVida = New System.Windows.Forms.TextBox
        Me.Label3 = New System.Windows.Forms.Label
        Me.EdtTiempoTotal = New System.Windows.Forms.TextBox
        Me.Label2 = New System.Windows.Forms.Label
        Me.EdNumEmpleado = New System.Windows.Forms.TextBox
        Me.Label1 = New System.Windows.Forms.Label
        Me.Label44 = New System.Windows.Forms.Label
        Me.Label15 = New System.Windows.Forms.Label
        Me.Label16 = New System.Windows.Forms.Label
        Me.Label40 = New System.Windows.Forms.Label
        Me.EdtTurno = New System.Windows.Forms.TextBox
        Me.EdtLado = New System.Windows.Forms.TextBox
        Me.EdtPrensa = New System.Windows.Forms.TextBox
        Me.EdtLine = New System.Windows.Forms.TextBox
        Me.EdtHora = New System.Windows.Forms.TextBox
        Me.EdtFecha = New System.Windows.Forms.TextBox
        Me.EdtTecnico = New System.Windows.Forms.TextBox
        Me.EdtLaina = New System.Windows.Forms.TextBox
        Me.EdtGreenPlate = New System.Windows.Forms.TextBox
        Me.EdtPPackAnt = New System.Windows.Forms.TextBox
        Me.Label41 = New System.Windows.Forms.Label
        Me.Label43 = New System.Windows.Forms.Label
        Me.Label37 = New System.Windows.Forms.Label
        Me.Label38 = New System.Windows.Forms.Label
        Me.Label39 = New System.Windows.Forms.Label
        Me.Label34 = New System.Windows.Forms.Label
        Me.Label35 = New System.Windows.Forms.Label
        Me.Label33 = New System.Windows.Forms.Label
        Me.Label32 = New System.Windows.Forms.Label
        Me.EdtTooling = New System.Windows.Forms.TextBox
        Me.Label31 = New System.Windows.Forms.Label
        Me.Label30 = New System.Windows.Forms.Label
        Me.Label29 = New System.Windows.Forms.Label
        Me.LPA9 = New System.Windows.Forms.Button
        Me.Label25 = New System.Windows.Forms.Label
        Me.LPE10 = New System.Windows.Forms.Button
        Me.Label24 = New System.Windows.Forms.Label
        Me.LPV10 = New System.Windows.Forms.Button
        Me.LPA1 = New System.Windows.Forms.Button
        Me.LPA10 = New System.Windows.Forms.Button
        Me.Label27 = New System.Windows.Forms.Label
        Me.Label26 = New System.Windows.Forms.Label
        Me.LPE4 = New System.Windows.Forms.Button
        Me.LPE9 = New System.Windows.Forms.Button
        Me.LPE1 = New System.Windows.Forms.Button
        Me.LPV8 = New System.Windows.Forms.Button
        Me.LPV5 = New System.Windows.Forms.Button
        Me.LPA8 = New System.Windows.Forms.Button
        Me.LPE5 = New System.Windows.Forms.Button
        Me.LPE7 = New System.Windows.Forms.Button
        Me.LPE6 = New System.Windows.Forms.Button
        Me.Label17 = New System.Windows.Forms.Label
        Me.LPV7 = New System.Windows.Forms.Button
        Me.LPV6 = New System.Windows.Forms.Button
        Me.LPV1 = New System.Windows.Forms.Button
        Me.LPA5 = New System.Windows.Forms.Button
        Me.LPA4 = New System.Windows.Forms.Button
        Me.LPE2 = New System.Windows.Forms.Button
        Me.LPV2 = New System.Windows.Forms.Button
        Me.LPA2 = New System.Windows.Forms.Button
        Me.LPA7 = New System.Windows.Forms.Button
        Me.LPV3 = New System.Windows.Forms.Button
        Me.LPA3 = New System.Windows.Forms.Button
        Me.LPE3 = New System.Windows.Forms.Button
        Me.LPA6 = New System.Windows.Forms.Button
        Me.LPV4 = New System.Windows.Forms.Button
        Me.LPV9 = New System.Windows.Forms.Button
        Me.LPE8 = New System.Windows.Forms.Button
        Me.TabHistorial = New System.Windows.Forms.TabControl
        Me.TmrFile = New System.Windows.Forms.Timer(Me.components)
        Me.TmrDbToFile = New System.Windows.Forms.Timer(Me.components)
        Me.TimerMain2 = New System.Windows.Forms.Timer(Me.components)
        Me.Panel1.SuspendLayout()
        Me.MenuStrip1.SuspendLayout()
        Me.InformacionHH.SuspendLayout()
        Me.Tooling.SuspendLayout()
        CType(Me.GridTooling, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.Lineas.SuspendLayout()
        Me.Panel3.SuspendLayout()
        Me.TabHistorial.SuspendLayout()
        Me.SuspendLayout()
        '
        'Label18
        '
        Me.Label18.BackColor = System.Drawing.Color.White
        resources.ApplyResources(Me.Label18, "Label18")
        Me.Label18.Name = "Label18"
        '
        'Label19
        '
        Me.Label19.BackColor = System.Drawing.Color.White
        resources.ApplyResources(Me.Label19, "Label19")
        Me.Label19.ForeColor = System.Drawing.Color.Navy
        Me.Label19.Name = "Label19"
        '
        'Label20
        '
        Me.Label20.BackColor = System.Drawing.Color.Lime
        resources.ApplyResources(Me.Label20, "Label20")
        Me.Label20.ForeColor = System.Drawing.Color.DarkBlue
        Me.Label20.Name = "Label20"
        '
        'OEE_CURRENT
        '
        Me.OEE_CURRENT.BackColor = System.Drawing.Color.DarkBlue
        resources.ApplyResources(Me.OEE_CURRENT, "OEE_CURRENT")
        Me.OEE_CURRENT.ForeColor = System.Drawing.Color.Lime
        Me.OEE_CURRENT.Name = "OEE_CURRENT"
        '
        'Panel1
        '
        Me.Panel1.BackColor = System.Drawing.Color.DarkBlue
        Me.Panel1.Controls.Add(Me.QUALITY)
        Me.Panel1.Controls.Add(Me.Label23)
        Me.Panel1.Controls.Add(Me.PERFORMANCE)
        Me.Panel1.Controls.Add(Me.Label22)
        Me.Panel1.Controls.Add(Me.AVAILABILITY)
        Me.Panel1.Controls.Add(Me.Label21)
        Me.Panel1.Controls.Add(Me.OEE_CURRENT)
        Me.Panel1.Controls.Add(Me.Label20)
        resources.ApplyResources(Me.Panel1, "Panel1")
        Me.Panel1.Name = "Panel1"
        '
        'QUALITY
        '
        Me.QUALITY.BackColor = System.Drawing.Color.Lime
        resources.ApplyResources(Me.QUALITY, "QUALITY")
        Me.QUALITY.ForeColor = System.Drawing.Color.Navy
        Me.QUALITY.Name = "QUALITY"
        '
        'Label23
        '
        Me.Label23.BackColor = System.Drawing.Color.Lime
        resources.ApplyResources(Me.Label23, "Label23")
        Me.Label23.ForeColor = System.Drawing.Color.DarkBlue
        Me.Label23.Name = "Label23"
        '
        'PERFORMANCE
        '
        Me.PERFORMANCE.BackColor = System.Drawing.Color.Lime
        resources.ApplyResources(Me.PERFORMANCE, "PERFORMANCE")
        Me.PERFORMANCE.ForeColor = System.Drawing.Color.Navy
        Me.PERFORMANCE.Name = "PERFORMANCE"
        '
        'Label22
        '
        Me.Label22.BackColor = System.Drawing.Color.Lime
        resources.ApplyResources(Me.Label22, "Label22")
        Me.Label22.ForeColor = System.Drawing.Color.DarkBlue
        Me.Label22.Name = "Label22"
        '
        'AVAILABILITY
        '
        Me.AVAILABILITY.BackColor = System.Drawing.Color.Lime
        resources.ApplyResources(Me.AVAILABILITY, "AVAILABILITY")
        Me.AVAILABILITY.ForeColor = System.Drawing.Color.Navy
        Me.AVAILABILITY.Name = "AVAILABILITY"
        '
        'Label21
        '
        Me.Label21.BackColor = System.Drawing.Color.Lime
        resources.ApplyResources(Me.Label21, "Label21")
        Me.Label21.ForeColor = System.Drawing.Color.DarkBlue
        Me.Label21.Name = "Label21"
        '
        'FECHA
        '
        Me.FECHA.BackColor = System.Drawing.SystemColors.ButtonHighlight
        resources.ApplyResources(Me.FECHA, "FECHA")
        Me.FECHA.ForeColor = System.Drawing.Color.DodgerBlue
        Me.FECHA.Name = "FECHA"
        '
        'HORA
        '
        Me.HORA.BackColor = System.Drawing.SystemColors.ButtonHighlight
        resources.ApplyResources(Me.HORA, "HORA")
        Me.HORA.ForeColor = System.Drawing.Color.DodgerBlue
        Me.HORA.Name = "HORA"
        '
        'Panel2
        '
        Me.Panel2.BackColor = System.Drawing.SystemColors.ButtonHighlight
        resources.ApplyResources(Me.Panel2, "Panel2")
        Me.Panel2.Name = "Panel2"
        '
        'TimerMain
        '
        Me.TimerMain.Interval = 10000
        '
        'TmrGrid
        '
        Me.TmrGrid.Interval = 10000
        '
        'Timer4
        '
        Me.Timer4.Enabled = True
        Me.Timer4.Interval = 1000
        '
        'MenuStrip1
        '
        Me.MenuStrip1.Items.AddRange(New System.Windows.Forms.ToolStripItem() {Me.MantenimientoToolStripMenuItem, Me.AcercaDeToolStripMenuItem})
        resources.ApplyResources(Me.MenuStrip1, "MenuStrip1")
        Me.MenuStrip1.Name = "MenuStrip1"
        '
        'MantenimientoToolStripMenuItem
        '
        Me.MantenimientoToolStripMenuItem.DropDownItems.AddRange(New System.Windows.Forms.ToolStripItem() {Me.AjustesToolStripMenuItem})
        Me.MantenimientoToolStripMenuItem.Name = "MantenimientoToolStripMenuItem"
        resources.ApplyResources(Me.MantenimientoToolStripMenuItem, "MantenimientoToolStripMenuItem")
        '
        'AjustesToolStripMenuItem
        '
        Me.AjustesToolStripMenuItem.Name = "AjustesToolStripMenuItem"
        resources.ApplyResources(Me.AjustesToolStripMenuItem, "AjustesToolStripMenuItem")
        '
        'AcercaDeToolStripMenuItem
        '
        Me.AcercaDeToolStripMenuItem.Name = "AcercaDeToolStripMenuItem"
        resources.ApplyResources(Me.AcercaDeToolStripMenuItem, "AcercaDeToolStripMenuItem")
        '
        'InformacionHH
        '
        Me.InformacionHH.Controls.Add(Me.BtnEnvioHH)
        resources.ApplyResources(Me.InformacionHH, "InformacionHH")
        Me.InformacionHH.Name = "InformacionHH"
        Me.InformacionHH.UseVisualStyleBackColor = True
        '
        'BtnEnvioHH
        '
        resources.ApplyResources(Me.BtnEnvioHH, "BtnEnvioHH")
        Me.BtnEnvioHH.Name = "BtnEnvioHH"
        Me.BtnEnvioHH.UseVisualStyleBackColor = True
        '
        'Tooling
        '
        Me.Tooling.Controls.Add(Me.TxtUpdTooling)
        Me.Tooling.Controls.Add(Me.BtnSave)
        Me.Tooling.Controls.Add(Me.GridTooling)
        resources.ApplyResources(Me.Tooling, "Tooling")
        Me.Tooling.Name = "Tooling"
        Me.Tooling.UseVisualStyleBackColor = True
        '
        'TxtUpdTooling
        '
        resources.ApplyResources(Me.TxtUpdTooling, "TxtUpdTooling")
        Me.TxtUpdTooling.ForeColor = System.Drawing.SystemColors.MenuHighlight
        Me.TxtUpdTooling.Name = "TxtUpdTooling"
        '
        'BtnSave
        '
        resources.ApplyResources(Me.BtnSave, "BtnSave")
        Me.BtnSave.Name = "BtnSave"
        Me.BtnSave.UseVisualStyleBackColor = True
        '
        'GridTooling
        '
        Me.GridTooling.BackgroundColor = System.Drawing.SystemColors.Highlight
        Me.GridTooling.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize
        Me.GridTooling.GridColor = System.Drawing.SystemColors.InactiveCaption
        resources.ApplyResources(Me.GridTooling, "GridTooling")
        Me.GridTooling.Name = "GridTooling"
        '
        'Lineas
        '
        Me.Lineas.Controls.Add(Me.Panel3)
        resources.ApplyResources(Me.Lineas, "Lineas")
        Me.Lineas.Name = "Lineas"
        Me.Lineas.UseVisualStyleBackColor = True
        '
        'Panel3
        '
        Me.Panel3.Controls.Add(Me.PE10T)
        Me.Panel3.Controls.Add(Me.PV10T)
        Me.Panel3.Controls.Add(Me.PA10T)
        Me.Panel3.Controls.Add(Me.PE9T)
        Me.Panel3.Controls.Add(Me.PV9T)
        Me.Panel3.Controls.Add(Me.PA9T)
        Me.Panel3.Controls.Add(Me.PE8T)
        Me.Panel3.Controls.Add(Me.PV8T)
        Me.Panel3.Controls.Add(Me.PA8T)
        Me.Panel3.Controls.Add(Me.PE7T)
        Me.Panel3.Controls.Add(Me.PV7T)
        Me.Panel3.Controls.Add(Me.PA7T)
        Me.Panel3.Controls.Add(Me.PE6T)
        Me.Panel3.Controls.Add(Me.PV6T)
        Me.Panel3.Controls.Add(Me.PA6T)
        Me.Panel3.Controls.Add(Me.PE5T)
        Me.Panel3.Controls.Add(Me.PV5T)
        Me.Panel3.Controls.Add(Me.PA5T)
        Me.Panel3.Controls.Add(Me.PE4T)
        Me.Panel3.Controls.Add(Me.PV4T)
        Me.Panel3.Controls.Add(Me.PA4T)
        Me.Panel3.Controls.Add(Me.PE3T)
        Me.Panel3.Controls.Add(Me.PV3T)
        Me.Panel3.Controls.Add(Me.PA3T)
        Me.Panel3.Controls.Add(Me.PE2T)
        Me.Panel3.Controls.Add(Me.PV2T)
        Me.Panel3.Controls.Add(Me.PA2T)
        Me.Panel3.Controls.Add(Me.PE1T)
        Me.Panel3.Controls.Add(Me.PV1T)
        Me.Panel3.Controls.Add(Me.PA1T)
        Me.Panel3.Controls.Add(Me.Label5)
        Me.Panel3.Controls.Add(Me.Label4)
        Me.Panel3.Controls.Add(Me.EdtVida)
        Me.Panel3.Controls.Add(Me.Label3)
        Me.Panel3.Controls.Add(Me.EdtTiempoTotal)
        Me.Panel3.Controls.Add(Me.Label2)
        Me.Panel3.Controls.Add(Me.EdNumEmpleado)
        Me.Panel3.Controls.Add(Me.Label1)
        Me.Panel3.Controls.Add(Me.Label44)
        Me.Panel3.Controls.Add(Me.Label15)
        Me.Panel3.Controls.Add(Me.Label16)
        Me.Panel3.Controls.Add(Me.Label40)
        Me.Panel3.Controls.Add(Me.EdtTurno)
        Me.Panel3.Controls.Add(Me.EdtLado)
        Me.Panel3.Controls.Add(Me.EdtPrensa)
        Me.Panel3.Controls.Add(Me.EdtLine)
        Me.Panel3.Controls.Add(Me.EdtHora)
        Me.Panel3.Controls.Add(Me.EdtFecha)
        Me.Panel3.Controls.Add(Me.EdtTecnico)
        Me.Panel3.Controls.Add(Me.EdtLaina)
        Me.Panel3.Controls.Add(Me.EdtGreenPlate)
        Me.Panel3.Controls.Add(Me.EdtPPackAnt)
        Me.Panel3.Controls.Add(Me.Label41)
        Me.Panel3.Controls.Add(Me.Label43)
        Me.Panel3.Controls.Add(Me.Label37)
        Me.Panel3.Controls.Add(Me.Label38)
        Me.Panel3.Controls.Add(Me.Label39)
        Me.Panel3.Controls.Add(Me.Label34)
        Me.Panel3.Controls.Add(Me.Label35)
        Me.Panel3.Controls.Add(Me.Label33)
        Me.Panel3.Controls.Add(Me.Label32)
        Me.Panel3.Controls.Add(Me.EdtTooling)
        Me.Panel3.Controls.Add(Me.Label31)
        Me.Panel3.Controls.Add(Me.Label30)
        Me.Panel3.Controls.Add(Me.Label29)
        Me.Panel3.Controls.Add(Me.LPA9)
        Me.Panel3.Controls.Add(Me.Label25)
        Me.Panel3.Controls.Add(Me.LPE10)
        Me.Panel3.Controls.Add(Me.Label24)
        Me.Panel3.Controls.Add(Me.LPV10)
        Me.Panel3.Controls.Add(Me.LPA1)
        Me.Panel3.Controls.Add(Me.LPA10)
        Me.Panel3.Controls.Add(Me.Label27)
        Me.Panel3.Controls.Add(Me.Label26)
        Me.Panel3.Controls.Add(Me.LPE4)
        Me.Panel3.Controls.Add(Me.LPE9)
        Me.Panel3.Controls.Add(Me.LPE1)
        Me.Panel3.Controls.Add(Me.LPV8)
        Me.Panel3.Controls.Add(Me.LPV5)
        Me.Panel3.Controls.Add(Me.LPA8)
        Me.Panel3.Controls.Add(Me.LPE5)
        Me.Panel3.Controls.Add(Me.LPE7)
        Me.Panel3.Controls.Add(Me.LPE6)
        Me.Panel3.Controls.Add(Me.Label17)
        Me.Panel3.Controls.Add(Me.LPV7)
        Me.Panel3.Controls.Add(Me.LPV6)
        Me.Panel3.Controls.Add(Me.LPV1)
        Me.Panel3.Controls.Add(Me.LPA5)
        Me.Panel3.Controls.Add(Me.LPA4)
        Me.Panel3.Controls.Add(Me.LPE2)
        Me.Panel3.Controls.Add(Me.LPV2)
        Me.Panel3.Controls.Add(Me.LPA2)
        Me.Panel3.Controls.Add(Me.LPA7)
        Me.Panel3.Controls.Add(Me.LPV3)
        Me.Panel3.Controls.Add(Me.LPA3)
        Me.Panel3.Controls.Add(Me.LPE3)
        Me.Panel3.Controls.Add(Me.LPA6)
        Me.Panel3.Controls.Add(Me.LPV4)
        Me.Panel3.Controls.Add(Me.LPV9)
        Me.Panel3.Controls.Add(Me.LPE8)
        resources.ApplyResources(Me.Panel3, "Panel3")
        Me.Panel3.Name = "Panel3"
        '
        'PE10T
        '
        resources.ApplyResources(Me.PE10T, "PE10T")
        Me.PE10T.Name = "PE10T"
        '
        'PV10T
        '
        resources.ApplyResources(Me.PV10T, "PV10T")
        Me.PV10T.Name = "PV10T"
        '
        'PA10T
        '
        resources.ApplyResources(Me.PA10T, "PA10T")
        Me.PA10T.Name = "PA10T"
        '
        'PE9T
        '
        resources.ApplyResources(Me.PE9T, "PE9T")
        Me.PE9T.Name = "PE9T"
        '
        'PV9T
        '
        resources.ApplyResources(Me.PV9T, "PV9T")
        Me.PV9T.Name = "PV9T"
        '
        'PA9T
        '
        resources.ApplyResources(Me.PA9T, "PA9T")
        Me.PA9T.Name = "PA9T"
        '
        'PE8T
        '
        resources.ApplyResources(Me.PE8T, "PE8T")
        Me.PE8T.Name = "PE8T"
        '
        'PV8T
        '
        resources.ApplyResources(Me.PV8T, "PV8T")
        Me.PV8T.Name = "PV8T"
        '
        'PA8T
        '
        resources.ApplyResources(Me.PA8T, "PA8T")
        Me.PA8T.Name = "PA8T"
        '
        'PE7T
        '
        resources.ApplyResources(Me.PE7T, "PE7T")
        Me.PE7T.Name = "PE7T"
        '
        'PV7T
        '
        resources.ApplyResources(Me.PV7T, "PV7T")
        Me.PV7T.Name = "PV7T"
        '
        'PA7T
        '
        resources.ApplyResources(Me.PA7T, "PA7T")
        Me.PA7T.Name = "PA7T"
        '
        'PE6T
        '
        resources.ApplyResources(Me.PE6T, "PE6T")
        Me.PE6T.Name = "PE6T"
        '
        'PV6T
        '
        resources.ApplyResources(Me.PV6T, "PV6T")
        Me.PV6T.Name = "PV6T"
        '
        'PA6T
        '
        resources.ApplyResources(Me.PA6T, "PA6T")
        Me.PA6T.Name = "PA6T"
        '
        'PE5T
        '
        resources.ApplyResources(Me.PE5T, "PE5T")
        Me.PE5T.Name = "PE5T"
        '
        'PV5T
        '
        resources.ApplyResources(Me.PV5T, "PV5T")
        Me.PV5T.Name = "PV5T"
        '
        'PA5T
        '
        resources.ApplyResources(Me.PA5T, "PA5T")
        Me.PA5T.Name = "PA5T"
        '
        'PE4T
        '
        resources.ApplyResources(Me.PE4T, "PE4T")
        Me.PE4T.Name = "PE4T"
        '
        'PV4T
        '
        resources.ApplyResources(Me.PV4T, "PV4T")
        Me.PV4T.Name = "PV4T"
        '
        'PA4T
        '
        resources.ApplyResources(Me.PA4T, "PA4T")
        Me.PA4T.Name = "PA4T"
        '
        'PE3T
        '
        resources.ApplyResources(Me.PE3T, "PE3T")
        Me.PE3T.Name = "PE3T"
        '
        'PV3T
        '
        resources.ApplyResources(Me.PV3T, "PV3T")
        Me.PV3T.Name = "PV3T"
        '
        'PA3T
        '
        resources.ApplyResources(Me.PA3T, "PA3T")
        Me.PA3T.Name = "PA3T"
        '
        'PE2T
        '
        resources.ApplyResources(Me.PE2T, "PE2T")
        Me.PE2T.Name = "PE2T"
        '
        'PV2T
        '
        resources.ApplyResources(Me.PV2T, "PV2T")
        Me.PV2T.Name = "PV2T"
        '
        'PA2T
        '
        resources.ApplyResources(Me.PA2T, "PA2T")
        Me.PA2T.Name = "PA2T"
        '
        'PE1T
        '
        resources.ApplyResources(Me.PE1T, "PE1T")
        Me.PE1T.Name = "PE1T"
        '
        'PV1T
        '
        resources.ApplyResources(Me.PV1T, "PV1T")
        Me.PV1T.Name = "PV1T"
        '
        'PA1T
        '
        resources.ApplyResources(Me.PA1T, "PA1T")
        Me.PA1T.Name = "PA1T"
        '
        'Label5
        '
        resources.ApplyResources(Me.Label5, "Label5")
        Me.Label5.Name = "Label5"
        '
        'Label4
        '
        resources.ApplyResources(Me.Label4, "Label4")
        Me.Label4.Name = "Label4"
        '
        'EdtVida
        '
        resources.ApplyResources(Me.EdtVida, "EdtVida")
        Me.EdtVida.ForeColor = System.Drawing.SystemColors.MenuHighlight
        Me.EdtVida.Name = "EdtVida"
        '
        'Label3
        '
        resources.ApplyResources(Me.Label3, "Label3")
        Me.Label3.Name = "Label3"
        '
        'EdtTiempoTotal
        '
        resources.ApplyResources(Me.EdtTiempoTotal, "EdtTiempoTotal")
        Me.EdtTiempoTotal.ForeColor = System.Drawing.SystemColors.MenuHighlight
        Me.EdtTiempoTotal.Name = "EdtTiempoTotal"
        '
        'Label2
        '
        resources.ApplyResources(Me.Label2, "Label2")
        Me.Label2.Name = "Label2"
        '
        'EdNumEmpleado
        '
        resources.ApplyResources(Me.EdNumEmpleado, "EdNumEmpleado")
        Me.EdNumEmpleado.ForeColor = System.Drawing.SystemColors.MenuHighlight
        Me.EdNumEmpleado.Name = "EdNumEmpleado"
        '
        'Label1
        '
        resources.ApplyResources(Me.Label1, "Label1")
        Me.Label1.Name = "Label1"
        '
        'Label44
        '
        resources.ApplyResources(Me.Label44, "Label44")
        Me.Label44.Name = "Label44"
        '
        'Label15
        '
        resources.ApplyResources(Me.Label15, "Label15")
        Me.Label15.Name = "Label15"
        '
        'Label16
        '
        resources.ApplyResources(Me.Label16, "Label16")
        Me.Label16.Name = "Label16"
        '
        'Label40
        '
        resources.ApplyResources(Me.Label40, "Label40")
        Me.Label40.Name = "Label40"
        '
        'EdtTurno
        '
        resources.ApplyResources(Me.EdtTurno, "EdtTurno")
        Me.EdtTurno.ForeColor = System.Drawing.SystemColors.MenuHighlight
        Me.EdtTurno.Name = "EdtTurno"
        '
        'EdtLado
        '
        resources.ApplyResources(Me.EdtLado, "EdtLado")
        Me.EdtLado.ForeColor = System.Drawing.SystemColors.MenuHighlight
        Me.EdtLado.Name = "EdtLado"
        '
        'EdtPrensa
        '
        resources.ApplyResources(Me.EdtPrensa, "EdtPrensa")
        Me.EdtPrensa.ForeColor = System.Drawing.SystemColors.MenuHighlight
        Me.EdtPrensa.Name = "EdtPrensa"
        '
        'EdtLine
        '
        Me.EdtLine.CausesValidation = False
        resources.ApplyResources(Me.EdtLine, "EdtLine")
        Me.EdtLine.ForeColor = System.Drawing.SystemColors.MenuHighlight
        Me.EdtLine.Name = "EdtLine"
        '
        'EdtHora
        '
        resources.ApplyResources(Me.EdtHora, "EdtHora")
        Me.EdtHora.ForeColor = System.Drawing.SystemColors.MenuHighlight
        Me.EdtHora.Name = "EdtHora"
        '
        'EdtFecha
        '
        resources.ApplyResources(Me.EdtFecha, "EdtFecha")
        Me.EdtFecha.ForeColor = System.Drawing.SystemColors.MenuHighlight
        Me.EdtFecha.Name = "EdtFecha"
        '
        'EdtTecnico
        '
        resources.ApplyResources(Me.EdtTecnico, "EdtTecnico")
        Me.EdtTecnico.ForeColor = System.Drawing.SystemColors.MenuHighlight
        Me.EdtTecnico.Name = "EdtTecnico"
        '
        'EdtLaina
        '
        resources.ApplyResources(Me.EdtLaina, "EdtLaina")
        Me.EdtLaina.ForeColor = System.Drawing.SystemColors.MenuHighlight
        Me.EdtLaina.Name = "EdtLaina"
        '
        'EdtGreenPlate
        '
        resources.ApplyResources(Me.EdtGreenPlate, "EdtGreenPlate")
        Me.EdtGreenPlate.ForeColor = System.Drawing.SystemColors.MenuHighlight
        Me.EdtGreenPlate.Name = "EdtGreenPlate"
        '
        'EdtPPackAnt
        '
        resources.ApplyResources(Me.EdtPPackAnt, "EdtPPackAnt")
        Me.EdtPPackAnt.ForeColor = System.Drawing.SystemColors.MenuHighlight
        Me.EdtPPackAnt.Name = "EdtPPackAnt"
        '
        'Label41
        '
        resources.ApplyResources(Me.Label41, "Label41")
        Me.Label41.Name = "Label41"
        '
        'Label43
        '
        resources.ApplyResources(Me.Label43, "Label43")
        Me.Label43.Name = "Label43"
        '
        'Label37
        '
        resources.ApplyResources(Me.Label37, "Label37")
        Me.Label37.Name = "Label37"
        '
        'Label38
        '
        resources.ApplyResources(Me.Label38, "Label38")
        Me.Label38.Name = "Label38"
        '
        'Label39
        '
        resources.ApplyResources(Me.Label39, "Label39")
        Me.Label39.Name = "Label39"
        '
        'Label34
        '
        resources.ApplyResources(Me.Label34, "Label34")
        Me.Label34.Name = "Label34"
        '
        'Label35
        '
        resources.ApplyResources(Me.Label35, "Label35")
        Me.Label35.Name = "Label35"
        '
        'Label33
        '
        resources.ApplyResources(Me.Label33, "Label33")
        Me.Label33.Name = "Label33"
        '
        'Label32
        '
        resources.ApplyResources(Me.Label32, "Label32")
        Me.Label32.Name = "Label32"
        '
        'EdtTooling
        '
        resources.ApplyResources(Me.EdtTooling, "EdtTooling")
        Me.EdtTooling.ForeColor = System.Drawing.SystemColors.MenuHighlight
        Me.EdtTooling.Name = "EdtTooling"
        '
        'Label31
        '
        resources.ApplyResources(Me.Label31, "Label31")
        Me.Label31.Name = "Label31"
        '
        'Label30
        '
        resources.ApplyResources(Me.Label30, "Label30")
        Me.Label30.Name = "Label30"
        '
        'Label29
        '
        resources.ApplyResources(Me.Label29, "Label29")
        Me.Label29.Name = "Label29"
        '
        'LPA9
        '
        Me.LPA9.BackColor = System.Drawing.Color.Yellow
        resources.ApplyResources(Me.LPA9, "LPA9")
        Me.LPA9.Name = "LPA9"
        Me.LPA9.UseVisualStyleBackColor = False
        '
        'Label25
        '
        resources.ApplyResources(Me.Label25, "Label25")
        Me.Label25.Name = "Label25"
        '
        'LPE10
        '
        Me.LPE10.BackColor = System.Drawing.Color.Red
        resources.ApplyResources(Me.LPE10, "LPE10")
        Me.LPE10.Name = "LPE10"
        Me.LPE10.UseVisualStyleBackColor = False
        '
        'Label24
        '
        resources.ApplyResources(Me.Label24, "Label24")
        Me.Label24.Name = "Label24"
        '
        'LPV10
        '
        Me.LPV10.BackColor = System.Drawing.Color.DodgerBlue
        resources.ApplyResources(Me.LPV10, "LPV10")
        Me.LPV10.Name = "LPV10"
        Me.LPV10.UseVisualStyleBackColor = False
        '
        'LPA1
        '
        Me.LPA1.BackColor = System.Drawing.Color.Green
        resources.ApplyResources(Me.LPA1, "LPA1")
        Me.LPA1.Name = "LPA1"
        Me.LPA1.UseVisualStyleBackColor = False
        '
        'LPA10
        '
        Me.LPA10.BackColor = System.Drawing.Color.Green
        resources.ApplyResources(Me.LPA10, "LPA10")
        Me.LPA10.Name = "LPA10"
        Me.LPA10.UseVisualStyleBackColor = False
        '
        'Label27
        '
        resources.ApplyResources(Me.Label27, "Label27")
        Me.Label27.Name = "Label27"
        '
        'Label26
        '
        resources.ApplyResources(Me.Label26, "Label26")
        Me.Label26.Name = "Label26"
        '
        'LPE4
        '
        Me.LPE4.BackColor = System.Drawing.Color.Green
        resources.ApplyResources(Me.LPE4, "LPE4")
        Me.LPE4.Name = "LPE4"
        Me.LPE4.UseVisualStyleBackColor = False
        '
        'LPE9
        '
        Me.LPE9.BackColor = System.Drawing.Color.Red
        resources.ApplyResources(Me.LPE9, "LPE9")
        Me.LPE9.Name = "LPE9"
        Me.LPE9.UseVisualStyleBackColor = False
        '
        'LPE1
        '
        Me.LPE1.BackColor = System.Drawing.Color.DodgerBlue
        resources.ApplyResources(Me.LPE1, "LPE1")
        Me.LPE1.Name = "LPE1"
        Me.LPE1.UseVisualStyleBackColor = False
        '
        'LPV8
        '
        Me.LPV8.BackColor = System.Drawing.Color.DodgerBlue
        resources.ApplyResources(Me.LPV8, "LPV8")
        Me.LPV8.Name = "LPV8"
        Me.LPV8.UseVisualStyleBackColor = False
        '
        'LPV5
        '
        Me.LPV5.BackColor = System.Drawing.Color.DodgerBlue
        resources.ApplyResources(Me.LPV5, "LPV5")
        Me.LPV5.Name = "LPV5"
        Me.LPV5.UseVisualStyleBackColor = False
        '
        'LPA8
        '
        Me.LPA8.BackColor = System.Drawing.Color.Green
        resources.ApplyResources(Me.LPA8, "LPA8")
        Me.LPA8.Name = "LPA8"
        Me.LPA8.UseVisualStyleBackColor = False
        '
        'LPE5
        '
        Me.LPE5.BackColor = System.Drawing.Color.Red
        resources.ApplyResources(Me.LPE5, "LPE5")
        Me.LPE5.Name = "LPE5"
        Me.LPE5.UseVisualStyleBackColor = False
        '
        'LPE7
        '
        Me.LPE7.BackColor = System.Drawing.Color.Red
        resources.ApplyResources(Me.LPE7, "LPE7")
        Me.LPE7.Name = "LPE7"
        Me.LPE7.UseVisualStyleBackColor = False
        '
        'LPE6
        '
        Me.LPE6.BackColor = System.Drawing.Color.Red
        resources.ApplyResources(Me.LPE6, "LPE6")
        Me.LPE6.Name = "LPE6"
        Me.LPE6.UseVisualStyleBackColor = False
        '
        'Label17
        '
        resources.ApplyResources(Me.Label17, "Label17")
        Me.Label17.Name = "Label17"
        '
        'LPV7
        '
        Me.LPV7.BackColor = System.Drawing.Color.DodgerBlue
        resources.ApplyResources(Me.LPV7, "LPV7")
        Me.LPV7.Name = "LPV7"
        Me.LPV7.UseVisualStyleBackColor = False
        '
        'LPV6
        '
        Me.LPV6.BackColor = System.Drawing.Color.DodgerBlue
        resources.ApplyResources(Me.LPV6, "LPV6")
        Me.LPV6.Name = "LPV6"
        Me.LPV6.UseVisualStyleBackColor = False
        '
        'LPV1
        '
        Me.LPV1.BackColor = System.Drawing.Color.Red
        resources.ApplyResources(Me.LPV1, "LPV1")
        Me.LPV1.Name = "LPV1"
        Me.LPV1.UseVisualStyleBackColor = False
        '
        'LPA5
        '
        Me.LPA5.BackColor = System.Drawing.Color.Green
        resources.ApplyResources(Me.LPA5, "LPA5")
        Me.LPA5.Name = "LPA5"
        Me.LPA5.UseVisualStyleBackColor = False
        '
        'LPA4
        '
        Me.LPA4.BackColor = System.Drawing.Color.Green
        resources.ApplyResources(Me.LPA4, "LPA4")
        Me.LPA4.Name = "LPA4"
        Me.LPA4.UseVisualStyleBackColor = False
        '
        'LPE2
        '
        Me.LPE2.BackColor = System.Drawing.Color.Red
        resources.ApplyResources(Me.LPE2, "LPE2")
        Me.LPE2.Name = "LPE2"
        Me.LPE2.UseVisualStyleBackColor = False
        '
        'LPV2
        '
        Me.LPV2.BackColor = System.Drawing.Color.DodgerBlue
        resources.ApplyResources(Me.LPV2, "LPV2")
        Me.LPV2.Name = "LPV2"
        Me.LPV2.UseVisualStyleBackColor = False
        '
        'LPA2
        '
        Me.LPA2.BackColor = System.Drawing.Color.Green
        resources.ApplyResources(Me.LPA2, "LPA2")
        Me.LPA2.Name = "LPA2"
        Me.LPA2.UseVisualStyleBackColor = False
        '
        'LPA7
        '
        Me.LPA7.BackColor = System.Drawing.Color.Green
        resources.ApplyResources(Me.LPA7, "LPA7")
        Me.LPA7.Name = "LPA7"
        Me.LPA7.UseVisualStyleBackColor = False
        '
        'LPV3
        '
        Me.LPV3.BackColor = System.Drawing.Color.DodgerBlue
        resources.ApplyResources(Me.LPV3, "LPV3")
        Me.LPV3.Name = "LPV3"
        Me.LPV3.UseVisualStyleBackColor = False
        '
        'LPA3
        '
        Me.LPA3.BackColor = System.Drawing.Color.Green
        resources.ApplyResources(Me.LPA3, "LPA3")
        Me.LPA3.Name = "LPA3"
        Me.LPA3.UseVisualStyleBackColor = False
        '
        'LPE3
        '
        Me.LPE3.BackColor = System.Drawing.Color.Red
        resources.ApplyResources(Me.LPE3, "LPE3")
        Me.LPE3.Name = "LPE3"
        Me.LPE3.UseVisualStyleBackColor = False
        '
        'LPA6
        '
        Me.LPA6.BackColor = System.Drawing.Color.Green
        resources.ApplyResources(Me.LPA6, "LPA6")
        Me.LPA6.Name = "LPA6"
        Me.LPA6.UseVisualStyleBackColor = False
        '
        'LPV4
        '
        Me.LPV4.BackColor = System.Drawing.Color.DodgerBlue
        resources.ApplyResources(Me.LPV4, "LPV4")
        Me.LPV4.Name = "LPV4"
        Me.LPV4.UseVisualStyleBackColor = False
        '
        'LPV9
        '
        Me.LPV9.BackColor = System.Drawing.Color.Red
        resources.ApplyResources(Me.LPV9, "LPV9")
        Me.LPV9.Name = "LPV9"
        Me.LPV9.UseVisualStyleBackColor = False
        '
        'LPE8
        '
        Me.LPE8.BackColor = System.Drawing.Color.Red
        resources.ApplyResources(Me.LPE8, "LPE8")
        Me.LPE8.Name = "LPE8"
        Me.LPE8.UseVisualStyleBackColor = False
        '
        'TabHistorial
        '
        Me.TabHistorial.Controls.Add(Me.Lineas)
        Me.TabHistorial.Controls.Add(Me.Tooling)
        Me.TabHistorial.Controls.Add(Me.InformacionHH)
        resources.ApplyResources(Me.TabHistorial, "TabHistorial")
        Me.TabHistorial.Name = "TabHistorial"
        Me.TabHistorial.SelectedIndex = 0
        '
        'TmrFile
        '
        Me.TmrFile.Interval = 60000
        '
        'TmrDbToFile
        '
        Me.TmrDbToFile.Interval = 60000
        '
        'TimerMain2
        '
        Me.TimerMain2.Interval = 10000
        '
        'Form1
        '
        Me.AllowDrop = True
        resources.ApplyResources(Me, "$this")
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.BackColor = System.Drawing.Color.White
        Me.ControlBox = False
        Me.Controls.Add(Me.TabHistorial)
        Me.Controls.Add(Me.HORA)
        Me.Controls.Add(Me.FECHA)
        Me.Controls.Add(Me.Panel2)
        Me.Controls.Add(Me.Panel1)
        Me.Controls.Add(Me.Label18)
        Me.Controls.Add(Me.Label19)
        Me.Controls.Add(Me.MenuStrip1)
        Me.Cursor = System.Windows.Forms.Cursors.Default
        Me.FormBorderStyle = System.Windows.Forms.FormBorderStyle.Fixed3D
        Me.MainMenuStrip = Me.MenuStrip1
        Me.MaximizeBox = False
        Me.MinimizeBox = False
        Me.Name = "Form1"
        Me.Panel1.ResumeLayout(False)
        Me.MenuStrip1.ResumeLayout(False)
        Me.MenuStrip1.PerformLayout()
        Me.InformacionHH.ResumeLayout(False)
        Me.Tooling.ResumeLayout(False)
        Me.Tooling.PerformLayout()
        CType(Me.GridTooling, System.ComponentModel.ISupportInitialize).EndInit()
        Me.Lineas.ResumeLayout(False)
        Me.Panel3.ResumeLayout(False)
        Me.Panel3.PerformLayout()
        Me.TabHistorial.ResumeLayout(False)
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub
    Friend WithEvents Timer1 As System.Windows.Forms.Timer
    Friend WithEvents Timer2 As System.Windows.Forms.Timer
    Friend WithEvents Label18 As System.Windows.Forms.Label
    Friend WithEvents Label19 As System.Windows.Forms.Label
    Friend WithEvents Label20 As System.Windows.Forms.Label
    Friend WithEvents OEE_CURRENT As System.Windows.Forms.Label
    Friend WithEvents Panel1 As System.Windows.Forms.Panel
    Friend WithEvents AVAILABILITY As System.Windows.Forms.Label
    Friend WithEvents Label21 As System.Windows.Forms.Label
    Friend WithEvents QUALITY As System.Windows.Forms.Label
    Friend WithEvents Label23 As System.Windows.Forms.Label
    Friend WithEvents PERFORMANCE As System.Windows.Forms.Label
    Friend WithEvents Label22 As System.Windows.Forms.Label
    Friend WithEvents FECHA As System.Windows.Forms.Label
    Friend WithEvents HORA As System.Windows.Forms.Label
    Friend WithEvents Panel2 As System.Windows.Forms.Panel
    Friend WithEvents Timer3 As System.Windows.Forms.Timer
    Friend WithEvents TimerMain As System.Windows.Forms.Timer
    Friend WithEvents TmrGrid As System.Windows.Forms.Timer
    Friend WithEvents Timer4 As System.Windows.Forms.Timer
    Friend WithEvents MenuStrip1 As System.Windows.Forms.MenuStrip
    Friend WithEvents MantenimientoToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents AcercaDeToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents AjustesToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents InformacionHH As System.Windows.Forms.TabPage
    Friend WithEvents BtnEnvioHH As System.Windows.Forms.Button
    Friend WithEvents Tooling As System.Windows.Forms.TabPage
    Friend WithEvents TxtUpdTooling As System.Windows.Forms.TextBox
    Friend WithEvents BtnSave As System.Windows.Forms.Button
    Friend WithEvents GridTooling As System.Windows.Forms.DataGridView
    Friend WithEvents Lineas As System.Windows.Forms.TabPage
    Friend WithEvents Panel3 As System.Windows.Forms.Panel
    Friend WithEvents PE10T As System.Windows.Forms.Label
    Friend WithEvents PV10T As System.Windows.Forms.Label
    Friend WithEvents PA10T As System.Windows.Forms.Label
    Friend WithEvents PE9T As System.Windows.Forms.Label
    Friend WithEvents PV9T As System.Windows.Forms.Label
    Friend WithEvents PA9T As System.Windows.Forms.Label
    Friend WithEvents PE8T As System.Windows.Forms.Label
    Friend WithEvents PV8T As System.Windows.Forms.Label
    Friend WithEvents PA8T As System.Windows.Forms.Label
    Friend WithEvents PE7T As System.Windows.Forms.Label
    Friend WithEvents PV7T As System.Windows.Forms.Label
    Friend WithEvents PA7T As System.Windows.Forms.Label
    Friend WithEvents PE6T As System.Windows.Forms.Label
    Friend WithEvents PV6T As System.Windows.Forms.Label
    Friend WithEvents PA6T As System.Windows.Forms.Label
    Friend WithEvents PE5T As System.Windows.Forms.Label
    Friend WithEvents PV5T As System.Windows.Forms.Label
    Friend WithEvents PA5T As System.Windows.Forms.Label
    Friend WithEvents PE4T As System.Windows.Forms.Label
    Friend WithEvents PV4T As System.Windows.Forms.Label
    Friend WithEvents PA4T As System.Windows.Forms.Label
    Friend WithEvents PE3T As System.Windows.Forms.Label
    Friend WithEvents PV3T As System.Windows.Forms.Label
    Friend WithEvents PA3T As System.Windows.Forms.Label
    Friend WithEvents PE2T As System.Windows.Forms.Label
    Friend WithEvents PV2T As System.Windows.Forms.Label
    Friend WithEvents PA2T As System.Windows.Forms.Label
    Friend WithEvents PE1T As System.Windows.Forms.Label
    Friend WithEvents PV1T As System.Windows.Forms.Label
    Friend WithEvents PA1T As System.Windows.Forms.Label
    Friend WithEvents Label5 As System.Windows.Forms.Label
    Friend WithEvents Label4 As System.Windows.Forms.Label
    Friend WithEvents EdtVida As System.Windows.Forms.TextBox
    Friend WithEvents Label3 As System.Windows.Forms.Label
    Friend WithEvents EdtTiempoTotal As System.Windows.Forms.TextBox
    Friend WithEvents Label2 As System.Windows.Forms.Label
    Friend WithEvents EdNumEmpleado As System.Windows.Forms.TextBox
    Friend WithEvents Label1 As System.Windows.Forms.Label
    Friend WithEvents Label44 As System.Windows.Forms.Label
    Friend WithEvents Label15 As System.Windows.Forms.Label
    Friend WithEvents Label16 As System.Windows.Forms.Label
    Friend WithEvents Label40 As System.Windows.Forms.Label
    Friend WithEvents EdtTurno As System.Windows.Forms.TextBox
    Friend WithEvents EdtLado As System.Windows.Forms.TextBox
    Friend WithEvents EdtPrensa As System.Windows.Forms.TextBox
    Friend WithEvents EdtLine As System.Windows.Forms.TextBox
    Friend WithEvents EdtHora As System.Windows.Forms.TextBox
    Friend WithEvents EdtFecha As System.Windows.Forms.TextBox
    Friend WithEvents EdtTecnico As System.Windows.Forms.TextBox
    Friend WithEvents EdtLaina As System.Windows.Forms.TextBox
    Friend WithEvents EdtGreenPlate As System.Windows.Forms.TextBox
    Friend WithEvents EdtPPackAnt As System.Windows.Forms.TextBox
    Friend WithEvents Label41 As System.Windows.Forms.Label
    Friend WithEvents Label43 As System.Windows.Forms.Label
    Friend WithEvents Label37 As System.Windows.Forms.Label
    Friend WithEvents Label38 As System.Windows.Forms.Label
    Friend WithEvents Label39 As System.Windows.Forms.Label
    Friend WithEvents Label34 As System.Windows.Forms.Label
    Friend WithEvents Label35 As System.Windows.Forms.Label
    Friend WithEvents Label33 As System.Windows.Forms.Label
    Friend WithEvents Label32 As System.Windows.Forms.Label
    Friend WithEvents EdtTooling As System.Windows.Forms.TextBox
    Friend WithEvents Label31 As System.Windows.Forms.Label
    Friend WithEvents Label30 As System.Windows.Forms.Label
    Friend WithEvents Label29 As System.Windows.Forms.Label
    Friend WithEvents LPA9 As System.Windows.Forms.Button
    Friend WithEvents Label25 As System.Windows.Forms.Label
    Friend WithEvents LPE10 As System.Windows.Forms.Button
    Friend WithEvents Label24 As System.Windows.Forms.Label
    Friend WithEvents LPV10 As System.Windows.Forms.Button
    Friend WithEvents LPA1 As System.Windows.Forms.Button
    Friend WithEvents LPA10 As System.Windows.Forms.Button
    Friend WithEvents Label27 As System.Windows.Forms.Label
    Friend WithEvents Label26 As System.Windows.Forms.Label
    Friend WithEvents LPE4 As System.Windows.Forms.Button
    Friend WithEvents LPE9 As System.Windows.Forms.Button
    Friend WithEvents LPE1 As System.Windows.Forms.Button
    Friend WithEvents LPV8 As System.Windows.Forms.Button
    Friend WithEvents LPV5 As System.Windows.Forms.Button
    Friend WithEvents LPA8 As System.Windows.Forms.Button
    Friend WithEvents LPE5 As System.Windows.Forms.Button
    Friend WithEvents LPE7 As System.Windows.Forms.Button
    Friend WithEvents LPE6 As System.Windows.Forms.Button
    Friend WithEvents Label17 As System.Windows.Forms.Label
    Friend WithEvents LPV7 As System.Windows.Forms.Button
    Friend WithEvents LPV6 As System.Windows.Forms.Button
    Friend WithEvents LPV1 As System.Windows.Forms.Button
    Friend WithEvents LPA5 As System.Windows.Forms.Button
    Friend WithEvents LPA4 As System.Windows.Forms.Button
    Friend WithEvents LPE2 As System.Windows.Forms.Button
    Friend WithEvents LPV2 As System.Windows.Forms.Button
    Friend WithEvents LPA2 As System.Windows.Forms.Button
    Friend WithEvents LPA7 As System.Windows.Forms.Button
    Friend WithEvents LPV3 As System.Windows.Forms.Button
    Friend WithEvents LPA3 As System.Windows.Forms.Button
    Friend WithEvents LPE3 As System.Windows.Forms.Button
    Friend WithEvents LPA6 As System.Windows.Forms.Button
    Friend WithEvents LPV4 As System.Windows.Forms.Button
    Friend WithEvents LPV9 As System.Windows.Forms.Button
    Friend WithEvents LPE8 As System.Windows.Forms.Button
    Friend WithEvents TabHistorial As System.Windows.Forms.TabControl
    Friend WithEvents TmrFile As System.Windows.Forms.Timer
    Friend WithEvents TmrDbToFile As System.Windows.Forms.Timer
    Friend WithEvents TimerMain2 As System.Windows.Forms.Timer
    'Friend WithEvents ShapeContainer1 As Microsoft.VisualBasic.PowerPacks.ShapeContainer
    'Friend WithEvents RectangleShape2 As Microsoft.VisualBasic.PowerPacks.RectangleShape
    'Friend WithEvents RectangleShape1 As Microsoft.VisualBasic.PowerPacks.RectangleShape
    'Friend WithEvents RECTANGULO As Microsoft.VisualBasic.PowerPacks.RectangleShape
#End Region
End Class