﻿
Imports System.Globalization
Imports System.Data.OleDb
Imports System.IO
Public Class Ajustes
    Dim StrPermisos, StrRecibeEmail As String
    Dim FILE_NAME_Logger As String = "C:\APP\TOOLING\Data\Logger.txt"
    Private Sub btnRegistrar_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnRegistrar.Click
        Dim FILE_NAME As String = "C:\APP\Tooling\DATA\Tecnicos.DAT"

        Dim DownTimeCnnStr As String = "Provider=Microsoft.Jet.OLEDB.4.0;Data Source=C:\APP\TOOLING\Data\PINPACK.mdb;Persist Security Info=False;" 'Jet OLEDB:Database" ' Password=INGENIERIA"        
        Dim conn1 As New System.Data.OleDb.OleDbConnection(DownTimeCnnStr)

        Dim StrTec, Strdum1, Strdum2 As String
        Dim Tecflag As Integer = 1

        Dim myStream As System.IO.StreamReader = New System.IO.StreamReader(FILE_NAME)
        Dim Line1 As String = ""

        If txtNombre.Text <> "" And txtNumero.Text <> "" And txtApellido.Text <> "" Then
            Do
                Line1 = myStream.ReadLine()  'Read everyline of the Tecnicos.DAT file
                If Line1 Is Nothing Then
                    Exit Do
                End If
                Dim sAry As String() = Split(Line1, ",")
                Strdum1 = sAry(0)
                Strdum2 = sAry(1)

                If (Strdum1 = txtNumero.Text) Then
                    MsgBox("Este tecnico ya esta Registrado")
                    Tecflag = 0
                End If

            Loop



        Else
            MsgBox("Captura los campos")
        End If
        myStream.Close()

        Dim access As String = "INSERT INTO ADMIN (ID, [PASSWORD], NOMBRE, APELLIDO, EMAIL, RECIBEEMAIL, MENU) VALUES ('" & txtNumero.Text & "','" & txtNumero.Text & "', '" & txtNombre.Text & "','" & txtApellido.Text & "','" & txtEmail.Text & "','" & StrRecibeEmail & "','" & StrPermisos & "' )"
        conn1.Open()

        Dim cmd1 As New System.Data.OleDb.OleDbCommand(access, conn1)
        cmd1.ExecuteNonQuery()
        conn1.Close()
        MsgBox("Se realizaron los cambios, Si es un nuevo usuario la contrasena temporal es su numero de empleado.")
        GenTecnicosFile() 'Generara el archivo on los tecnicos
        Me.Close()

    End Sub
    Public Sub GenTecnicosFile()

        Dim DownTimeCnnStr As String = "Provider=Microsoft.Jet.OLEDB.4.0;Data Source=C:\APP\TOOLING\Data\PINPACK.mdb;Persist Security Info=False;" 'Jet OLEDB:Database" ' Password=INGENIERIA"        
        Dim conn1 As New System.Data.OleDb.OleDbConnection(DownTimeCnnStr)
        Dim SPath As String = "c:\APP\TOOLING\DATA\"
        
        Dim StrID, StrNom, StrDummyTec As String

        'Declara el archivo de texto para los tecnicos
        Dim FILE_NAME As String = "C:\APP\Tooling\DATA\Tecnicos.DAT"


        Try

            Dim access As String
            access = "Select ID, NOMBRE FROM ADMIN"

            conn1.Open()
            Dim cmd2 As New System.Data.OleDb.OleDbCommand(access, conn1)
            Dim reader2 As OleDbDataReader = cmd2.ExecuteReader


            If System.IO.File.Exists(FILE_NAME) = False Then
                System.IO.File.Create(FILE_NAME).Dispose()
            End If
            Dim objWrtToolOK As New System.IO.StreamWriter(FILE_NAME, True)

            'Lee toda la tabla de los ADMIN y crea el archivo de texto para leer en la HH
            While reader2.Read()
                StrID = reader2.GetString(0)
                StrNom = reader2.GetString(1)
                StrDummyTec = StrID + "," + StrNom
                objWrtToolOK.WriteLine(StrDummyTec)
            End While
            objWrtToolOK.Close()

            conn1.Close()

        Catch ex As Exception
            MsgBox(ex.Message.ToString, MsgBoxStyle.Critical)

        End Try

        'Genera un Log
        Using objWrtLOG As New System.IO.StreamWriter(FILE_NAME_Logger, True)
            objWrtLOG.WriteLine(DateAndTime.Now + " Se Genero el archivo de Tecnicos.DAT ")
            objWrtLOG.Close()
        End Using
    End Sub

    Private Sub btnLineDis_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnLineDis.Click
        Dim DownTimeCnnStr As String = "Provider=Microsoft.Jet.OLEDB.4.0;Data Source=C:\APP\TOOLING\Data\PINPACK.mdb;Persist Security Info=False;" 'Jet OLEDB:Database" ' Password=INGENIERIA"        
        Dim conn1 As New System.Data.OleDb.OleDbConnection(DownTimeCnnStr)

        If MsgBox(txtNumEm.Text + " " + txtNom.Text + " estas deshabilitando la linea: " & txtLineDis.Text & " , se enviara un correo informando a los supervisores que has deshabilitado esta linea. Estas seguro de continuar", MsgBoxStyle.YesNoCancel, "Deshabilitar Lineas") = MsgBoxResult.Yes Then
            conn1.Open()
            Dim query As String = "Select * FROM INFOLINES WHERE INFOLINES.LINEA='" + txtLineDis.Text + "' ORDER BY FECHA DESC, HORA DESC"
            Dim cmd13 As New System.Data.OleDb.OleDbCommand(query, conn1)
            Dim reader13 As OleDbDataReader = cmd13.ExecuteReader

            Dim Encontrado0, Encontrado1, Encontrado15 As String
            Dim Encontrado16 As Double

            'identifica el reporte mas reciente para esa linea
            reader13.Read()
            Encontrado0 = reader13.GetValue(0) 'trae la fecha
            Encontrado1 = reader13.GetValue(1) 'trae la hora
            Encontrado16 = reader13.GetValue(17) 'trae la vida
            Encontrado15 = reader13.GetString(16) 'trae el status

            conn1.Close()


            conn1.Open()

            Dim queryupd As String = "UPDATE INFOLINES SET ESTADO = '" & "D" & "',QUITO = '" & txtNom.Text & "', DURATOTAL = '" & "0" & "', EFICIENCIA = '" & "0" & "' WHERE FECHA = #" & Encontrado0 & "# AND HORA = #" & Encontrado1 & "#"
            query = "UPDATE  RUNNING SET ESTADO='" & "D" & "'  WHERE RUNNING.LINEA='" + txtLineDis.Text + "'"

            Dim cmd10 As New System.Data.OleDb.OleDbCommand(queryupd, conn1)
            Dim cmd11 As New System.Data.OleDb.OleDbCommand(query, conn1)

            cmd11.ExecuteNonQuery()
            cmd10.ExecuteNonQuery()
            conn1.Close()
            Form1.ReadTableStatus()
        End If

    End Sub

    Private Sub btnEnvReport_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnEnvReport.Click
        If MsgBox(txtNumEm.Text + " " + txtNom.Text + " se enviara un correo con el Reporte de las ultimas 12 Horas, deseas continuar ?", MsgBoxStyle.YesNoCancel, "Deshabilitar Lineas") = MsgBoxResult.Yes Then
            Form1.Mailer()
        End If
    End Sub



    Private Sub Ajustes_Load(ByVal sender As Object, ByVal e As System.EventArgs) Handles Me.Load
        Dim colRemovedTabas As New Collection()
        Dim TabPage1 As TabPage
        Form1.ReadTableStatus()

        TabPage1 = tabAjustes.TabPages(1)
        colRemovedTabas.Add(tabAjustes, TabPage1.Name)

        If txtPrivilegios.Text.Contains("ABCD") Then

        Else
            tabAjustes.Controls.Remove(tabDeshabilitar)
            tabAjustes.Controls.Remove(tabTecnicos)
            tabAjustes.Controls.Remove(tabTooling)
            tabAjustes.Controls.Remove(tabReporte)
        End If


    End Sub

    Private Sub L01A_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles L01A.Click
        txtLineDis.Text = "01A"
    End Sub

    Private Sub L01V_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles L01V.Click
        txtLineDis.Text = "01V"
    End Sub

    Private Sub L01E_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles L01E.Click
        txtLineDis.Text = "01E"
    End Sub

    Private Sub L02A_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles L02A.Click
        txtLineDis.Text = "02A"
    End Sub

    Private Sub L02V_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles L02V.Click
        txtLineDis.Text = "02V"
    End Sub

    Private Sub L02E_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles L02E.Click
        txtLineDis.Text = "02E"
    End Sub

    Private Sub L03A_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles L03A.Click
        txtLineDis.Text = "03A"
    End Sub

    Private Sub L03V_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles L03V.Click
        txtLineDis.Text = "03V"
    End Sub

    Private Sub L03E_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles L03E.Click
        txtLineDis.Text = "03E"
    End Sub

    Private Sub L04A_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles L04A.Click
        txtLineDis.Text = "04A"
    End Sub

    Private Sub L04V_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles L04V.Click
        txtLineDis.Text = "04V"
    End Sub

    Private Sub L04E_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles L04E.Click
        txtLineDis.Text = "04E"
    End Sub

    Private Sub L05A_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles L05A.Click
        txtLineDis.Text = "05A"
    End Sub

    Private Sub L05V_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles L05V.Click
        txtLineDis.Text = "05V"
    End Sub

    Private Sub L05E_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles L05E.Click
        txtLineDis.Text = "05E"
    End Sub

    Private Sub L06A_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles L06A.Click
        txtLineDis.Text = "06A"
    End Sub

    Private Sub L06V_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles L06V.Click
        txtLineDis.Text = "06V"
    End Sub

    Private Sub L06E_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles L06E.Click
        txtLineDis.Text = "06E"
    End Sub

    Private Sub L07A_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles L07A.Click
        txtLineDis.Text = "07A"
    End Sub

    Private Sub L07V_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles L07V.Click
        txtLineDis.Text = "07V"
    End Sub

    Private Sub L07E_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles L07E.Click
        txtLineDis.Text = "07E"
    End Sub

    Private Sub L08A_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles L08A.Click
        txtLineDis.Text = "08A"
    End Sub

    Private Sub L08V_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles L08V.Click
        txtLineDis.Text = "08V"
    End Sub

    Private Sub L08E_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles L08E.Click
        txtLineDis.Text = "08E"
    End Sub

    Private Sub L09A_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles L09A.Click
        txtLineDis.Text = "09A"
    End Sub

    Private Sub L09V_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles L09V.Click
        txtLineDis.Text = "09V"
    End Sub

    Private Sub L09E_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles L09E.Click
        txtLineDis.Text = "09E"
    End Sub

    Private Sub L10A_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles L10A.Click
        txtLineDis.Text = "10A"
    End Sub

    Private Sub L10V_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles L10V.Click
        txtLineDis.Text = "10V"
    End Sub

    Private Sub L10E_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles L10E.Click
        txtLineDis.Text = "10E"
    End Sub

    Private Sub btnCerrar_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnCerrar.Click
        Me.Close()
    End Sub

    Private Sub rbEmailNo_CheckedChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles rbEmailNo.CheckedChanged
        StrRecibeEmail = "0"
        txtEmail.Text = "n"
        lblEmail.Visible = False
        txtEmail.Visible = False

    End Sub

    Private Sub rbEmailSi_CheckedChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles rbEmailSi.CheckedChanged
        StrRecibeEmail = "1"
        lblEmail.Visible = True
        txtEmail.Visible = True
        txtEmail.Focus()
    End Sub

    Private Sub rbTecnico_CheckedChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles rbTecnico.CheckedChanged
        StrPermisos = "C"
    End Sub

    Private Sub rbAdministrador_CheckedChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles rbAdministrador.CheckedChanged
        StrPermisos = "ABCD"
    End Sub

    Private Sub btnCreateFiles_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnCreateFiles.Click
        Form1.CreateBadTooling()
        Form1.CreateGoodTooling()
        If System.IO.File.Exists("C:\APP\TOOLING\Data\ToolBADflag.txt") = True Then
            System.IO.File.Delete("C:\APP\TOOLING\Data\ToolBADflag.txt")
        End If
        If System.IO.File.Exists("C:\APP\TOOLING\Data\ToolOKflag.txt") = True Then
            System.IO.File.Delete("C:\APP\TOOLING\Data\ToolOKflag.txt")
        End If
        MsgBox("Se crearon los archivos con las modificaciones.", MsgBoxStyle.OkOnly)
    End Sub
End Class


