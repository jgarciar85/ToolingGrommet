﻿Imports MySql.Data
Imports MySql.Data.MySqlClient
Imports MySql.Data.Types

Public Class DBConnection
    Private dConnection As MySqlConnection
    Public dReader As MySqlDataReader
    Public dDataSet As New DataSet
    Private IsReaderInitialized As Boolean = False
    Private IsDataSetInitialized As Boolean = False

    Public Sub New()
        'Check our current location


        dConnection = New MySqlConnection("server=10.56.12.100; user id=root; database=TimeReport2; port=3306; password=INGENIERIA") 'Guadalupe

    End Sub

    Private Function OpenConnection() As Boolean    'Open Connection to DB
        Try
            dConnection.Open()
        Catch ex As Exception
            Return False
        End Try
        Return True
    End Function

    Function CloseConnection() As Boolean    'Close Connection to DB
        If IsReaderInitialized = True Then
            'Try to close reader
            If dReader.IsClosed = False Then
                dReader.Close()
            End If
        End If
        Try
            'Close connection
            dConnection.Close()
        Catch ex As Exception
        End Try
        Return True
    End Function

    Function SelectQueryReader(ByVal Query As String) As Boolean   'Executes a Select Query and fill the reader 
        'Try to close any active connection       
        CloseConnection()
        'Now open the connection
        OpenConnection()
        'Create a new command
        Dim cmd As New MySqlCommand(Query, dConnection)
        'Prepare reader
        dReader = cmd.ExecuteReader()
        'Set Reader as Initialized
        IsReaderInitialized = True
        'Now we can read from outside, dont forget to call CloseConnection
        Return True
    End Function

    Function SelectQueryDataSet(ByVal Query As String) As Boolean   'Executes a Select Query and fill the dataset
        Dim adapter As New MySqlDataAdapter
        'Try to close any active connection       
        CloseConnection()
        'Now open the connection
        OpenConnection()
        'Create a new command
        Dim cmd As New MySqlCommand(Query, dConnection)
        'Assign command to adapter
        adapter.SelectCommand = cmd
        'Try to clear DataSet
        If IsDataSetInitialized = True Then
            dDataSet.Clear()
            dDataSet.Reset()
        End If
        Try
            'Fill DataSet
            adapter.Fill(dDataSet)
        Catch ex As Exception
            MessageBox.Show("Error al consultar base de datos (DS).", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error)
            Return False
        End Try
        'Set DataSet as Initialized
        IsDataSetInitialized = True
        'Now we can read from outside, dont forget to call CloseConnection
        Return True
    End Function

    Function ModifyQuery(ByVal Query As String) As Boolean   'Executes a Delete or Update Query
        'Try to close any active connection       
        CloseConnection()
        'Now open the connection
        OpenConnection()
        'Create a new command
        Dim cmd As New MySqlCommand(Query, dConnection)
        Try
            'Execute command
            cmd.ExecuteNonQuery()
        Catch ex As Exception
            MessageBox.Show("Error al modificar base de datos.", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error)
            Return False
        End Try
        Return True
    End Function

End Class
